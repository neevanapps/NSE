using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NiftySignal.Domain;
using NiftySignal.Domain.Configuration;
using NiftySignal.Domain.Entities;
using NiftySignal.Domain.Enums;
using NiftySignal.Features;
using NiftySignal.Ingestion.FlatTrade;
using NiftySignal.Persistence;
using NiftySignal.Pricing;
using NiftySignal.Scoring;

namespace NiftySignal.Dashboard.Services;

enum TokenRole { Spot, Future, Vix, Option }

/// <summary>Which slot a token feeds when a tick is pushed -- resolved from the DB every 5s (<see cref="LiveDataService.PollAsync"/>), consulted on every push.</summary>
sealed record TokenInfo(TokenRole Role, decimal Strike, OptionType OptionType);

/// <summary>
/// Backs the dashboard -- successor to the earlier DemoDataService random-walk simulation,
/// kept to the same public shape on purpose (one singleton, one <see cref="Updated"/>
/// event, same view-model records) so panels only had to change their injected service,
/// not their markup.
///
/// Two update paths, not one poll loop:
/// - <see cref="Updated"/> (5s poll) covers the score, data health, and the full option
///   chain table (IV solving + a 30-min OI lookback per row -- genuinely not cheap over
///   ~80 instruments), plus refreshes the token-role/day-open lookups the push path needs.
/// - <see cref="QuoteUpdated"/> (push, via <see cref="ApplyPushedTick"/>) covers what the
///   Live Quote panel shows -- spot/future LTP and the selected CE/PE legs' LTP/bid/ask.
///   Host is a SignalR client of Dashboard's own MarketDataHub (2026-09-04) and forwards
///   every tick the instant it receives one; this class just mutates in-memory state on
///   receipt, no DB round-trip on the hot path. Before this, both paths shared one poll
///   timer, then two separate poll timers (1s/5s) -- push removes the polling floor
///   entirely for the one thing that actually needed sub-second freshness.
///
/// Positions/ClosedTrades (2026-09-04) read the same paper_trades table LiveTradingEngine
/// (Host) writes to -- open positions' CurrentPremium/lot size come from the latest tick and
/// today's instrument master, same "read fresh from the DB each cycle" philosophy
/// LiveTradingEngine itself already uses for open-position state, rather than caching
/// anything that could drift out of sync with what Host actually persisted.
/// </summary>
public sealed class LiveDataService : IDisposable
{
    static readonly TimeSpan PollInterval = TimeSpan.FromSeconds(5);
    static readonly TimeSpan StaleAfter = TimeSpan.FromSeconds(60);

    readonly IDbContextFactory<NiftySignalDbContext> _dbFactory;
    readonly FlatTradeAuthClient _authClient;
    readonly ILogger<LiveDataService> _logger;
    readonly Timer _timer;
    readonly Lock _lock = new();
    int _pollInProgress;

    double _currentScore;
    List<ScoreHistoryPoint> _scoreHistory = [];
    double _currentCoreScore;
    double? _currentCoreScoreFast;
    double? _currentCoreScoreSlow;
    List<CoreScoreHistoryPoint> _coreScoreHistory = [];
    List<OptionChainRow> _optionChain = [];
    List<PositionRow> _positions = [];
    List<StrategyPositionRow> _strategyPositions = [];
    List<ClosedTradeRow> _closedTrades = [];
    Dictionary<(decimal Strike, OptionType Type), QuickQuote> _quickQuotes = [];
    Dictionary<string, TokenInfo> _tokenRoles = [];
    Dictionary<string, decimal> _dayOpenByToken = [];

    // PENDING (2026-09-09, found while fixing the "last 24h" leaks -- see TodayIstMidnightUtc):
    // both fields below are set once via ??= and never reset, so if this Dashboard process ever
    // runs across a midnight without restarting (the same "process outlives the trading day"
    // scenario F22 already tracks for the Host side's WelfordRollingWindow), day 2's warm-up
    // countdown would silently keep reading off day 1's start time instead of today's. Low
    // priority -- display-only (BuildComponentRows' "Remaining" countdown), not score-affecting,
    // and this process gets redeployed most days in practice -- but a latent gap, not a
    // guarantee. Fix properly alongside F22: detect day rollover (compare against
    // TodayIstMidnightUtc each poll) and reset to null rather than relying on process restart.
    DateTimeOffset? _firstSnapshotAt;

    /// <summary>
    /// VIX's own first-observed timestamp (2026-09-04), separate from <see cref="_firstSnapshotAt"/>
    /// -- VIX tracking can start well after the session's other six metrics already have
    /// hours of history (as it did today), so its warm-up countdown needs its own clock
    /// rather than reusing the whole day's start time.
    /// </summary>
    DateTimeOffset? _firstVixSnapshotAt;

    public event Action? Updated;

    /// <summary>Fires on every pushed tick that resolves to a known token -- subscribe to this (not <see cref="Updated"/>) for anything that needs to feel live tick-by-tick, e.g. the Live Quote panel.</summary>
    public event Action? QuoteUpdated;

    public double CurrentScore { get { lock (_lock) return _currentScore; } }

    public IReadOnlyList<ScoreHistoryPoint> ScoreHistory { get { lock (_lock) return _scoreHistory; } }

    public IReadOnlyList<ScoreComponentRow> ScoreComponents { get; private set; } = BuildDefaultComponentRows();

    // --- Core score (Batch 7, 2026-09-14) -- the two new strategies' own scoring pipeline,
    // independent of the 14-component composite above. Same "read fresh every poll" shape.

    public double CurrentCoreScore { get { lock (_lock) return _currentCoreScore; } }

    public double? CurrentCoreScoreFast { get { lock (_lock) return _currentCoreScoreFast; } }

    public double? CurrentCoreScoreSlow { get { lock (_lock) return _currentCoreScoreSlow; } }

    public IReadOnlyList<CoreScoreHistoryPoint> CoreScoreHistory { get { lock (_lock) return _coreScoreHistory; } }

    public IReadOnlyList<CoreScoreComponentRow> CoreScoreComponents { get; private set; } = BuildDefaultCoreScoreComponentRows();

    /// <summary>
    /// Always exactly 2 entries (Hysteresis, Crossover), in that order -- a strategy with no open
    /// position still gets a row, with a null <see cref="StrategyPositionRow.Position"/>, so the
    /// panel can render a stable "flat" state rather than the row disappearing. Refreshed on the
    /// 5s poll only, unlike <see cref="Positions"/> -- deliberately not wired into
    /// <see cref="ApplyPushedTick"/>'s tick-fast path; this is an at-a-glance summary on the score
    /// panel, not the primary position-tracking table (that's <see cref="Positions"/>/
    /// PositionsPanel, which does get the fast path).
    /// </summary>
    public IReadOnlyList<StrategyPositionRow> StrategyPositions { get { lock (_lock) return [.. _strategyPositions]; } }

    public IReadOnlyList<OptionChainRow> OptionChain { get { lock (_lock) return _optionChain; } }

    // Snapshot copy, not the live dictionary (2026-09-08, same bug class as Positions' own fix
    // above): updating an *existing* key doesn't invalidate a Dictionary<TKey,TValue>
    // enumerator, but ApplyPushedTick inserting a genuinely new key (a strike just subscribed
    // to for the first time) while a consumer enumerates the live reference would. A snapshot
    // is immune either way.
    public IReadOnlyDictionary<(decimal Strike, OptionType Type), QuickQuote> QuickQuotes
    {
        get { lock (_lock) return new Dictionary<(decimal, OptionType), QuickQuote>(_quickQuotes); }
    }

    // Snapshot copy, not the live list (2026-09-08 live-caught): ApplyPushedTick mutates
    // _positions in place via index-set (list[i] = value), which bumps List<T>'s internal
    // version counter same as Add/Remove does. A caller enumerating the live reference --
    // PositionsPanel's @foreach captures this getter's return value once, then iterates it
    // across an entire render-tree build, well outside this lock -- would throw
    // InvalidOperationException the moment a tick landed on an open position's instrument
    // mid-render. A snapshot is immune: mutating the *live* field afterward can never affect
    // an already-returned, independent copy.
    public IReadOnlyList<PositionRow> Positions { get { lock (_lock) return [.. _positions]; } }

    public IReadOnlyList<ClosedTradeRow> ClosedTrades { get { lock (_lock) return _closedTrades; } }

    public ConnectionStatus Connection { get; private set; } = ConnectionStatus.Disconnected;

    public DateTimeOffset LastTickAt { get; private set; } = DateTimeOffset.MinValue;

    public decimal? SpotLtp { get; private set; }

    public decimal? FutureLtp { get; private set; }

    public decimal? SpotChange { get; private set; }

    public decimal? FutureChange { get; private set; }

    public decimal? VixLtp { get; private set; }

    public decimal? VixChange { get; private set; }

    /// <summary>
    /// The spot level where net Gamma Exposure crosses zero, per the latest cadence (2026-09-08)
    /// -- see ScoreSnapshot.GammaFlipLevel's own doc comment. A price level, not a magnitude, so
    /// it doesn't belong in <see cref="ScoreComponents"/> (which expects a Z-score/weight shape) --
    /// shown instead next to SpotLtp, the same way it's meant to be read.
    /// </summary>
    public double? GammaFlipLevel { get; private set; }

    public LiveDataService(
        IDbContextFactory<NiftySignalDbContext> dbFactory,
        FlatTradeAuthClient authClient,
        IOptionsMonitor<PricingOptions> pricingOptions,
        ILogger<LiveDataService> logger)
    {
        _dbFactory = dbFactory;
        _authClient = authClient;
        _pricingOptions = pricingOptions;
        _logger = logger;
        _timer = new Timer(_ => Poll(), null, TimeSpan.Zero, PollInterval);
    }

    /// <summary>
    /// Guards against overlapping PollAsync runs -- the fire-and-forget timer used to start a
    /// new poll every 5s regardless of whether the previous one had finished, which would have
    /// let concurrent DB-heavy polls pile up on a slow cycle. Now a poll that's still running
    /// when the next tick fires is skipped rather than stacked.
    /// </summary>
    void Poll()
    {
        if (Interlocked.CompareExchange(ref _pollInProgress, 1, 0) != 0)
        {
            _logger.LogWarning("Skipping poll tick -- previous poll is still running");
            return;
        }

        _ = PollAsync();
    }

    /// <summary>
    /// Called by MarketDataHub the instant Host forwards a tick. No DB access here on
    /// purpose -- that's the whole point of push over poll. Unknown tokens (an on-demand
    /// subscription Host hasn't caught up to yet, or a stale role map) are dropped rather
    /// than guessed at; the next 5s poll's role refresh self-heals it.
    /// </summary>
    public void ApplyPushedTick(Tick tick)
    {
        // Independent of _tokenRoles below (2026-09-08): an open position's own instrument
        // isn't necessarily one of the tracked spot/future/vix/quick-quote roles, so this has
        // to be its own check rather than a fifth TokenRole case. Positions.CurrentPremium
        // otherwise only refreshed on the 5s poll or a trade-changed push (RefreshTradesAsync),
        // both far coarser than the live tick stream everything else on this page already gets.
        var matchedPosition = false;
        lock (_lock)
        {
            for (var i = 0; i < _positions.Count; i++)
            {
                if (_positions[i].InstrumentToken == tick.Token)
                {
                    _positions[i] = _positions[i] with { CurrentPremium = tick.LastPrice };
                    matchedPosition = true;
                }
            }
        }

        if (!_tokenRoles.TryGetValue(tick.Token, out var info))
        {
            // Preserves the original "unknown token, nothing changed, nothing to notify" drop --
            // only fire when the position match above actually changed something.
            if (matchedPosition)
            {
                QuoteUpdated?.Invoke();
            }

            return;
        }

        var change = _dayOpenByToken.TryGetValue(tick.Token, out var open) ? tick.LastPrice - open : (decimal?)null;

        switch (info.Role)
        {
            case TokenRole.Spot:
                SpotLtp = tick.LastPrice;
                SpotChange = change;
                break;

            case TokenRole.Future:
                FutureLtp = tick.LastPrice;
                FutureChange = change;
                break;

            case TokenRole.Vix:
                VixLtp = tick.LastPrice;
                VixChange = change;
                break;

            case TokenRole.Option:
                var depth = tick.Depth;
                lock (_lock)
                {
                    _quickQuotes[(info.Strike, info.OptionType)] = new QuickQuote(
                        Ltp: tick.LastPrice,
                        Bid: depth?.Bid1Price is > 0 ? depth.Bid1Price : null,
                        Ask: depth?.Ask1Price is > 0 ? depth.Ask1Price : null,
                        Change: change);
                }
                break;
        }

        QuoteUpdated?.Invoke();
    }

    /// <summary>
    /// Called by MarketDataHub the instant Host pushes a trade-changed signal (2026-09-07) --
    /// re-reads just positions + closed trades (not the whole 5s poll, which also solves IV
    /// across the option chain) so the Positions/Performance panels update immediately on
    /// entry/partial-book/exit instead of waiting up to 5s for the next timer tick.
    /// </summary>
    public async Task RefreshTradesAsync()
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var positions = await BuildPositionsAsync(db);
        var closedTrades = await BuildClosedTradesAsync(db);

        lock (_lock)
        {
            _positions = positions;
            _closedTrades = closedTrades;
        }

        Updated?.Invoke();
    }

    /// <summary>
    /// Resolves an arbitrary (strike, side) into a real instrument via a live FlatTrade
    /// call and inserts it (Subscribed=false) for the Host's poll loop to pick up -- the
    /// dashboard's "watch this strike even though it's outside the tracked ATM band" path.
    /// Returns false if already live, the session's stale, or FlatTrade has no such strike.
    /// </summary>
    public async Task<bool> RequestSubscriptionAsync(decimal strike, OptionType side)
    {
        if (QuickQuotes.ContainsKey((strike, side)))
        {
            return true; // already subscribed and showing live data
        }

        await using var db = await _dbFactory.CreateDbContextAsync();
        var session = await db.FlatTradeSessions.FindAsync(FlatTradeSession.SingletonId);
        if (session?.Token is null || !session.IsValidAt(DateTimeOffset.UtcNow))
        {
            return false;
        }

        var today = DateOnly.FromDateTime(DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(5.5)).Date);
        var anchor = await db.Instruments
            .Where(i => i.AsOfDate == today && i.InstrumentType == InstrumentType.Option)
            .OrderBy(i => i.ExpiryDate)
            .FirstOrDefaultAsync();
        if (anchor is null)
        {
            return false;
        }

        IReadOnlyList<OptionChainEntry> chain;
        try
        {
            chain = await _authClient.GetOptionChainAsync(session.Token, Exchange.Nfo, anchor.TradingSymbol, strike, strikeCount: 2, CancellationToken.None);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "On-demand strike resolution failed for {Strike} {Side}", strike, side);
            return false;
        }

        var match = chain.FirstOrDefault(c => c.StrikePrice == strike && c.OptionType == side);
        if (match is null)
        {
            return false;
        }

        var exists = await db.Instruments.AnyAsync(i => i.Token == match.Token && i.AsOfDate == today);
        if (!exists)
        {
            db.Instruments.Add(new Instrument
            {
                Token = match.Token,
                Exchange = match.Exchange,
                TradingSymbol = match.TradingSymbol,
                InstrumentType = InstrumentType.Option,
                OptionType = match.OptionType,
                StrikePrice = match.StrikePrice,
                ExpiryDate = anchor.ExpiryDate,
                Underlying = anchor.Underlying,
                LotSize = match.LotSize,
                TickSize = match.TickSize,
                AsOfDate = today,
                Subscribed = false,
            });
            await db.SaveChangesAsync();
        }

        return true;
    }

    async Task PollAsync()
    {
        try
        {
            await using var db = await _dbFactory.CreateDbContextAsync();

            var latestTick = await db.Ticks.OrderByDescending(t => t.ReceivedAt).Select(t => (DateTimeOffset?)t.ReceivedAt).FirstOrDefaultAsync();
            LastTickAt = latestTick ?? DateTimeOffset.MinValue;
            Connection = latestTick is { } lt && DateTimeOffset.UtcNow - lt < StaleAfter
                ? ConnectionStatus.Connected
                : latestTick is null ? ConnectionStatus.Disconnected : ConnectionStatus.Reconnecting;

            var todayIstMidnightUtc = TodayIstMidnightUtc();
            // Floored at today's IST midnight (2026-09-09) -- Take(120) alone (30 min at the 15s
            // cadence) self-corrects once today has that much history, but a session's first few
            // minutes, before 120 of today's own snapshots exist, would otherwise pull in
            // yesterday's tail end. See TodayIstMidnightUtc's doc comment.
            var snapshots = await db.ScoreSnapshots
                .Where(s => s.ComputedAt >= todayIstMidnightUtc)
                .OrderByDescending(s => s.ComputedAt)
                .Take(120)
                .ToListAsync();
            snapshots.Reverse();

            if (snapshots.Count > 0)
            {
                // Same today-only floor (2026-09-09) -- these used to find the all-time-earliest
                // snapshot in the whole table with no date filter, so the warm-up "Remaining"
                // countdown these feed (BuildComponentRows) would read as already-elapsed the
                // instant a session started, off a stopwatch that actually started days ago.
                _firstSnapshotAt ??= await db.ScoreSnapshots
                    .Where(s => s.ComputedAt >= todayIstMidnightUtc)
                    .OrderBy(s => s.ComputedAt)
                    .Select(s => (DateTimeOffset?)s.ComputedAt)
                    .FirstOrDefaultAsync();
                _firstVixSnapshotAt ??= await db.ScoreSnapshots
                    .Where(s => s.ComputedAt >= todayIstMidnightUtc && s.VixChangeRaw != null)
                    .OrderBy(s => s.ComputedAt)
                    .Select(s => (DateTimeOffset?)s.ComputedAt)
                    .FirstOrDefaultAsync();
                var latest = snapshots[^1];

                lock (_lock)
                {
                    _currentScore = latest.CompositeScore ?? _currentScore;
                    _scoreHistory = [.. snapshots.Select(s => new ScoreHistoryPoint(s.ComputedAt, s.CompositeScore ?? 0, s.SpotPrice))];
                }

                ScoreComponents = BuildComponentRows(latest, _firstSnapshotAt ?? latest.ComputedAt, _firstVixSnapshotAt);
                GammaFlipLevel = latest.GammaFlipLevel;
            }

            // Same today-only floor, same Take(120)/reverse shape as the composite score above --
            // a second, independent scoring pipeline (Batch 7, 2026-09-14) with its own history.
            var coreSnapshots = await db.CoreScoreSnapshots
                .Where(s => s.ComputedAt >= todayIstMidnightUtc)
                .OrderByDescending(s => s.ComputedAt)
                .Take(120)
                .ToListAsync();
            coreSnapshots.Reverse();

            if (coreSnapshots.Count > 0)
            {
                var latestCore = coreSnapshots[^1];

                // CoreScoreSnapshot carries no SpotPrice of its own (it's a leaner, purpose-built
                // table -- see that entity's own doc comment); joined here by exact cadence
                // timestamp against ScoreSnapshot instead, since both tables are populated from
                // the SAME cadence tick in MarketDataIngestionWorker and therefore share exact
                // ComputedAt values -- not an approximate/nearest-match join.
                var coreTimestamps = coreSnapshots.Select(s => s.ComputedAt).ToArray();
                var spotByTimestamp = await db.ScoreSnapshots
                    .Where(s => coreTimestamps.Contains(s.ComputedAt))
                    .ToDictionaryAsync(s => s.ComputedAt, s => s.SpotPrice);

                lock (_lock)
                {
                    _currentCoreScore = latestCore.CoreScore ?? _currentCoreScore;
                    _currentCoreScoreFast = latestCore.CoreScoreFast;
                    _currentCoreScoreSlow = latestCore.CoreScoreSlow;
                    _coreScoreHistory = [.. coreSnapshots.Select(s => new CoreScoreHistoryPoint(s.ComputedAt, s.CoreScore ?? 0, s.CoreScoreFast, s.CoreScoreSlow, spotByTimestamp.GetValueOrDefault(s.ComputedAt)))];
                }

                CoreScoreComponents = BuildCoreScoreComponentRows(latestCore);
            }

            var chain = await BuildOptionChainAsync(db);
            lock (_lock)
            {
                _optionChain = chain;
            }

            var positions = await BuildPositionsAsync(db);
            var strategyPositions = await BuildStrategyPositionsAsync(db);
            var closedTrades = await BuildClosedTradesAsync(db);
            lock (_lock)
            {
                _positions = positions;
                _strategyPositions = strategyPositions;
                _closedTrades = closedTrades;
            }

            await RefreshTokenRolesAsync(db);

            Updated?.Invoke();
        }
        catch (Exception ex)
        {
            // A Blazor singleton's background timer must never let an exception escape --
            // that would take down every connected viewer's next poll silently. Log and
            // retry next tick instead (a transient DB hiccup shouldn't kill the dashboard).
            _logger.LogWarning(ex, "LiveDataService poll failed");
        }
        finally
        {
            Interlocked.Exchange(ref _pollInProgress, 0);
        }
    }

    /// <summary>
    /// What <see cref="ApplyPushedTick"/> needs to make sense of a bare token: which slot
    /// it feeds (spot/future/a specific strike+side) and today's opening price for that
    /// token (for the "(+x.xx)" change display). Refreshed every 5s alongside the rest of
    /// <see cref="PollAsync"/> -- a newly on-demand-subscribed instrument shows up here
    /// within one poll cycle of Host actually subscribing to it.
    /// </summary>
    async Task RefreshTokenRolesAsync(NiftySignalDbContext db)
    {
        var today = DateOnly.FromDateTime(DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(5.5)).Date);

        var instruments = await db.Instruments
            .Where(i => i.AsOfDate == today && (i.InstrumentType == InstrumentType.Option || i.InstrumentType == InstrumentType.Future || i.InstrumentType == InstrumentType.Index || i.InstrumentType == InstrumentType.Vix))
            .ToListAsync();

        // Nearest-expiry options only -- same filter BuildOptionChainAsync already applies.
        // The tracked universe holds both weekly expiries, and they share identical
        // strikes (e.g. 23400 CE exists as both a near-week and a next-week token). Without
        // this filter, both tokens map into _quickQuotes under the same (Strike, OptionType)
        // key -- no Expiry component -- and the Live Quote panel flips unpredictably between
        // whichever expiry's tick arrived last (live-caught 2026-09-04).
        var nearestExpiry = instruments
            .Where(i => i.InstrumentType == InstrumentType.Option && i.ExpiryDate is not null)
            .Select(i => i.ExpiryDate!.Value)
            .DefaultIfEmpty()
            .Min();

        var roles = new Dictionary<string, TokenInfo>();
        foreach (var instrument in instruments)
        {
            if (instrument.InstrumentType == InstrumentType.Option && instrument.ExpiryDate != nearestExpiry)
            {
                continue;
            }

            roles[instrument.Token] = instrument.InstrumentType switch
            {
                InstrumentType.Index => new TokenInfo(TokenRole.Spot, 0, OptionType.None),
                InstrumentType.Future => new TokenInfo(TokenRole.Future, 0, OptionType.None),
                InstrumentType.Vix => new TokenInfo(TokenRole.Vix, 0, OptionType.None),
                _ => new TokenInfo(TokenRole.Option, instrument.StrikePrice!.Value, instrument.OptionType),
            };
        }

        var allTokens = instruments.Select(i => i.Token).ToArray();
        var dayOpenTicks = await EarliestTicksAsync(db, allTokens, TodayIstMidnightUtc());
        var dayOpenByToken = dayOpenTicks.ToDictionary(t => t.Token, t => t.LastPrice);

        _tokenRoles = roles;
        _dayOpenByToken = dayOpenByToken;
    }

    /// <summary>
    /// Weight/z/contribution plus each component's own warm-up status (2026-09-04) --
    /// folded together from the former separate ScoreComponents/WarmUpStatuses so ScorePanel
    /// (which absorbed the standalone Data Health panel) reads one list keyed one way,
    /// instead of correlating two lists with differently-formatted names.
    /// </summary>
    static List<ScoreComponentRow> BuildComponentRows(ScoreSnapshot s, DateTimeOffset firstSnapshotAt, DateTimeOffset? firstVixSnapshotAt)
    {
        var elapsed = s.ComputedAt - firstSnapshotAt;
        TimeSpan Remaining(TimeSpan window) => window - elapsed > TimeSpan.Zero ? window - elapsed : TimeSpan.Zero;

        // VIX gets its own clock -- it can start tracking well after the session's other
        // six already have hours of history (as it did today), so reusing firstSnapshotAt
        // would under-count its remaining warm-up time. Null (never seen yet) reads as
        // "the full window remains", not "already warmed up".
        var vixRemaining = firstVixSnapshotAt is { } vixStart
            ? (FeatureWindowLengths.VixChangeZScoreWindow - (s.ComputedAt - vixStart) is var vixLeft && vixLeft > TimeSpan.Zero ? vixLeft : TimeSpan.Zero)
            : FeatureWindowLengths.VixChangeZScoreWindow;

        return
        [
            new("OiBuildupNet", ScoreWeights.Default.OiBuildupNet, s.OiBuildupNetZ ?? 0, (s.OiBuildupNetZ ?? 0) * ScoreWeights.Default.OiBuildupNet,
                s.OiBuildupNetZ is not null, FeatureWindowLengths.OiBuildupNet, Remaining(FeatureWindowLengths.OiBuildupNet)),
            new("Pcr", ScoreWeights.Default.Pcr, s.PcrZ ?? 0, (s.PcrZ ?? 0) * ScoreWeights.Default.Pcr,
                s.PcrZ is not null, FeatureWindowLengths.Pcr, Remaining(FeatureWindowLengths.Pcr)),
            new("FuturesBasis", ScoreWeights.Default.FuturesBasis, s.FuturesBasisZ ?? 0, (s.FuturesBasisZ ?? 0) * ScoreWeights.Default.FuturesBasis,
                s.FuturesBasisZ is not null, FeatureWindowLengths.FuturesBasis, Remaining(FeatureWindowLengths.FuturesBasis)),
            new("IvSkew", ScoreWeights.Default.IvSkew, s.IvSkewZ ?? 0, (s.IvSkewZ ?? 0) * ScoreWeights.Default.IvSkew,
                s.IvSkewZ is not null, FeatureWindowLengths.IvSkew, Remaining(FeatureWindowLengths.IvSkew)),
            new("PriceMomentum", ScoreWeights.Default.PriceMomentum, s.PriceMomentumZ ?? 0, (s.PriceMomentumZ ?? 0) * ScoreWeights.Default.PriceMomentum,
                s.PriceMomentumZ is not null, FeatureWindowLengths.PriceMomentum, Remaining(FeatureWindowLengths.PriceMomentum)),
            new("DepthImbalance", ScoreWeights.Default.DepthImbalance, s.DepthImbalanceZ ?? 0, (s.DepthImbalanceZ ?? 0) * ScoreWeights.Default.DepthImbalance,
                s.DepthImbalanceZ is not null, FeatureWindowLengths.DepthImbalance, Remaining(FeatureWindowLengths.DepthImbalance)),
            // Optional (see CompositeScoreCalculator) -- can legitimately stay "not warmed
            // up" indefinitely on a day VIX isn't tracked, unlike the other six.
            new("VixChange", ScoreWeights.Default.VixChange, s.VixChangeZ ?? 0, (s.VixChangeZ ?? 0) * ScoreWeights.Default.VixChange,
                s.VixChangeZ is not null, FeatureWindowLengths.VixChangeZScoreWindow, vixRemaining),
            // Diagnostic-only (weight 0.0, see ScoreWeights.Default) -- shown so the metric can
            // be watched across real sessions before it's ever given a nonzero weight.
            new("GammaExposure", ScoreWeights.Default.GammaExposure, s.GammaExposureZ ?? 0, (s.GammaExposureZ ?? 0) * ScoreWeights.Default.GammaExposure,
                s.GammaExposureZ is not null, FeatureWindowLengths.GammaExposure, Remaining(FeatureWindowLengths.GammaExposure)),
            // Diagnostic-only (weight 0.0, see ScoreWeights.Default) -- same treatment as GammaExposure.
            new("VolumePcr", ScoreWeights.Default.VolumePcr, s.VolumePcrZ ?? 0, (s.VolumePcrZ ?? 0) * ScoreWeights.Default.VolumePcr,
                s.VolumePcrZ is not null, FeatureWindowLengths.VolumePcr, Remaining(FeatureWindowLengths.VolumePcr)),
            // Diagnostic-only (weight 0.0, see ScoreWeights.Default) -- same treatment as GammaExposure/VolumePcr.
            new("SpreadRatio", ScoreWeights.Default.SpreadRatio, s.SpreadRatioZ ?? 0, (s.SpreadRatioZ ?? 0) * ScoreWeights.Default.SpreadRatio,
                s.SpreadRatioZ is not null, FeatureWindowLengths.SpreadRatio, Remaining(FeatureWindowLengths.SpreadRatio)),
            // Diagnostic-only (weight 0.0, see ScoreWeights.Default) -- same treatment as the three above.
            new("VannaExposure", ScoreWeights.Default.VannaExposure, s.VannaExposureZ ?? 0, (s.VannaExposureZ ?? 0) * ScoreWeights.Default.VannaExposure,
                s.VannaExposureZ is not null, FeatureWindowLengths.VannaExposure, Remaining(FeatureWindowLengths.VannaExposure)),
            new("CharmExposure", ScoreWeights.Default.CharmExposure, s.CharmExposureZ ?? 0, (s.CharmExposureZ ?? 0) * ScoreWeights.Default.CharmExposure,
                s.CharmExposureZ is not null, FeatureWindowLengths.CharmExposure, Remaining(FeatureWindowLengths.CharmExposure)),
            new("CvdProxy", ScoreWeights.Default.CvdProxy, s.CvdProxyZ ?? 0, (s.CvdProxyZ ?? 0) * ScoreWeights.Default.CvdProxy,
                s.CvdProxyZ is not null, FeatureWindowLengths.CvdProxy, Remaining(FeatureWindowLengths.CvdProxy)),
            // Volatility-demand, not directional (see ScoreSnapshot.StraddleRichnessRaw's doc
            // comment) -- still rendered as an ordinary weighted row here since weight is 0.0
            // either way; the distinction only matters once/if it's ever given a real weight.
            new("StraddleRichness", ScoreWeights.Default.StraddleRichness, s.StraddleRichnessZ ?? 0, (s.StraddleRichnessZ ?? 0) * ScoreWeights.Default.StraddleRichness,
                s.StraddleRichnessZ is not null, FeatureWindowLengths.StraddleRichness, Remaining(FeatureWindowLengths.StraddleRichness)),
        ];
    }

    static List<ScoreComponentRow> BuildDefaultComponentRows() =>
    [
        new("OiBuildupNet", ScoreWeights.Default.OiBuildupNet, 0, 0, false, FeatureWindowLengths.OiBuildupNet, FeatureWindowLengths.OiBuildupNet),
        new("Pcr", ScoreWeights.Default.Pcr, 0, 0, false, FeatureWindowLengths.Pcr, FeatureWindowLengths.Pcr),
        new("FuturesBasis", ScoreWeights.Default.FuturesBasis, 0, 0, false, FeatureWindowLengths.FuturesBasis, FeatureWindowLengths.FuturesBasis),
        new("IvSkew", ScoreWeights.Default.IvSkew, 0, 0, false, FeatureWindowLengths.IvSkew, FeatureWindowLengths.IvSkew),
        new("PriceMomentum", ScoreWeights.Default.PriceMomentum, 0, 0, false, FeatureWindowLengths.PriceMomentum, FeatureWindowLengths.PriceMomentum),
        new("DepthImbalance", ScoreWeights.Default.DepthImbalance, 0, 0, false, FeatureWindowLengths.DepthImbalance, FeatureWindowLengths.DepthImbalance),
        new("VixChange", ScoreWeights.Default.VixChange, 0, 0, false, FeatureWindowLengths.VixChangeZScoreWindow, FeatureWindowLengths.VixChangeZScoreWindow),
        new("GammaExposure", ScoreWeights.Default.GammaExposure, 0, 0, false, FeatureWindowLengths.GammaExposure, FeatureWindowLengths.GammaExposure),
        new("VolumePcr", ScoreWeights.Default.VolumePcr, 0, 0, false, FeatureWindowLengths.VolumePcr, FeatureWindowLengths.VolumePcr),
        new("SpreadRatio", ScoreWeights.Default.SpreadRatio, 0, 0, false, FeatureWindowLengths.SpreadRatio, FeatureWindowLengths.SpreadRatio),
        new("VannaExposure", ScoreWeights.Default.VannaExposure, 0, 0, false, FeatureWindowLengths.VannaExposure, FeatureWindowLengths.VannaExposure),
        new("CharmExposure", ScoreWeights.Default.CharmExposure, 0, 0, false, FeatureWindowLengths.CharmExposure, FeatureWindowLengths.CharmExposure),
        new("CvdProxy", ScoreWeights.Default.CvdProxy, 0, 0, false, FeatureWindowLengths.CvdProxy, FeatureWindowLengths.CvdProxy),
        new("StraddleRichness", ScoreWeights.Default.StraddleRichness, 0, 0, false, FeatureWindowLengths.StraddleRichness, FeatureWindowLengths.StraddleRichness),
    ];

    /// <summary>Batch 7 (2026-09-14) -- the Core score's own 8 terms, same weights <see cref="CoreScoreWeights.Default"/> the live engine actually trades on.</summary>
    static List<CoreScoreComponentRow> BuildCoreScoreComponentRows(CoreScoreSnapshot s) =>
    [
        new("DepthImbalance", CoreScoreWeights.Default.DepthImbalance, s.DepthImbalanceSigned, (s.DepthImbalanceSigned ?? 0) * CoreScoreWeights.Default.DepthImbalance, s.DepthImbalanceSigned is not null),
        new("ItmSkew", CoreScoreWeights.Default.ItmSkew, s.ItmSkewSigned, (s.ItmSkewSigned ?? 0) * CoreScoreWeights.Default.ItmSkew, s.ItmSkewSigned is not null),
        new("FutureCvdNet5Min", CoreScoreWeights.Default.FutureCvdNet5Min, s.FutureCvdNet5MinSigned, (s.FutureCvdNet5MinSigned ?? 0) * CoreScoreWeights.Default.FutureCvdNet5Min, s.FutureCvdNet5MinSigned is not null),
        new("NotionalVolumeRatio", CoreScoreWeights.Default.NotionalVolumeRatio, s.NotionalVolumeRatioSigned, (s.NotionalVolumeRatioSigned ?? 0) * CoreScoreWeights.Default.NotionalVolumeRatio, s.NotionalVolumeRatioSigned is not null),
        new("GammaExposure", CoreScoreWeights.Default.GammaExposure, s.GammaExposureSigned, (s.GammaExposureSigned ?? 0) * CoreScoreWeights.Default.GammaExposure, s.GammaExposureSigned is not null),
        new("TrendReversion15m", CoreScoreWeights.Default.TrendReversion15m, s.TrendReversion15mSigned, (s.TrendReversion15mSigned ?? 0) * CoreScoreWeights.Default.TrendReversion15m, s.TrendReversion15mSigned is not null),
        new("BasisChange", CoreScoreWeights.Default.BasisChange, s.BasisChangeSigned, (s.BasisChangeSigned ?? 0) * CoreScoreWeights.Default.BasisChange, s.BasisChangeSigned is not null),
        new("OiChangeDiff15m", CoreScoreWeights.Default.OiChangeDiff15m, s.OiChangeDiff15mSigned, (s.OiChangeDiff15mSigned ?? 0) * CoreScoreWeights.Default.OiChangeDiff15m, s.OiChangeDiff15mSigned is not null),
    ];

    static List<CoreScoreComponentRow> BuildDefaultCoreScoreComponentRows() =>
    [
        new("DepthImbalance", CoreScoreWeights.Default.DepthImbalance, null, 0, false),
        new("ItmSkew", CoreScoreWeights.Default.ItmSkew, null, 0, false),
        new("FutureCvdNet5Min", CoreScoreWeights.Default.FutureCvdNet5Min, null, 0, false),
        new("NotionalVolumeRatio", CoreScoreWeights.Default.NotionalVolumeRatio, null, 0, false),
        new("GammaExposure", CoreScoreWeights.Default.GammaExposure, null, 0, false),
        new("TrendReversion15m", CoreScoreWeights.Default.TrendReversion15m, null, 0, false),
        new("BasisChange", CoreScoreWeights.Default.BasisChange, null, 0, false),
        new("OiChangeDiff15m", CoreScoreWeights.Default.OiChangeDiff15m, null, 0, false),
    ];

    async Task<List<OptionChainRow>> BuildOptionChainAsync(NiftySignalDbContext db)
    {
        var today = DateOnly.FromDateTime(DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(5.5)).Date);

        var instruments = await db.Instruments
            .Where(i => i.AsOfDate == today && i.InstrumentType == InstrumentType.Option)
            .ToListAsync();
        if (instruments.Count == 0)
        {
            return [];
        }

        // Both tracked weeklies come back together (2026-09-05); OptionChainPanel filters to
        // the one the viewer selected. Deliberately not filtered here: LiveDataService is a
        // singleton shared by every circuit, so an expiry choice stored on it would change the
        // view for everyone at once. Note this does NOT touch RefreshTokenRolesAsync, which
        // stays nearest-expiry-only -- _quickQuotes is keyed (Strike, OptionType) with no
        // expiry component, and relaxing that filter would reintroduce the CE/PE flip bug
        // caught live on 2026-09-04.
        var tokens = instruments.Select(i => i.Token).ToArray();

        var spotToken = await db.Instruments
            .Where(i => i.AsOfDate == today && i.InstrumentType == InstrumentType.Index)
            .Select(i => i.Token)
            .FirstOrDefaultAsync();

        var latestTicks = await LatestTicksAsync(db, tokens);
        var latestByToken = latestTicks.ToDictionary(t => t.Token);

        var todayIstMidnightUtc = TodayIstMidnightUtc();

        // OI itself only updates on the exchange side every ~3 minutes -- comparing
        // against the immediately-prior poll (5s ago) was structurally almost always a
        // no-op, which is why this always read 0.0%. Compare against ~30 minutes ago
        // instead, a window long enough to always span at least one real OI update. Floored at
        // today's IST midnight (2026-09-09, via LatestTicksAtOrBeforeAsync's sinceUtc) -- for the
        // first ~30 minutes of every session, "30 minutes ago" falls before today's first tick;
        // with no lower bound in the query, that silently fell back to yesterday's closing OI.
        // The floor means those first 30 minutes correctly find no row (OiChangePct's existing
        // "no prior tick" default of 0%) instead of a real-looking but cross-day number.
        var oiLookbackCutoff = DateTimeOffset.UtcNow.AddMinutes(-30);
        var oi30MinAgoTicks = await LatestTicksAtOrBeforeAsync(db, tokens, todayIstMidnightUtc, oiLookbackCutoff);
        var oi30MinAgoByToken = oi30MinAgoTicks.ToDictionary(t => t.Token, t => t.OpenInterest);

        var dayOpenTicks = await EarliestTicksAsync(db, tokens, todayIstMidnightUtc);
        var dayOpenByToken = dayOpenTicks.ToDictionary(t => t.Token, t => t.LastPrice);

        // Spot/Future LTP+change are ApplyPushedTick's job now (push, not poll) -- still
        // fetched here since the ATM calc and IV solve below need spotLtp, just no longer
        // published to the SpotLtp/FutureLtp properties from this (5s) path.
        //
        // Spot, not the tracked future (2026-09-04 fix, live-caught: "all put IVs read >10,
        // call IVs around 5"). NSE only lists monthly futures; the tracked future is the
        // current-month contract, which doesn't match this weekly option chain's own (much
        // nearer) expiry. Using it overstated the underlying by its full month-vs-week
        // cost-of-carry gap (~127 points, observed 2026-09-04) -- enough to price deep-ITM
        // calls below their own intrinsic value (an impossible/arbitrage price), which is
        // what was driving the solver to a degenerate call IV and, symmetrically, an
        // inflated put IV. Kept only as the anchor for BuildSyntheticForwardByExpiry below
        // (2026-09-07) -- spot itself is no longer fed directly into any IV/Greeks calculation;
        // that first fix was directionally right but incomplete, since spot alone still carries
        // no cost-of-carry adjustment. See BuildSyntheticForwardByExpiry's own doc comment.
        var spotLtp = spotToken is null
            ? (decimal?)null
            : await db.Ticks.Where(t => t.Token == spotToken).OrderByDescending(t => t.ExchangeTimestamp).Select(t => (decimal?)t.LastPrice).FirstOrDefaultAsync();

        if (latestByToken.Count == 0)
        {
            return [];
        }

        // ATM = the strike whose call+put pair together straddle the underlying most
        // tightly -- approximate with "nearest strike to spot" if we have one.
        var atmStrike = spotLtp is { } sl
            ? instruments.Select(i => i.StrikePrice!.Value).Distinct().OrderBy(s => Math.Abs(s - sl)).FirstOrDefault()
            : instruments.Select(i => i.StrikePrice!.Value).Distinct().OrderBy(s => s).Skip(instruments.Count / 4).FirstOrDefault();

        // Time to expiry is per-expiry now that both weeklies are in play -- a single `t` from
        // the nearest expiry would misprice every next-week row.
        var yearsToExpiry = instruments
            .Select(i => i.ExpiryDate!.Value)
            .Distinct()
            .ToDictionary(e => e, e => TimeToExpiry.YearsUntilExpiry(e, DateTimeOffset.UtcNow));

        // Synthetic forward per expiry via put-call parity (2026-09-07) -- replaces spotLtp as
        // the Black-Scholes underlying below. Neither spot nor a tracked future is the right
        // underlying for a weekly option (spot has no cost-of-carry adjustment; the earlier
        // 2026-09-04 fix already ruled out the mismatched monthly future) -- a same-day live
        // check found systematically inconsistent call/put IV at the same strike (put running
        // ~7-8 vol points below call, everywhere, all day) that traced to exactly this: an
        // understated underlying biases a call solve up and a put solve down. See
        // NiftySignal.Pricing.SyntheticForward's doc comment and
        // LiveFeatureEngine.ComputeUnderlyingPrice (same fix, same day, same root cause).
        var forwardByExpiry = spotLtp is { } spotForForward
            ? BuildSyntheticForwardByExpiry(instruments, latestByToken, spotForForward, yearsToExpiry, RiskFreeRate)
            : [];

        // Reference vol for theoretical pricing (2026-09-05), solved per expiry at the ATM
        // strike. Pricing each strike with its *own* implied vol would just reproduce that
        // strike's market price exactly -- true by construction, and useless. Pricing every
        // strike at the ATM strike's vol instead makes the gap meaningful: it's the skew
        // premium in rupee terms, i.e. how much more (or less) the market is paying for this
        // strike than the at-the-money baseline implies. Above theoretical reads as demand
        // bidding premium up; below reads as supply/writing pressure.
        var atmVolByExpiry = BuildAtmReferenceVol(instruments, latestByToken, forwardByExpiry, atmStrike, yearsToExpiry, RiskFreeRate);

        var rows = new List<OptionChainRow>();
        foreach (var instrument in instruments.OrderBy(i => i.ExpiryDate).ThenBy(i => i.StrikePrice))
        {
            if (!latestByToken.TryGetValue(instrument.Token, out var tick))
            {
                continue;
            }

            var expiry = instrument.ExpiryDate!.Value;
            var t = yearsToExpiry[expiry];

            double? iv = null, theoretical = null;
            if (forwardByExpiry.TryGetValue(expiry, out var underlying) && tick.LastPrice > 0)
            {
                iv = ImpliedVolatilitySolver.Solve(instrument.OptionType, (double)tick.LastPrice, (double)underlying, (double)instrument.StrikePrice!.Value, t, RiskFreeRate);

                if (atmVolByExpiry.TryGetValue(expiry, out var atmVol))
                {
                    theoretical = BlackScholes.Calculate(
                        instrument.OptionType, (double)underlying, (double)instrument.StrikePrice!.Value, t, RiskFreeRate, atmVol).Price;
                }
            }

            var depth = tick.Depth;
            // Normalized (bid-ask)/(bid+ask), not a raw bid/ask ratio -- a ratio of two
            // non-negative quantities can never be negative, yet the grid colors this
            // bull/bear and formats it with a sign as if it could swing either way. Same
            // bug, same fix, as LiveFeatureEngine.ComputeDepthImbalance (2026-09-04).
            var depthImbalance = depth is { } d && (d.TotalBidQty + d.TotalAskQty) > 0
                ? (double)(d.TotalBidQty - d.TotalAskQty) / (d.TotalBidQty + d.TotalAskQty)
                : 0.0;

            long? oiChange = null;
            double oiChangePct = 0;
            if (oi30MinAgoByToken.TryGetValue(instrument.Token, out var oi30MinAgo) && oi30MinAgo is { } prevOi && tick.OpenInterest is { } currentOi)
            {
                oiChange = currentOi - prevOi;
                if (prevOi > 0)
                {
                    oiChangePct = (double)oiChange.Value / prevOi * 100.0;
                }
            }

            var change = dayOpenByToken.TryGetValue(instrument.Token, out var open) ? tick.LastPrice - open : (decimal?)null;

            rows.Add(new OptionChainRow(
                TradingSymbol: instrument.TradingSymbol,
                OptionType: instrument.OptionType,
                Strike: instrument.StrikePrice!.Value,
                ExpiryDate: expiry,
                Ltp: tick.LastPrice,
                OpenInterest: tick.OpenInterest ?? 0,
                LotSize: instrument.LotSize,
                OiChangePct: oiChangePct,
                OiChange: oiChange,
                ImpliedVolatility: iv,
                TheoreticalPrice: theoretical,
                DepthImbalance: depthImbalance,
                Buildup: OiBuildupClassification.Neutral, // per-row buildup not tracked yet -- see LiveFeatureEngine for the aggregate version
                IsAtm: instrument.StrikePrice == atmStrike,
                Bid: depth?.Bid1Price is > 0 ? depth.Bid1Price : null,
                Ask: depth?.Ask1Price is > 0 ? depth.Ask1Price : null,
                Change: change));
        }

        return rows;
    }

    /// <summary>
    /// One reference volatility per expiry, solved from the ATM strike -- the most liquid and
    /// therefore most trustworthy point on the chain. Prefers the call, falls back to the put
    /// if the call's solve fails. Expiries with no usable ATM quote are simply absent from the
    /// result, and their rows get no theoretical price rather than one built on a guess.
    ///
    /// Audit finding F33 fixed (2026-09-09): the fallback/solve step (call preferred, put as
    /// fallback) is now shared with LiveFeatureEngine.SolveAtmReferenceVol via
    /// AtmReferenceVolSolver (NiftySignal.Pricing) -- only this method's own multi-expiry
    /// iteration and LTP-based mark price stay local, since those are legitimate, pre-existing
    /// differences from the live engine's single-expiry/mid-price read (this is a display value,
    /// not a live scoring input), not something that needed sharing.
    /// </summary>
    static Dictionary<DateOnly, double> BuildAtmReferenceVol(
        List<Instrument> instruments,
        Dictionary<string, Tick> latestByToken,
        Dictionary<DateOnly, decimal> forwardByExpiry,
        decimal atmStrike,
        Dictionary<DateOnly, double> yearsToExpiry,
        double riskFreeRate)
    {
        var result = new Dictionary<DateOnly, double>();

        foreach (var expiry in yearsToExpiry.Keys)
        {
            if (!forwardByExpiry.TryGetValue(expiry, out var underlying))
            {
                continue;
            }

            var atmLegs = instruments
                .Where(i => i.ExpiryDate == expiry && i.StrikePrice == atmStrike)
                .OrderBy(i => i.OptionType == OptionType.Call ? 0 : 1)
                .Select(i => latestByToken.TryGetValue(i.Token, out var tick)
                    ? new AtmReferenceVolSolver.Leg(i.OptionType, tick.LastPrice)
                    : (AtmReferenceVolSolver.Leg?)null)
                .Where(leg => leg is not null)
                .Select(leg => leg!.Value);

            if (AtmReferenceVolSolver.Solve(atmLegs, atmStrike, underlying, yearsToExpiry[expiry], riskFreeRate) is { } vol)
            {
                result[expiry] = vol;
            }
        }

        return result;
    }

    const int SyntheticForwardStrikeCount = 5;

    /// <summary>
    /// Synthetic forward via put-call parity, one per expiry (2026-09-07) -- see the call
    /// site's doc comment for why this replaced spotLtp as the Black-Scholes underlying.
    /// Averages (median, via SyntheticForward.Compute) the parity estimate from the
    /// <see cref="SyntheticForwardStrikeCount"/> strikes nearest spot within that expiry, each
    /// with both a call and put quote. Falls back to spotLtp itself for an expiry where no
    /// strike has both legs quoted yet.
    /// </summary>
    static Dictionary<DateOnly, decimal> BuildSyntheticForwardByExpiry(
        List<Instrument> instruments,
        Dictionary<string, Tick> latestByToken,
        decimal spotLtp,
        Dictionary<DateOnly, double> yearsToExpiry,
        double riskFreeRate)
    {
        var result = new Dictionary<DateOnly, decimal>();

        foreach (var (expiry, t) in yearsToExpiry)
        {
            var expiryInstruments = instruments.Where(i => i.ExpiryDate == expiry).ToList();
            var pairs = new List<(double Strike, double CallMid, double PutMid)>();

            foreach (var strike in expiryInstruments.Select(i => i.StrikePrice!.Value).Distinct().OrderBy(s => Math.Abs(s - spotLtp)).Take(SyntheticForwardStrikeCount))
            {
                var call = expiryInstruments.FirstOrDefault(i => i.OptionType == OptionType.Call && i.StrikePrice == strike);
                var put = expiryInstruments.FirstOrDefault(i => i.OptionType == OptionType.Put && i.StrikePrice == strike);
                if (call is null || put is null
                    || !latestByToken.TryGetValue(call.Token, out var callTick) || !latestByToken.TryGetValue(put.Token, out var putTick)
                    || MidPrice(callTick) is not { } callMid || MidPrice(putTick) is not { } putMid)
                {
                    continue;
                }

                pairs.Add(((double)strike, (double)callMid, (double)putMid));
            }

            result[expiry] = SyntheticForward.Compute(pairs, t, riskFreeRate) is { } forward ? (decimal)forward : spotLtp;
        }

        return result;
    }

    static decimal? MidPrice(Tick tick)
    {
        if (tick.Depth is { } depth && depth.Bid1Price > 0 && depth.Ask1Price > 0)
        {
            return (depth.Bid1Price + depth.Ask1Price) / 2;
        }

        return tick.LastPrice > 0 ? tick.LastPrice : null;
    }

    /// <summary>
    /// Open paper_trades rows plus what the UI needs but the row itself doesn't store -- the
    /// live mark price, from the same latest-tick lookup BuildOptionChainAsync already uses
    /// for the same purpose. Quantity is the *remaining* open quantity (2026-09-08 dashboard
    /// fix): PaperTrade.Quantity itself is always the original traded-at-entry total (2026-09-07
    /// -- what was actually traded, not re-derived from the instrument's exchange lot size,
    /// since LotsPerTrade means those two numbers are no longer the same thing), but once a
    /// position has partially booked, only Quantity minus PartialExitQuantity is genuinely
    /// still open -- showing the original total there read as if the booked half were still
    /// at risk, both in the Qty column and in UnrealizedPnl (PositionRow multiplies by this).
    /// </summary>
    async Task<List<PositionRow>> BuildPositionsAsync(NiftySignalDbContext db)
    {
        var open = await db.PaperTrades.Where(t => t.ExitTime == null).ToListAsync();
        if (open.Count == 0)
        {
            return [];
        }

        var latestPriceByToken = await LatestPriceByTokenAsync(db, open.Select(t => t.InstrumentToken));
        return open.Select(t => ToPositionRow(t, latestPriceByToken)).ToList();
    }

    /// <summary>
    /// Batch 7 (2026-09-14) -- the two new strategies' own open position, if any, for the
    /// repurposed ScorePanel. Always returns exactly one row per <see cref="StrategyId"/> (null
    /// <see cref="StrategyPositionRow.Position"/> when flat) rather than omitting flat strategies,
    /// so the panel renders a stable two-row layout instead of the row count itself changing.
    /// </summary>
    async Task<List<StrategyPositionRow>> BuildStrategyPositionsAsync(NiftySignalDbContext db)
    {
        var open = await db.PaperTrades
            .Where(t => t.ExitTime == null && (t.StrategyId == StrategyId.CoreScoreHysteresis || t.StrategyId == StrategyId.CoreScoreCrossover))
            .ToListAsync();

        var latestPriceByToken = await LatestPriceByTokenAsync(db, open.Select(t => t.InstrumentToken));

        PositionRow? RowFor(StrategyId strategyId) =>
            open.FirstOrDefault(t => t.StrategyId == strategyId) is { } trade ? ToPositionRow(trade, latestPriceByToken) : null;

        return
        [
            new StrategyPositionRow(StrategyId.CoreScoreHysteresis, RowFor(StrategyId.CoreScoreHysteresis)),
            new StrategyPositionRow(StrategyId.CoreScoreCrossover, RowFor(StrategyId.CoreScoreCrossover)),
        ];
    }

    static PositionRow ToPositionRow(PaperTrade t, IReadOnlyDictionary<string, decimal> latestPriceByToken) => new(
        InstrumentToken: t.InstrumentToken,
        TradingSymbol: t.TradingSymbol,
        Direction: t.Direction,
        EntryPremium: t.EntryPrice,
        // Falls back to entry price (0 unrealized) if no tick has landed yet for this
        // token this session -- same "nothing live yet" tolerance as everywhere else,
        // not a crash or a fabricated number.
        CurrentPremium: latestPriceByToken.TryGetValue(t.InstrumentToken, out var ltp) ? ltp : t.EntryPrice,
        Quantity: t.HasPartiallyBooked ? t.Quantity - (t.PartialExitQuantity ?? 0) : t.Quantity,
        EntryTime: t.EntryTime,
        HasPartiallyBooked: t.HasPartiallyBooked);

    static async Task<Dictionary<string, decimal>> LatestPriceByTokenAsync(NiftySignalDbContext db, IEnumerable<string> tokens)
    {
        var distinctTokens = tokens.Distinct().ToArray();
        var latestTicks = await LatestTicksAsync(db, distinctTokens);
        return latestTicks.ToDictionary(t => t.Token, t => t.LastPrice);
    }

    /// <summary>
    /// Closed trades from today's IST session, matching PerformancePanel's own "(today)" title
    /// (2026-09-09 -- was a rolling AddHours(-24) window, so a trade from yesterday evening was
    /// still "recent" hours into today's session; see TodayIstMidnightUtc's doc comment).
    /// </summary>
    async Task<List<ClosedTradeRow>> BuildClosedTradesAsync(NiftySignalDbContext db)
    {
        var cutoff = TodayIstMidnightUtc();
        var closed = await db.PaperTrades
            .Where(t => t.ExitTime != null && t.ExitTime >= cutoff)
            .OrderByDescending(t => t.ExitTime)
            .ToListAsync();

        return closed.Select(t => new ClosedTradeRow(
            TradingSymbol: t.TradingSymbol,
            Direction: t.Direction,
            EntryTime: t.EntryTime,
            ExitTime: t.ExitTime!.Value,
            NetPnl: t.NetPnl ?? 0,
            ExitReason: t.ExitReason))
            .ToList();
    }

    /// <summary>
    /// "Latest/earliest tick per token" the LINQ way -- <c>GroupBy(t => t.Token).Select(g =>
    /// g.OrderBy(...).First())</c> -- translates to a ROW_NUMBER() window function scanning and
    /// sorting every matching row for every token, not an index seek per token. Measured against
    /// the live DB (3.86M rows): ~11s wall time with a 200MB+ disk sort. Raw SQL was needed too --
    /// Npgsql's EF Core provider flattens even a correlated `Select(x => relatedQuery.
    /// FirstOrDefault())` into the same window-function shape rather than a LATERAL join
    /// (confirmed via ToQueryString), so plain LINQ can't reach the fast plan either way.
    ///
    /// `unnest(tokens) CROSS JOIN LATERAL (... LIMIT 1)` lets Postgres seek the existing
    /// (Token, ExchangeTimestamp) index once per token instead: measured at 1-16ms for the same
    /// 80-token lookup, a ~1000x improvement, because cost now scales with the (small, fixed)
    /// number of distinct tokens rather than with total table size.
    /// </summary>
    static Task<List<Tick>> LatestTicksAsync(NiftySignalDbContext db, string[] tokens) =>
        tokens.Length == 0
            ? Task.FromResult(new List<Tick>())
            : db.Ticks.FromSqlInterpolated($@"
                SELECT lt.* FROM unnest({tokens}) AS tok(token)
                CROSS JOIN LATERAL (
                    SELECT * FROM ticks t WHERE t.""Token"" = tok.token ORDER BY t.""ExchangeTimestamp"" DESC LIMIT 1
                ) lt")
                .AsNoTracking()
                .ToListAsync();

    /// <summary>
    /// Same as <see cref="LatestTicksAsync"/> but the earliest tick per token at or after
    /// <paramref name="sinceUtc"/> -- today's open, not a token's all-time-earliest tick (that
    /// was the bug: with no date floor, a token that already had ticks from a prior day, e.g.
    /// the spot index, returned an ancient tick as "today's open").
    /// </summary>
    static Task<List<Tick>> EarliestTicksAsync(NiftySignalDbContext db, string[] tokens, DateTimeOffset sinceUtc) =>
        tokens.Length == 0
            ? Task.FromResult(new List<Tick>())
            : db.Ticks.FromSqlInterpolated($@"
                SELECT lt.* FROM unnest({tokens}) AS tok(token)
                CROSS JOIN LATERAL (
                    SELECT * FROM ticks t WHERE t.""Token"" = tok.token AND t.""ExchangeTimestamp"" >= {sinceUtc} ORDER BY t.""ExchangeTimestamp"" ASC LIMIT 1
                ) lt")
                .AsNoTracking()
                .ToListAsync();

    /// <summary>
    /// Same as <see cref="LatestTicksAsync"/> but the latest tick at or before
    /// <paramref name="cutoff"/> and at or after <paramref name="sinceUtc"/> per token. The lower
    /// bound matters: with only an upper bound, a token with no tick between <paramref
    /// name="sinceUtc"/> and <paramref name="cutoff"/> would keep walking backward past it into
    /// a prior day's ticks instead of correctly finding none (the OI-lookback bug this was added
    /// for -- see <see cref="TodayIstMidnightUtc"/>'s doc comment).
    /// </summary>
    static Task<List<Tick>> LatestTicksAtOrBeforeAsync(NiftySignalDbContext db, string[] tokens, DateTimeOffset sinceUtc, DateTimeOffset cutoff) =>
        tokens.Length == 0
            ? Task.FromResult(new List<Tick>())
            : db.Ticks.FromSqlInterpolated($@"
                SELECT lt.* FROM unnest({tokens}) AS tok(token)
                CROSS JOIN LATERAL (
                    SELECT * FROM ticks t WHERE t.""Token"" = tok.token AND t.""ExchangeTimestamp"" <= {cutoff} AND t.""ExchangeTimestamp"" >= {sinceUtc} ORDER BY t.""ExchangeTimestamp"" DESC LIMIT 1
                ) lt")
                .AsNoTracking()
                .ToListAsync();

    /// <summary>
    /// Today's IST midnight, as the UTC instant EF/Npgsql needs for a timestamptz comparison
    /// (2026-09-09) -- the one floor every "today, not last-24h" query in this class shares.
    /// Before this, ClosedTrades used a rolling AddHours(-24) window (so a trade from yesterday
    /// evening was still "recent" hours into today), EarliestTicksAsync had no date filter at all
    /// (returning a token's all-time-earliest tick as "today's open" -- wrong the moment a token,
    /// e.g. the spot index, has ticks from a prior day), the OI 30-min lookback had no lower
    /// bound (silently comparing against yesterday's close for the first ~30 minutes of every
    /// session, before today has 30 real minutes of its own history), and the score-history chart
    /// bounded itself by count (Take(120)) rather than by day, so a session's first few minutes
    /// could pull in yesterday's tail-end snapshots. Same IST-midnight boundary
    /// MarketDataIngestionWorker.SeedEngineHistoryAsync already uses on the Host side.
    /// </summary>
    static DateTimeOffset TodayIstMidnightUtc() =>
        new DateTimeOffset(DateTimeOffset.UtcNow.ToIst().Date, IstTime.Offset).ToUniversalTime();

    // 91-day T-bill proxy -- same starting value as LiveFeatureEngine (plan 4.1).
    // Audit finding F21 fixed (2026-09-09): was a hardcoded const duplicated identically in
    // NiftySignal.Host/LiveFeatureEngine.cs; both now read the same-shaped "Pricing" config
    // section (PricingOptions, NiftySignal.Domain.Configuration) from their own appsettings.json
    // instead -- see PricingOptions' own doc comment for why this is two config entries kept in
    // sync by hand, not one shared source.
    readonly IOptionsMonitor<PricingOptions> _pricingOptions;
    double RiskFreeRate => _pricingOptions.CurrentValue.RiskFreeRate;

    public void Dispose() => _timer.Dispose();
}
