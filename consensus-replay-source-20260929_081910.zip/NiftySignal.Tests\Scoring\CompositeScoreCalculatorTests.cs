using NiftySignal.Scoring;

namespace NiftySignal.Tests.Scoring;

public class CompositeScoreCalculatorTests
{
    static readonly DateTimeOffset ComputedAt = new(2026, 9, 3, 10, 0, 0, TimeSpan.FromHours(5.5));

    static readonly ScoreComponentInputs FullyWarmInputs = new(
        OiBuildupNetZ: 1.0,
        PcrZ: -0.5,
        FuturesBasisZ: 0.8,
        IvSkewZ: -1.2,
        PriceMomentumZ: 2.0,
        DepthImbalanceZ: 0.3);

    [Fact]
    public void Calculate_MatchesManualComputation_ForFullyWarmInputs()
    {
        var weights = ScoreWeights.Default;

        var result = CompositeScoreCalculator.Calculate(FullyWarmInputs, weights, ComputedAt, k: 1.0);

        var expectedRaw = (weights.OiBuildupNet * 1.0) + (weights.Pcr * -0.5) + (weights.FuturesBasis * 0.8)
            + (weights.IvSkew * -1.2) + (weights.PriceMomentum * 2.0) + (weights.DepthImbalance * 0.3);
        var expectedScore = 100.0 * Math.Tanh(expectedRaw / 1.0);

        Assert.True(result.IsWarmedUp);
        Assert.NotNull(result.Score);
        Assert.Equal(expectedScore, result.Score.Value, 1e-9);
    }

    [Fact]
    public void Calculate_UsesRawOverride_InsteadOfRecomputingFromInputs_WhenSupplied()
    {
        // 2026-09-07: LiveFeatureEngine's multi-cadence smoothing feeds a caller-supplied raw
        // (the smoothed value) rather than letting Calculate derive it from inputs itself.
        var weights = ScoreWeights.Default;
        var withoutOverride = CompositeScoreCalculator.Calculate(FullyWarmInputs, weights, ComputedAt, k: 1.0);
        var withOverride = CompositeScoreCalculator.Calculate(FullyWarmInputs, weights, ComputedAt, k: 1.0, rawOverride: 0.0);

        Assert.NotEqual(withoutOverride.Score, withOverride.Score);
        // raw=0 with any positive k must tanh to exactly 0.
        Assert.Equal(0.0, withOverride.Score!.Value, 1e-9);
        // Warm-up and the per-component breakdown still come from inputs, not the override --
        // an override doesn't manufacture a score out of components that aren't ready.
        Assert.True(withOverride.IsWarmedUp);
        Assert.Equal(withoutOverride.Components, withOverride.Components);
    }

    [Fact]
    public void Calculate_RawOverrideDoesNotForceAScore_WhenInputsAreNotWarmedUp()
    {
        // An override must not bypass the "all six required components present" gate --
        // that gate is about whether the inputs are trustworthy, which a substituted raw
        // number can't fix.
        var weights = ScoreWeights.Default;
        var notWarm = FullyWarmInputs with { PcrZ = null };

        var result = CompositeScoreCalculator.Calculate(notWarm, weights, ComputedAt, k: 1.0, rawOverride: 5.0);

        Assert.False(result.IsWarmedUp);
        Assert.Null(result.Score);
    }

    // PriceMomentum deliberately excluded from this theory (audit finding F47, 2026-09-10):
    // its default weight is 0.0 (cut by F4), so it's now optional -- see the dedicated
    // Calculate_StillWarmsUp_WhenPriceMomentumZIsNull test below instead of asserting the
    // opposite of what F47 fixed.
    [Theory]
    [InlineData(true, false, false, false, false)]
    [InlineData(false, true, false, false, false)]
    [InlineData(false, false, true, false, false)]
    [InlineData(false, false, false, true, false)]
    [InlineData(false, false, false, false, true)]
    public void Calculate_ReturnsNullScore_WhenAnySingleNonzeroWeightComponentIsNotWarmedUp(
        bool missingOi, bool missingPcr, bool missingBasis, bool missingSkew, bool missingDepth)
    {
        var inputs = FullyWarmInputs with
        {
            OiBuildupNetZ = missingOi ? null : FullyWarmInputs.OiBuildupNetZ,
            PcrZ = missingPcr ? null : FullyWarmInputs.PcrZ,
            FuturesBasisZ = missingBasis ? null : FullyWarmInputs.FuturesBasisZ,
            IvSkewZ = missingSkew ? null : FullyWarmInputs.IvSkewZ,
            DepthImbalanceZ = missingDepth ? null : FullyWarmInputs.DepthImbalanceZ,
        };

        var result = CompositeScoreCalculator.Calculate(inputs, ScoreWeights.Default, ComputedAt);

        Assert.False(result.IsWarmedUp);
        Assert.Null(result.Score);
    }

    [Fact]
    public void Calculate_StillWarmsUp_WhenPriceMomentumZIsNull_BecauseItsWeightIsZero()
    {
        // Audit finding F47 (2026-09-10): PriceMomentum's weight was cut to 0.0 by F4, but it
        // stayed on the hardcoded required-six list -- a missing PriceMomentumZ could stall the
        // whole composite for a component that contributes exactly 0 to the score even when
        // present. Fixed: a component is now required iff its weight is nonzero (or it's
        // VixChange, which has its own separate name-based exception).
        var inputs = FullyWarmInputs with { PriceMomentumZ = null };

        var result = CompositeScoreCalculator.Calculate(inputs, ScoreWeights.Default, ComputedAt);

        Assert.True(result.IsWarmedUp);
        Assert.NotNull(result.Score);

        var momentumComponent = result.Components.Single(c => c.Name == "PriceMomentum");
        Assert.Null(momentumComponent.ZScore);
        Assert.Null(momentumComponent.WeightedContribution);
    }

    [Fact]
    public void DescribeMissingRequiredComponents_ExcludesPriceMomentum_EvenWhenItIsNull()
    {
        // Live-caught 2026-09-10 while validating this same day's F47 deploy:
        // MarketDataIngestionWorker's warm-up-blocked diagnostic log used a hardcoded six-name
        // list that kept blaming PriceMomentumZ for blocking warm-up even after F47 made it
        // optional -- actively misleading. Fixed by having that log call this shared method
        // instead of duplicating the required/optional rule. Both DepthImbalance (real,
        // nonzero weight -- genuinely still required) and PriceMomentum (weight 0.0 -- no
        // longer required) missing at once, to prove the method reports the former and not the
        // latter, not just "reports something."
        var inputs = FullyWarmInputs with { PriceMomentumZ = null, DepthImbalanceZ = null };

        var missing = CompositeScoreCalculator.DescribeMissingRequiredComponents(inputs, ScoreWeights.Default);

        Assert.Contains("DepthImbalance", missing);
        Assert.DoesNotContain("PriceMomentum", missing);
    }

    [Fact]
    public void DescribeMissingRequiredComponents_IsEmpty_WhenFullyWarm()
    {
        var missing = CompositeScoreCalculator.DescribeMissingRequiredComponents(FullyWarmInputs, ScoreWeights.Default);

        Assert.Empty(missing);
    }

    [Fact]
    public void Calculate_ReturnsNullScore_WhenNoComponentsAreWarmedUp()
    {
        var allNull = new ScoreComponentInputs(null, null, null, null, null, null);

        var result = CompositeScoreCalculator.Calculate(allNull, ScoreWeights.Default, ComputedAt);

        Assert.False(result.IsWarmedUp);
        Assert.Null(result.Score);
        Assert.All(result.Components, c => Assert.Null(c.ZScore));
    }

    [Fact]
    public void Calculate_IsAntisymmetric_NegatingEveryInputNegatesTheScore()
    {
        var negated = new ScoreComponentInputs(
            -FullyWarmInputs.OiBuildupNetZ, -FullyWarmInputs.PcrZ, -FullyWarmInputs.FuturesBasisZ,
            -FullyWarmInputs.IvSkewZ, -FullyWarmInputs.PriceMomentumZ, -FullyWarmInputs.DepthImbalanceZ);

        var positive = CompositeScoreCalculator.Calculate(FullyWarmInputs, ScoreWeights.Default, ComputedAt);
        var negative = CompositeScoreCalculator.Calculate(negated, ScoreWeights.Default, ComputedAt);

        Assert.Equal(-positive.Score!.Value, negative.Score!.Value, 1e-9);
    }

    [Fact]
    public void Calculate_ScoreStaysWithinBounds_EvenAtFullSaturation()
    {
        var maxedOut = new ScoreComponentInputs(3.0, 3.0, 3.0, 3.0, 3.0, 3.0);

        var result = CompositeScoreCalculator.Calculate(maxedOut, ScoreWeights.Default, ComputedAt);

        Assert.NotNull(result.Score);
        Assert.True(result.Score.Value < 100.0);
        Assert.True(result.Score.Value > 99.0); // should be close to saturated, e.g. ~99.5 at k=1
    }

    [Fact]
    public void Calculate_ClipsOutOfRangeZScores_BeforeWeighting()
    {
        // WelfordRollingWindow.ComputeZScore already clips to +/-3, but this method is
        // defensive: an out-of-range input should be clamped, not silently over-weighted.
        var withOutOfRangeZ = FullyWarmInputs with { PriceMomentumZ = 50.0 };
        var withClippedZ = FullyWarmInputs with { PriceMomentumZ = 3.0 };

        var actual = CompositeScoreCalculator.Calculate(withOutOfRangeZ, ScoreWeights.Default, ComputedAt);
        var expected = CompositeScoreCalculator.Calculate(withClippedZ, ScoreWeights.Default, ComputedAt);

        Assert.Equal(expected.Score!.Value, actual.Score!.Value, 1e-9);
    }

    [Fact]
    public void Calculate_PropagatesTheWeightSetVersion()
    {
        var weights = ScoreWeights.Default with { Version = "2026-09-03.custom" };

        var result = CompositeScoreCalculator.Calculate(FullyWarmInputs, weights, ComputedAt);

        Assert.Equal("2026-09-03.custom", result.WeightSetVersion);
    }

    [Fact]
    public void Calculate_ComponentBreakdown_ContainsAllFourteenNamedComponents()
    {
        var result = CompositeScoreCalculator.Calculate(FullyWarmInputs, ScoreWeights.Default, ComputedAt);

        var names = result.Components.Select(c => c.Name).ToHashSet();
        Assert.Equal(14, result.Components.Count);
        Assert.Contains("OiBuildupNet", names);
        Assert.Contains("Pcr", names);
        Assert.Contains("FuturesBasis", names);
        Assert.Contains("IvSkew", names);
        Assert.Contains("PriceMomentum", names);
        Assert.Contains("DepthImbalance", names);
        Assert.Contains("VixChange", names);
        Assert.Contains("GammaExposure", names);
        Assert.Contains("VolumePcr", names);
        Assert.Contains("SpreadRatio", names);
        Assert.Contains("VannaExposure", names);
        Assert.Contains("CharmExposure", names);
        Assert.Contains("CvdProxy", names);
        Assert.Contains("StraddleRichness", names);
    }

    [Fact]
    public void Calculate_StaysWarmedUp_WhenOnlyVixChangeZIsMissing()
    {
        // VixChangeZ is deliberately optional (2026-09-04) -- unlike the six required
        // components, its absence must not block the composite score.
        var inputs = FullyWarmInputs with { VixChangeZ = null };

        var result = CompositeScoreCalculator.Calculate(inputs, ScoreWeights.Default, ComputedAt);

        Assert.True(result.IsWarmedUp);
        Assert.NotNull(result.Score);
    }

    [Fact]
    public void Calculate_IncludesVixChangesWeightedContribution_WhenPresent()
    {
        var weights = ScoreWeights.Default;
        var inputs = FullyWarmInputs with { VixChangeZ = 1.5 };

        var result = CompositeScoreCalculator.Calculate(inputs, weights, ComputedAt, k: 1.0);

        var expectedRaw = (weights.OiBuildupNet * FullyWarmInputs.OiBuildupNetZ!.Value)
            + (weights.Pcr * FullyWarmInputs.PcrZ!.Value)
            + (weights.FuturesBasis * FullyWarmInputs.FuturesBasisZ!.Value)
            + (weights.IvSkew * FullyWarmInputs.IvSkewZ!.Value)
            + (weights.PriceMomentum * FullyWarmInputs.PriceMomentumZ!.Value)
            + (weights.DepthImbalance * FullyWarmInputs.DepthImbalanceZ!.Value)
            + (weights.VixChange * 1.5);
        var expectedScore = 100.0 * Math.Tanh(expectedRaw / 1.0);

        Assert.Equal(expectedScore, result.Score!.Value, 1e-9);
    }

    [Fact]
    public void Calculate_StaysWarmedUp_WhenOnlyGammaExposureZIsMissing()
    {
        // GammaExposureZ is deliberately optional too (2026-09-07, diagnostic-only -- see
        // ScoreWeights.Default's own weight of 0.0) -- its absence must not block the composite.
        var inputs = FullyWarmInputs with { GammaExposureZ = null };

        var result = CompositeScoreCalculator.Calculate(inputs, ScoreWeights.Default, ComputedAt);

        Assert.True(result.IsWarmedUp);
        Assert.NotNull(result.Score);
    }

    [Fact]
    public void Calculate_IncludesGammaExposuresWeightedContribution_WhenPresentAndWeighted()
    {
        // Default's GammaExposure weight is 0.0 (diagnostic-only), so this uses a nonzero
        // weight to verify the wiring itself, independent of the current live weight.
        var weights = ScoreWeights.Default with { GammaExposure = 0.08 };
        var inputs = FullyWarmInputs with { GammaExposureZ = -2.0 };

        var result = CompositeScoreCalculator.Calculate(inputs, weights, ComputedAt, k: 1.0);

        var expectedRaw = (weights.OiBuildupNet * FullyWarmInputs.OiBuildupNetZ!.Value)
            + (weights.Pcr * FullyWarmInputs.PcrZ!.Value)
            + (weights.FuturesBasis * FullyWarmInputs.FuturesBasisZ!.Value)
            + (weights.IvSkew * FullyWarmInputs.IvSkewZ!.Value)
            + (weights.PriceMomentum * FullyWarmInputs.PriceMomentumZ!.Value)
            + (weights.DepthImbalance * FullyWarmInputs.DepthImbalanceZ!.Value)
            + (weights.GammaExposure * -2.0);
        var expectedScore = 100.0 * Math.Tanh(expectedRaw / 1.0);

        Assert.Equal(expectedScore, result.Score!.Value, 1e-9);
    }

    [Fact]
    public void Calculate_StaysWarmedUp_WhenOnlyVolumePcrZIsMissing()
    {
        // VolumePcrZ is deliberately optional too (2026-09-07, diagnostic-only -- see
        // ScoreWeights.Default's own weight of 0.0) -- its absence must not block the composite.
        var inputs = FullyWarmInputs with { VolumePcrZ = null };

        var result = CompositeScoreCalculator.Calculate(inputs, ScoreWeights.Default, ComputedAt);

        Assert.True(result.IsWarmedUp);
        Assert.NotNull(result.Score);
    }

    [Fact]
    public void Calculate_IncludesVolumePcrsWeightedContribution_WhenPresentAndWeighted()
    {
        // Default's VolumePcr weight is 0.0 (diagnostic-only), so this uses a nonzero weight
        // to verify the wiring itself, independent of the current live weight.
        var weights = ScoreWeights.Default with { VolumePcr = 0.06 };
        var inputs = FullyWarmInputs with { VolumePcrZ = 1.8 };

        var result = CompositeScoreCalculator.Calculate(inputs, weights, ComputedAt, k: 1.0);

        var expectedRaw = (weights.OiBuildupNet * FullyWarmInputs.OiBuildupNetZ!.Value)
            + (weights.Pcr * FullyWarmInputs.PcrZ!.Value)
            + (weights.FuturesBasis * FullyWarmInputs.FuturesBasisZ!.Value)
            + (weights.IvSkew * FullyWarmInputs.IvSkewZ!.Value)
            + (weights.PriceMomentum * FullyWarmInputs.PriceMomentumZ!.Value)
            + (weights.DepthImbalance * FullyWarmInputs.DepthImbalanceZ!.Value)
            + (weights.VolumePcr * 1.8);
        var expectedScore = 100.0 * Math.Tanh(expectedRaw / 1.0);

        Assert.Equal(expectedScore, result.Score!.Value, 1e-9);
    }

    [Fact]
    public void Calculate_StaysWarmedUp_WhenOnlySpreadRatioZIsMissing()
    {
        // SpreadRatioZ is deliberately optional too (2026-09-07, diagnostic-only -- see
        // ScoreWeights.Default's own weight of 0.0) -- its absence must not block the composite.
        var inputs = FullyWarmInputs with { SpreadRatioZ = null };

        var result = CompositeScoreCalculator.Calculate(inputs, ScoreWeights.Default, ComputedAt);

        Assert.True(result.IsWarmedUp);
        Assert.NotNull(result.Score);
    }

    [Fact]
    public void Calculate_IncludesSpreadRatiosWeightedContribution_WhenPresentAndWeighted()
    {
        // Default's SpreadRatio weight is 0.0 (diagnostic-only), so this uses a nonzero weight
        // to verify the wiring itself, independent of the current live weight.
        var weights = ScoreWeights.Default with { SpreadRatio = 0.05 };
        var inputs = FullyWarmInputs with { SpreadRatioZ = -1.4 };

        var result = CompositeScoreCalculator.Calculate(inputs, weights, ComputedAt, k: 1.0);

        var expectedRaw = (weights.OiBuildupNet * FullyWarmInputs.OiBuildupNetZ!.Value)
            + (weights.Pcr * FullyWarmInputs.PcrZ!.Value)
            + (weights.FuturesBasis * FullyWarmInputs.FuturesBasisZ!.Value)
            + (weights.IvSkew * FullyWarmInputs.IvSkewZ!.Value)
            + (weights.PriceMomentum * FullyWarmInputs.PriceMomentumZ!.Value)
            + (weights.DepthImbalance * FullyWarmInputs.DepthImbalanceZ!.Value)
            + (weights.SpreadRatio * -1.4);
        var expectedScore = 100.0 * Math.Tanh(expectedRaw / 1.0);

        Assert.Equal(expectedScore, result.Score!.Value, 1e-9);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void Calculate_ThrowsForNonPositiveK(double k)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() =>
            CompositeScoreCalculator.Calculate(FullyWarmInputs, ScoreWeights.Default, ComputedAt, k));
    }

    [Fact]
    public void ComputeRaw_MatchesTheWeightedSumInsideCalculate()
    {
        var raw = CompositeScoreCalculator.ComputeRaw(FullyWarmInputs, ScoreWeights.Default);
        var viaCalculate = CompositeScoreCalculator.Calculate(FullyWarmInputs, ScoreWeights.Default, ComputedAt, k: 1.0);

        Assert.NotNull(raw);
        // 100*tanh(raw/1) == score at k=1, so raw is recoverable from the score for this check.
        Assert.Equal(100.0 * Math.Tanh(raw!.Value), viaCalculate.Score!.Value, 1e-9);
    }

    [Fact]
    public void ComputeRaw_ReturnsNull_WhenAnyComponentIsNotWarmedUp()
    {
        var raw = CompositeScoreCalculator.ComputeRaw(FullyWarmInputs with { PcrZ = null }, ScoreWeights.Default);

        Assert.Null(raw);
    }

    [Fact]
    public void DefaultWeights_AreThePlansSection6TableRescaledForVix_AndSumToOne()
    {
        // Plan section 6's 25/20/15/15/15/10, each x0.95, plus a conservative 0.05 for the
        // VixChange component (2026-09-04), then PriceMomentum cut 0.1425 -> 0.07 with the
        // freed 0.0725 moved to OiBuildupNet/DepthImbalance (2026-09-07), then PriceMomentum
        // cut again to 0.0 with the freed 0.07 split the same way (2026-09-09, F4, external
        // review) -- see ScoreWeights.Default's own doc comments.
        var weights = ScoreWeights.Default;

        Assert.Equal(0.3125, weights.OiBuildupNet, 1e-9);
        Assert.Equal(0.19, weights.Pcr, 1e-9);
        Assert.Equal(0.1425, weights.FuturesBasis, 1e-9);
        Assert.Equal(0.1425, weights.IvSkew, 1e-9);
        Assert.Equal(0.0, weights.PriceMomentum, 1e-9);
        Assert.Equal(0.1625, weights.DepthImbalance, 1e-9);
        Assert.Equal(0.05, weights.VixChange, 1e-9);
        Assert.Equal(0.0, weights.GammaExposure, 1e-9);
        Assert.Equal(0.0, weights.VolumePcr, 1e-9);
        Assert.Equal(0.0, weights.SpreadRatio, 1e-9);
        Assert.Equal(1.0, weights.Total, 1e-9);
    }
}
