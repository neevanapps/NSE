using NiftySignal.Domain.Entities;
using NiftySignal.Domain.Enums;
using NiftySignal.Domain.ValueObjects;
using NiftySignal.Features;
using NiftySignal.Host;
using NiftySignal.Pricing;
using NiftySignal.Scoring;

namespace NiftySignal.Tests.Host;

public class LiveFeatureEngineTests
{
    static readonly DateOnly AsOfDate = new(2026, 9, 4);
    static readonly DateOnly NearestExpiry = new(2026, 9, 8);
    static readonly DateTimeOffset Start = new(2026, 9, 4, 9, 30, 0, TimeSpan.FromHours(5.5));

    const string SpotToken = "26000";
    const string FutureToken = "68407";
    const string CallToken = "42637"; // strike 23950
    const string PutToken = "42638"; // strike 23950

    static Instrument Spot() => new()
    {
        Token = SpotToken,
        Exchange = Exchange.Nse,
        TradingSymbol = "Nifty 50",
        InstrumentType = InstrumentType.Index,
        Underlying = "NIFTY",
        LotSize = 1,
        TickSize = 0.05m,
        AsOfDate = AsOfDate,
    };

    static Instrument Future() => new()
    {
        Token = FutureToken,
        Exchange = Exchange.Nfo,
        TradingSymbol = "NIFTY08SEP26F",
        InstrumentType = InstrumentType.Future,
        ExpiryDate = NearestExpiry,
        Underlying = "NIFTY",
        LotSize = 65,
        TickSize = 0.05m,
        AsOfDate = AsOfDate,
    };

    static Instrument Option(string token, OptionType type, decimal strike) => new()
    {
        Token = token,
        Exchange = Exchange.Nfo,
        TradingSymbol = $"NIFTY08SEP26{(type == OptionType.Call ? "C" : "P")}{strike:0}",
        InstrumentType = InstrumentType.Option,
        OptionType = type,
        StrikePrice = strike,
        ExpiryDate = NearestExpiry,
        Underlying = "NIFTY",
        LotSize = 65,
        TickSize = 0.05m,
        AsOfDate = AsOfDate,
    };

    static List<Instrument> BaseUniverse() =>
    [
        Spot(),
        Future(),
        Option(CallToken, OptionType.Call, 23950m),
        Option(PutToken, OptionType.Put, 23950m),
    ];

    static Tick MakeTick(string token, decimal lastPrice, DateTimeOffset at, long? oi = null, MarketDepth? depth = null, long volume = 0) => new()
    {
        Token = token,
        Exchange = Exchange.Nfo,
        ExchangeTimestamp = at,
        ReceivedAt = at,
        LastPrice = lastPrice,
        Volume = volume,
        OpenInterest = oi,
        Depth = depth,
    };

    static MarketDepth Depth(long bidQty, long askQty, decimal bid = 100m, decimal ask = 101m) => new(
        Bid1Price: bid, Bid1Qty: bidQty, Bid2Price: 0, Bid2Qty: 0, Bid3Price: 0, Bid3Qty: 0, Bid4Price: 0, Bid4Qty: 0, Bid5Price: 0, Bid5Qty: 0,
        Ask1Price: ask, Ask1Qty: askQty, Ask2Price: 0, Ask2Qty: 0, Ask3Price: 0, Ask3Qty: 0, Ask4Price: 0, Ask4Qty: 0, Ask5Price: 0, Ask5Qty: 0);

    [Fact]
    public void ComputeCadence_ReturnsNull_BeforeSpotAndFutureHaveTicks()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());

        Assert.Null(engine.ComputeCadence(Start));
    }

    [Fact]
    public void ComputeCadence_ReturnsNull_WhenOnlySpotHasTicked()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));

        Assert.Null(engine.ComputeCadence(Start));
    }

    [Fact]
    public void ComputeCadence_ComputesFuturesBasis_AsFutureMidMinusSpot()
    {
        // Basis is the real monthly future's own mid minus spot mid (2026-09-09 external
        // review, reverting audit finding F11's original fix -- see the ParityGapRaw test
        // below for the synthetic-forward-based diagnostic that replaced the reverted
        // version). Two engines differing only in the future's price must produce genuinely
        // different basis readings -- the opposite assertion from before this revert.
        var engineA = new LiveFeatureEngine(BaseUniverse());
        engineA.OnTick(MakeTick(SpotToken, 23950m, Start));
        engineA.OnTick(MakeTick(FutureToken, 24028.35m, Start));
        engineA.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 99.5m, ask: 100.5m)));
        engineA.OnTick(MakeTick(PutToken, 80m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 79.5m, ask: 80.5m)));

        var engineB = new LiveFeatureEngine(BaseUniverse());
        engineB.OnTick(MakeTick(SpotToken, 23950m, Start));
        engineB.OnTick(MakeTick(FutureToken, 23200m, Start)); // wildly different future price
        engineB.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 99.5m, ask: 100.5m)));
        engineB.OnTick(MakeTick(PutToken, 80m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 79.5m, ask: 80.5m)));

        var snapshotA = engineA.ComputeCadence(Start);
        var snapshotB = engineB.ComputeCadence(Start);

        Assert.NotNull(snapshotA);
        Assert.NotNull(snapshotB);
        Assert.Equal(24028.35 - 23950, snapshotA!.FuturesBasisRaw!.Value, precision: 6);
        Assert.Equal(23200 - 23950, snapshotB!.FuturesBasisRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCadence_ComputesParityGap_AsSyntheticForwardMinusSpot_IndependentOfTheTrackedFuture()
    {
        // ParityGapRaw (2026-09-09 review, new alongside the F11 revert above): synthetic
        // forward via put-call parity minus spot -- a quote-quality diagnostic, deliberately
        // independent of the tracked future's own price (unlike FuturesBasisRaw above). This
        // is exactly the assertion FuturesBasisRaw itself carried before the revert.
        var engineA = new LiveFeatureEngine(BaseUniverse());
        engineA.OnTick(MakeTick(SpotToken, 23950m, Start));
        engineA.OnTick(MakeTick(FutureToken, 24028.35m, Start)); // deliberately far from spot
        engineA.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 99.5m, ask: 100.5m)));
        engineA.OnTick(MakeTick(PutToken, 80m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 79.5m, ask: 80.5m)));

        var engineB = new LiveFeatureEngine(BaseUniverse());
        engineB.OnTick(MakeTick(SpotToken, 23950m, Start));
        engineB.OnTick(MakeTick(FutureToken, 23200m, Start)); // wildly different future price
        engineB.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 99.5m, ask: 100.5m)));
        engineB.OnTick(MakeTick(PutToken, 80m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 79.5m, ask: 80.5m)));

        var snapshotA = engineA.ComputeCadence(Start);
        var snapshotB = engineB.ComputeCadence(Start);

        Assert.NotNull(snapshotA);
        Assert.NotNull(snapshotB);
        Assert.NotEqual(0, snapshotA!.ParityGapRaw!.Value, 6);
        Assert.Equal(snapshotA.ParityGapRaw!.Value, snapshotB!.ParityGapRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCadence_UsesFutureMidPrice_NotBouncingLastPrice_ForMomentum()
    {
        // Regression for a live-caught bug (2026-09-07): the future's last-traded price was
        // observed alternating between two levels several points apart within seconds -- not
        // genuine price discovery. Mid (bid+ask)/2 is stable against that kind of bounce.
        // (FuturesBasis no longer reads the future's price at all -- see F11 above -- so this
        // now covers PriceMomentum, the one remaining consumer of the future's mid price.)
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));
        engine.OnTick(MakeTick(FutureToken, 23905m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 24000m, ask: 24002m)));
        engine.ComputeCadence(Start);

        // Second cadence 15s later: LTP bounces (the live-caught symptom), mid barely moves.
        engine.OnTick(MakeTick(FutureToken, 23906m, Start.AddSeconds(15), depth: Depth(bidQty: 10, askQty: 10, bid: 24001m, ask: 24003m)));
        var snapshot = engine.ComputeCadence(Start.AddSeconds(15));

        // Mid moved from 24001 to 24002 -- momentum should read +1 against that, not whatever
        // the bouncing LastPrice implies.
        Assert.NotNull(snapshot);
        Assert.Equal(1.0, snapshot!.PriceMomentumRaw!.Value, precision: 2);
    }

    [Fact]
    public void ComputeCadence_ComputesPcr_AsPutOiOverCallOi()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 870_000));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.Equal(0.87, snapshot!.PcrRaw!.Value, precision: 2);
    }

    [Fact]
    public void ComputeCadence_Pcr_ExcludesStrikesOutsideThePersistedBand()
    {
        // Audit finding F5 (2026-09-08): Pcr must do the OPPOSITE of GammaExposure/VolumePcr --
        // those two are deliberately full-chain (see their own "not just a persisted band"
        // tests); Pcr is deliberately restricted, since a full-chain sum was dominated by
        // enormous OI sitting on far strikes that has nothing to do with today's positioning.
        const string FarPutToken = "99010";
        // PersistedStrikeBand=2 means "5 nearest distinct strikes" -- need at least 6 distinct
        // strikes total for that selection to genuinely exclude one, so four untraded filler
        // strikes sit between spot and the deliberately far one (their presence as instruments
        // is what matters here, not any tick data on them).
        var universe = BaseUniverse();
        universe.Add(Option("99006", OptionType.Call, 24000m));
        universe.Add(Option("99007", OptionType.Call, 24050m));
        universe.Add(Option("99008", OptionType.Call, 24100m));
        universe.Add(Option("99009", OptionType.Call, 24150m));
        universe.Add(Option(FarPutToken, OptionType.Put, 25000m)); // 1050 points from spot -- the 6th, farthest strike

        var withFarOi = new LiveFeatureEngine(universe);
        withFarOi.OnTick(MakeTick(SpotToken, 23950m, Start));
        withFarOi.OnTick(MakeTick(FutureToken, 24000m, Start));
        withFarOi.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000));
        withFarOi.OnTick(MakeTick(PutToken, 80m, Start, oi: 870_000));
        withFarOi.OnTick(MakeTick(FarPutToken, 5m, Start, oi: 50_000_000)); // enormous, if it counted would swamp the ratio

        var withoutFarOi = new LiveFeatureEngine(universe);
        withoutFarOi.OnTick(MakeTick(SpotToken, 23950m, Start));
        withoutFarOi.OnTick(MakeTick(FutureToken, 24000m, Start));
        withoutFarOi.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000));
        withoutFarOi.OnTick(MakeTick(PutToken, 80m, Start, oi: 870_000));
        withoutFarOi.OnTick(MakeTick(FarPutToken, 5m, Start, oi: 0));

        var withFar = withFarOi.ComputeCadence(Start);
        var withoutFar = withoutFarOi.ComputeCadence(Start);

        Assert.NotNull(withFar);
        Assert.NotNull(withoutFar);
        Assert.Equal(withoutFar!.PcrRaw!.Value, withFar!.PcrRaw!.Value, precision: 9);
    }

    [Fact]
    public void ComputeCadence_ComputesDepthImbalance_FromNearestTwoStrikesOnly_ExcludingFartherOnes()
    {
        const string MediumCallToken = "99000";
        const string FarCallToken = "99001";
        var universe = BaseUniverse();
        // Three distinct strikes total (23950/24450/25000) so "nearest 2" genuinely
        // excludes the third (25000) instead of trivially including everything there is.
        universe.Add(Option(MediumCallToken, OptionType.Call, 24450m));
        universe.Add(Option(FarCallToken, OptionType.Call, 25000m));

        var engine = new LiveFeatureEngine(universe);
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 500, askQty: 400)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, depth: Depth(bidQty: 300, askQty: 600)));
        engine.OnTick(MakeTick(MediumCallToken, 40m, Start, depth: Depth(bidQty: 200, askQty: 200)));
        engine.OnTick(MakeTick(FarCallToken, 5m, Start, depth: Depth(bidQty: 9_000, askQty: 1)));

        var snapshot = engine.ComputeCadence(Start);

        // Calls at the 2 nearest strikes (23950, 24450): bid=500+200=700, ask=400+200=600 --
        // callImbalance = 100/1300. Puts at those same 2 strikes (only 23950 has one):
        // bid=300, ask=600 -- putImbalance = -300/900. Result = callImbalance - putImbalance.
        // The far strike's 9000/1 call depth would dominate the call side (and the result) if
        // it weren't excluded by "nearest 2".
        Assert.NotNull(snapshot);
        Assert.Equal((100.0 / 1300.0) - (-300.0 / 900.0), snapshot!.DepthImbalanceRaw!.Value, precision: 9);
    }

    [Fact]
    public void ComputeCadence_DepthImbalance_ReadsNeutral_WhenBothCallAndPutBooksAreEquallyBidHeavy()
    {
        // Audit finding F2 (2026-09-08): a call book bid-heavy is bullish (buying calls); a put
        // book bid-heavy is bearish (buying puts). Summing both sides together before
        // normalizing (the pre-fix formula) would have read this as +0.2, strongly bullish, when
        // nothing directional is actually happening -- differencing each side's own imbalance
        // correctly cancels it to zero.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 600, askQty: 400)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, depth: Depth(bidQty: 600, askQty: 400)));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.Equal(0.0, snapshot!.DepthImbalanceRaw!.Value, precision: 9);
    }

    [Fact]
    public void ComputeCadence_ComputesGammaExposure_AcrossTheFullChain_NotJustAPersistedBand()
    {
        // Same three-strike layout as the DepthImbalance "excludes farther ones" test above,
        // but GammaExposure must do the OPPOSITE: BuildStrikeSnapshots' PersistedStrikeBand (2,
        // i.e. nearest 5 strikes) is a *persistence* concern, unrelated to what this component
        // aggregates over. A strike 1050 points from spot -- nowhere near any plausible band --
        // must still move the aggregate, or GammaExposure would be exactly as band-limited as
        // the day-one attempt that made the metric impossible to evaluate in the first place.
        const string MediumCallToken = "99000";
        const string FarCallToken = "99001";
        var universeWithFarOi = BaseUniverse();
        universeWithFarOi.Add(Option(MediumCallToken, OptionType.Call, 24450m));
        universeWithFarOi.Add(Option(FarCallToken, OptionType.Call, 25000m));

        var withFarOi = new LiveFeatureEngine(universeWithFarOi);
        withFarOi.OnTick(MakeTick(SpotToken, 23950m, Start));
        withFarOi.OnTick(MakeTick(FutureToken, 24000m, Start));
        withFarOi.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(bidQty: 500, askQty: 400, bid: 99.5m, ask: 100.5m)));
        withFarOi.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(bidQty: 300, askQty: 600, bid: 79.5m, ask: 80.5m)));
        withFarOi.OnTick(MakeTick(MediumCallToken, 40m, Start, oi: 50_000, depth: Depth(bidQty: 200, askQty: 200, bid: 39.5m, ask: 40.5m)));
        // Far strike: touchline OI only, deliberately no depth -- proves GEX doesn't need a
        // live two-sided quote for a strike to count, only its OpenInterest.
        withFarOi.OnTick(MakeTick(FarCallToken, 5m, Start, oi: 900_000));

        var universeNoFarOi = BaseUniverse();
        universeNoFarOi.Add(Option(MediumCallToken, OptionType.Call, 24450m));
        universeNoFarOi.Add(Option(FarCallToken, OptionType.Call, 25000m));

        var withoutFarOi = new LiveFeatureEngine(universeNoFarOi);
        withoutFarOi.OnTick(MakeTick(SpotToken, 23950m, Start));
        withoutFarOi.OnTick(MakeTick(FutureToken, 24000m, Start));
        withoutFarOi.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(bidQty: 500, askQty: 400, bid: 99.5m, ask: 100.5m)));
        withoutFarOi.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(bidQty: 300, askQty: 600, bid: 79.5m, ask: 80.5m)));
        withoutFarOi.OnTick(MakeTick(MediumCallToken, 40m, Start, oi: 50_000, depth: Depth(bidQty: 200, askQty: 200, bid: 39.5m, ask: 40.5m)));
        withoutFarOi.OnTick(MakeTick(FarCallToken, 5m, Start, oi: 0));

        var withFar = withFarOi.ComputeCadence(Start);
        var withoutFar = withoutFarOi.ComputeCadence(Start);

        Assert.NotNull(withFar!.GammaExposureRaw);
        Assert.NotNull(withoutFar!.GammaExposureRaw);
        Assert.NotEqual(withoutFar.GammaExposureRaw!.Value, withFar.GammaExposureRaw!.Value);
    }

    [Fact]
    public void ComputeCadence_ComputesVannaAndCharmExposure_WheneverGammaExposureIsAvailable()
    {
        // Same ATM-reference-vol gate as GammaExposure (ComputeVannaExposure/ComputeCharmExposure
        // are called right alongside it in ComputeCadence, reusing the same solve) -- whenever
        // GEX produces a value, these two must as well.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(bidQty: 500, askQty: 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(bidQty: 300, askQty: 600, bid: 79.5m, ask: 80.5m)));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot!.GammaExposureRaw);
        Assert.NotNull(snapshot.VannaExposureRaw);
        Assert.NotNull(snapshot.CharmExposureRaw);
        Assert.True(double.IsFinite(snapshot.VannaExposureRaw!.Value));
        Assert.True(double.IsFinite(snapshot.CharmExposureRaw!.Value));
    }

    [Fact]
    public void ComputeCadence_IvRank_IsNull_OnTheFirstCadence_NotEnoughHistoryToRankAgainst()
    {
        // Audit finding F3: a single observation (or a perfectly flat window) can't produce a
        // meaningful rank -- null, not a fabricated "neutral 50".
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(bidQty: 500, askQty: 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(bidQty: 300, askQty: 600, bid: 79.5m, ask: 80.5m)));

        var snapshot = engine.ComputeCadence(Start);

        Assert.Null(snapshot!.IvRankRaw);
    }

    [Fact]
    public void ComputeCadence_IvRank_SitsAtAnExtreme_WithOnlyTwoObservationsInTheWindow()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(bidQty: 500, askQty: 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(bidQty: 300, askQty: 600, bid: 79.5m, ask: 80.5m)));
        engine.ComputeCadence(Start);

        // Richer option prices this cadence imply a different (higher) solved IV -- a second,
        // distinct observation to rank against.
        engine.OnTick(MakeTick(CallToken, 150m, Start.AddSeconds(15), oi: 100_000, depth: Depth(bidQty: 500, askQty: 400, bid: 149.5m, ask: 150.5m)));
        engine.OnTick(MakeTick(PutToken, 130m, Start.AddSeconds(15), oi: 100_000, depth: Depth(bidQty: 300, askQty: 600, bid: 129.5m, ask: 130.5m)));
        var snapshot = engine.ComputeCadence(Start.AddSeconds(15));

        // With only two points in the window, the latest one is necessarily either the new min
        // or the new max -- rank must land exactly at 0 or 100, not somewhere in between.
        Assert.NotNull(snapshot!.IvRankRaw);
        Assert.True(snapshot.IvRankRaw is 0.0 or 100.0);
        Assert.Equal(0, snapshot.IvRankSessionCount);
    }

    [Fact]
    public void IvRankSessionCount_IsZero_BeforeAnyPriorSessionHistoryIsSeeded()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());

        Assert.Equal(0, engine.IvRankSessionCount);
    }

    [Fact]
    public void ComputeCadence_IvRank_UsesPriorSessionDistribution_OnceFiveSessionsAreSeeded()
    {
        // 2026-09-09 review amendment to F3: once >= 5 prior sessions are seeded, IvRankRaw
        // ranks against that fixed distribution starting from the very first cadence of the
        // day -- no longer gated behind accumulating 2 same-day observations first (contrast
        // with the unseeded cold-start test above, which is null on its first cadence).
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.SeedPriorSessionIvHistory([0.10, 0.12, 0.14, 0.16, 0.18]);
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(bidQty: 500, askQty: 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(bidQty: 300, askQty: 600, bid: 79.5m, ask: 80.5m)));

        var snapshot = engine.ComputeCadence(Start);

        Assert.Equal(5, engine.IvRankSessionCount);
        Assert.Equal(5, snapshot!.IvRankSessionCount);
        Assert.NotNull(snapshot.IvRankRaw);
    }

    [Fact]
    public void ComputeCadence_CvdProxy_ReadsBuyLeaningCallVolume_AsBullish()
    {
        // LTP at/above the bid/ask midpoint classifies this cadence's traded call volume as
        // buy-leaning -- bullish, same sign convention as OiBuildupNetRaw.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, volume: 1_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, volume: 500, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));
        engine.ComputeCadence(Start);

        // Call: 200 more traded, LTP 100.5 >= midpoint 100.0 -- buy-leaning.
        // Put: volume unchanged (delta 0) -- excluded, isolating the signal to the call.
        engine.OnTick(MakeTick(CallToken, 100.5m, Start.AddSeconds(15), oi: 100_000, volume: 1_200, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start.AddSeconds(15), oi: 100_000, volume: 500, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));

        var second = engine.ComputeCadence(Start.AddSeconds(15));

        Assert.Equal(200.0, second!.CvdProxyRaw);
    }

    [Fact]
    public void ComputeCadence_CvdProxy_ReadsSellLeaningCallVolume_AsBearish()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, volume: 1_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, volume: 500, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));
        engine.ComputeCadence(Start);

        // LTP 99.5 < midpoint 100.0 -- sell-leaning, so the call's contribution flips negative.
        engine.OnTick(MakeTick(CallToken, 99.5m, Start.AddSeconds(15), oi: 100_000, volume: 1_200, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start.AddSeconds(15), oi: 100_000, volume: 500, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));

        var second = engine.ComputeCadence(Start.AddSeconds(15));

        Assert.Equal(-200.0, second!.CvdProxyRaw);
    }

    [Fact]
    public void ComputeCadence_ComputesGammaFlipLevel_AsTheZeroCrossingBetweenNetNegativeAndNetPositiveStrikes()
    {
        // A far put-only strike (net GEX negative there) and a far call-only strike (net GEX
        // positive there), spaced widely enough that each dominates its own end of the range --
        // guarantees a sign flip for ComputeGammaFlipLevel to interpolate across.
        const string PutOnlyToken = "88001";
        const string CallOnlyToken = "88002";
        var universe = BaseUniverse();
        universe.Add(Option(PutOnlyToken, OptionType.Put, 23800m));
        universe.Add(Option(CallOnlyToken, OptionType.Call, 24100m));

        var engine = new LiveFeatureEngine(universe);
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 1_000, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));
        engine.OnTick(MakeTick(PutOnlyToken, 10m, Start, oi: 1_000_000));
        engine.OnTick(MakeTick(CallOnlyToken, 10m, Start, oi: 1_000_000));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot!.GammaFlipLevel);
        Assert.InRange(snapshot.GammaFlipLevel!.Value, 23800.0, 24100.0);
    }

    [Fact]
    public void ComputeCadence_GammaFlipLevel_IsNull_WhenNoSignFlipExistsAcrossTrackedStrikes()
    {
        // Two strikes, both call-only (Put OI zeroed out) -- net GEX is positive everywhere on
        // the grid, so there is genuinely no crossing to find, not merely "fewer than 2 strikes".
        const string SecondCallToken = "88003";
        var universe = BaseUniverse();
        universe.Add(Option(SecondCallToken, OptionType.Call, 24100m));

        var engine = new LiveFeatureEngine(universe);
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 0));
        engine.OnTick(MakeTick(SecondCallToken, 10m, Start, oi: 500_000));

        var snapshot = engine.ComputeCadence(Start);

        Assert.Null(snapshot!.GammaFlipLevel);
    }

    [Fact]
    public void ComputeCadence_StraddleRichness_IsNull_OnTheFirstCadence()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));

        var snapshot = engine.ComputeCadence(Start);

        Assert.Null(snapshot!.StraddleRichnessRaw);
    }

    [Fact]
    public void ComputeCadence_StraddleRichness_IsNonNull_OnASecondCadenceAtTheSameAtmStrike()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));
        engine.ComputeCadence(Start);

        engine.OnTick(MakeTick(SpotToken, 23955m, Start.AddSeconds(15)));
        engine.OnTick(MakeTick(FutureToken, 24005m, Start.AddSeconds(15)));
        engine.OnTick(MakeTick(CallToken, 102m, Start.AddSeconds(15), oi: 100_000, depth: Depth(500, 400, bid: 101.5m, ask: 102.5m)));
        engine.OnTick(MakeTick(PutToken, 78m, Start.AddSeconds(15), oi: 100_000, depth: Depth(300, 600, bid: 77.5m, ask: 78.5m)));

        var second = engine.ComputeCadence(Start.AddSeconds(15));

        Assert.NotNull(second!.StraddleRichnessRaw);
        Assert.True(double.IsFinite(second.StraddleRichnessRaw!.Value));
    }

    [Fact]
    public void ComputeCadence_StraddleRichness_IsNull_WhenTheAtmStrikeRollsToADifferentStrike()
    {
        // Comparing two different straddles' prices would be meaningless -- must be null, not a
        // fabricated comparison, exactly like ComputeOiBuildupNet's stale-gap case.
        const string FarCallToken = "88010";
        const string FarPutToken = "88011";
        var universe = BaseUniverse();
        universe.Add(Option(FarCallToken, OptionType.Call, 24200m));
        universe.Add(Option(FarPutToken, OptionType.Put, 24200m));

        var engine = new LiveFeatureEngine(universe);
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 100_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 100_000, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));
        engine.OnTick(MakeTick(FarCallToken, 5m, Start, oi: 100_000, depth: Depth(500, 400, bid: 4.5m, ask: 5.5m)));
        engine.OnTick(MakeTick(FarPutToken, 250m, Start, oi: 100_000, depth: Depth(300, 600, bid: 249.5m, ask: 250.5m)));
        engine.ComputeCadence(Start); // ATM = 23950, the nearest strike to spot 23950.

        // Push spot right onto the far strike -- now that one is nearest, a genuine roll.
        engine.OnTick(MakeTick(SpotToken, 24200m, Start.AddSeconds(15)));
        engine.OnTick(MakeTick(FutureToken, 24250m, Start.AddSeconds(15)));
        engine.OnTick(MakeTick(CallToken, 250m, Start.AddSeconds(15), oi: 100_000, depth: Depth(500, 400, bid: 249.5m, ask: 250.5m)));
        engine.OnTick(MakeTick(PutToken, 5m, Start.AddSeconds(15), oi: 100_000, depth: Depth(300, 600, bid: 4.5m, ask: 5.5m)));
        engine.OnTick(MakeTick(FarCallToken, 100m, Start.AddSeconds(15), oi: 100_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(FarPutToken, 80m, Start.AddSeconds(15), oi: 100_000, depth: Depth(300, 600, bid: 79.5m, ask: 80.5m)));

        var second = engine.ComputeCadence(Start.AddSeconds(15));

        Assert.Null(second!.StraddleRichnessRaw);
    }

    [Fact]
    public void ComputeCadence_ComputesVolumePcr_AsNotionalNotContractCount_AcrossTheFullChain()
    {
        // A strike far outside any plausible persisted band, same reasoning as the GammaExposure
        // full-chain test above -- VolumePcr must include it too, not just the near strikes.
        const string FarPutToken = "99002";
        var universe = BaseUniverse();
        universe.Add(Option(FarPutToken, OptionType.Put, 25000m));

        var engine = new LiveFeatureEngine(universe);
        var t0 = Start;
        engine.OnTick(MakeTick(SpotToken, 23950m, t0));
        engine.OnTick(MakeTick(FutureToken, 24000m, t0));
        engine.OnTick(MakeTick(CallToken, 100m, t0, volume: 1000, depth: Depth(bidQty: 1, askQty: 1, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, t0, volume: 1000, depth: Depth(bidQty: 1, askQty: 1, bid: 79.5m, ask: 80.5m)));
        engine.OnTick(MakeTick(FarPutToken, 5m, t0, volume: 500));

        // First cadence: no prior volume baseline yet -- must be null, not a fabricated delta.
        var first = engine.ComputeCadence(t0);
        Assert.Null(first!.VolumePcrRaw);

        var t1 = t0.AddSeconds(15);
        engine.OnTick(MakeTick(SpotToken, 23950m, t1));
        engine.OnTick(MakeTick(FutureToken, 24000m, t1));
        engine.OnTick(MakeTick(CallToken, 100m, t1, volume: 1200, depth: Depth(bidQty: 1, askQty: 1, bid: 99.5m, ask: 100.5m))); // +200 @ mid 100
        engine.OnTick(MakeTick(PutToken, 80m, t1, volume: 1100, depth: Depth(bidQty: 1, askQty: 1, bid: 79.5m, ask: 80.5m)));   // +100 @ mid 80
        engine.OnTick(MakeTick(FarPutToken, 5m, t1, volume: 800));                                                              // +300 @ 5 (no depth -- LTP fallback)

        var second = engine.ComputeCadence(t1);

        // Call notional = 200 * 100 = 20,000. Put notional = (100*80) + (300*5) = 9,500.
        // A count-weighted or band-limited ratio would both give a different number (0.5 count,
        // 0.4 notional-but-band-limited) -- 0.475 only comes out if it's notional AND full-chain.
        Assert.NotNull(second!.VolumePcrRaw);
        Assert.Equal(9_500.0 / 20_000.0, second.VolumePcrRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCadence_ComputesSpreadRatio_AsPutOverCall_AcrossTheFullChain()
    {
        // Same "far strike must still count" shape as the GammaExposure/VolumePcr full-chain
        // tests above. Near strikes (23950) alone would give ratio 2.5/2.0 = 1.25 -- the far
        // strike (25000, wide and illiquid, spread% dominated by a tiny mid) must pull that
        // number away from 1.25, or this is secretly band-limited after all.
        const string FarCallToken = "99003";
        const string FarPutToken = "99004";
        var universe = BaseUniverse();
        universe.Add(Option(FarCallToken, OptionType.Call, 25000m));
        universe.Add(Option(FarPutToken, OptionType.Put, 25000m));

        var engine = new LiveFeatureEngine(universe);
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 1, askQty: 1, bid: 99m, ask: 101m)));   // spread 2, mid 100 -> 2.0%
        engine.OnTick(MakeTick(PutToken, 80m, Start, depth: Depth(bidQty: 1, askQty: 1, bid: 79m, ask: 81m)));      // spread 2, mid 80 -> 2.5%
        engine.OnTick(MakeTick(FarCallToken, 5m, Start, depth: Depth(bidQty: 1, askQty: 1, bid: 4m, ask: 6m)));     // spread 2, mid 5 -> 40%
        engine.OnTick(MakeTick(FarPutToken, 5m, Start, depth: Depth(bidQty: 1, askQty: 1, bid: 4.5m, ask: 5.5m)));  // spread 1, mid 5 -> 20%

        var snapshot = engine.ComputeCadence(Start);

        // callMean = (2.0 + 40) / 2 = 21.0; putMean = (2.5 + 20) / 2 = 11.25; ratio = 11.25/21.0.
        Assert.NotNull(snapshot!.SpreadRatioRaw);
        Assert.Equal(11.25 / 21.0, snapshot.SpreadRatioRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCadence_SkipsOiBuildupNet_WhenTheGapSinceTheLastCadenceExceedsNormalSpacing()
    {
        // Regression for a live-caught bug (2026-09-07): after a feed reconnect, "the last
        // cadence" could be 60-90+ seconds old instead of the normal ~15s, so the OI delta
        // would really represent several cadences' worth of change bunched into one -- which
        // read as a spurious extreme z-score against a window calibrated for normal 15s
        // deltas. The cadence right after a gap like that must report no OiBuildupNet reading
        // at all rather than a misleading one.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 900_000));
        var first = engine.ComputeCadence(Start);
        Assert.NotNull(first);

        // A big, real OI change -- but arriving 90 seconds later, well past the normal ~15s
        // cadence spacing (simulating a reconnect gap).
        var afterGap = Start.AddSeconds(90);
        engine.OnTick(MakeTick(SpotToken, 23900m, afterGap));
        engine.OnTick(MakeTick(FutureToken, 24000m, afterGap));
        engine.OnTick(MakeTick(CallToken, 100m, afterGap, oi: 1_500_000));
        engine.OnTick(MakeTick(PutToken, 80m, afterGap, oi: 1_200_000));
        var afterReconnect = engine.ComputeCadence(afterGap);

        Assert.NotNull(afterReconnect);
        Assert.Null(afterReconnect!.OiBuildupNetRaw);

        // The next cadence, back to normal ~15s spacing, must compute normally again.
        var normalNext = afterGap.AddSeconds(15);
        engine.OnTick(MakeTick(SpotToken, 23900m, normalNext));
        engine.OnTick(MakeTick(FutureToken, 24000m, normalNext));
        engine.OnTick(MakeTick(CallToken, 100m, normalNext, oi: 1_500_000));
        engine.OnTick(MakeTick(PutToken, 80m, normalNext, oi: 1_200_000));
        var resumed = engine.ComputeCadence(normalNext);

        Assert.NotNull(resumed);
        Assert.NotNull(resumed!.OiBuildupNetRaw);
    }

    [Fact]
    public void ComputeCadence_OiBuildupNet_WeighsEachStrikeByOiChangeMagnitude_NotAFlatVote()
    {
        // Audit finding F7 (2026-09-08): under the old flat +/-1 vote, a small bullish call
        // buildup and a much larger bearish put buildup would have exactly canceled (net 0) --
        // a 200-contract strike counted as loud as a 500,000-contract one, on the component
        // carrying the single largest weight in the composite. Weighted by |OI change|, the
        // far larger put buildup correctly dominates instead.
        //
        // Spans FeatureWindowLengths.OiComparisonWindow, not just one 15s cadence (audit
        // finding F50, 2026-09-10): ComputeOiBuildupNet now compares OI against ~that long ago,
        // not the previous cadence, matching how NSE/the broker actually refresh OI (~3
        // minutes, not every 15s) -- see OiLookbackWindow. Ticks every 15s throughout (real
        // cadence spacing, not one big jump) with OI held flat -- ComputeOiBuildupNet's own
        // MaxCadenceGapForOiBuildup guard rejects a single >20s gap as looking like a feed
        // outage, same as production calling ComputeCadence every 15s while the exchange's own
        // OI print just lags behind underneath.
        var engine = new LiveFeatureEngine(BaseUniverse());
        var at = Start;
        engine.OnTick(MakeTick(SpotToken, 23950m, at));
        engine.OnTick(MakeTick(FutureToken, 24000m, at));
        engine.OnTick(MakeTick(CallToken, 100m, at, oi: 100_000));
        engine.OnTick(MakeTick(PutToken, 80m, at, oi: 100_000));
        engine.ComputeCadence(at);

        for (var elapsed = TimeSpan.FromSeconds(15); elapsed <= FeatureWindowLengths.OiComparisonWindow + TimeSpan.FromSeconds(15); elapsed += TimeSpan.FromSeconds(15))
        {
            at = Start + elapsed;
            engine.OnTick(MakeTick(SpotToken, 23950m, at));
            engine.OnTick(MakeTick(FutureToken, 24000m, at));
            engine.OnTick(MakeTick(CallToken, 100m, at, oi: 100_000));
            engine.OnTick(MakeTick(PutToken, 80m, at, oi: 100_000));
            engine.ComputeCadence(at);
        }

        // Spot up (classification is spot-driven since F17, not each leg's own price -- see
        // ComputeOiBuildupNet). Call: OI up by a small 1,000 -- LongBuildup, bullish, +1 sign,
        // small size. Put: OI up by a large 50,000 -- LongBuildup, bearish for a put, -1 sign,
        // large size. Old formula: (+1) + (-1) = 0. New formula: (+1,000) + (-50,000) = -49,000.
        var next = at + TimeSpan.FromSeconds(15);
        engine.OnTick(MakeTick(SpotToken, 23960m, next));
        engine.OnTick(MakeTick(FutureToken, 24000m, next));
        engine.OnTick(MakeTick(CallToken, 105m, next, oi: 101_000));
        engine.OnTick(MakeTick(PutToken, 85m, next, oi: 150_000));
        var snapshot = engine.ComputeCadence(next);

        Assert.NotNull(snapshot);
        Assert.Equal(-49_000.0, snapshot!.OiBuildupNetRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCadence_SmoothsCompositeRaw_AcrossTheLastSeveralCadences()
    {
        // Regression for the live-caught "score isn't tradable" problem (2026-09-07): a
        // composite recomputed from scratch every cadence, with no memory of its own recent
        // behavior, let a single noisy cadence swing the tradable score just as much as a
        // genuinely sustained move -- which kept resetting the entry rules' sustain timer even
        // on days with a real, persistent directional move. Warm up a baseline with small,
        // realistic jitter (StdDev must be non-zero or every z-score stays null -- see
        // WelfordRollingWindow.ComputeZScore), then inject one drastic single-cadence OI
        // change and confirm the smoothed CompositeScoreRaw moves far less than the
        // instantaneous one did.
        // A second strike (2026-09-07), independently jittered -- ComputeUnderlyingPrice
        // averages the synthetic forward across every strike with both legs quoted, and
        // IvSkew solves at whichever strike is nearest spot +/-200. With only one strike in
        // the universe, both resolve to the exact same (strike, call price, put price) triple.
        // Put-call parity makes C-P independent of volatility entirely (see
        // NiftySignal.Pricing.SyntheticForward's derivation), so an underlying solved via that
        // exact identity from IvSkew's own two prices makes the sigma that solves the call
        // side an *exact* algebraic solution of the put side too -- putIv-callIv is
        // mathematically forced to (near enough) zero every cadence, not just usually small.
        // Its window's StdDev then drops below WelfordRollingWindow's 1e-12 floor,
        // ComputeZScore nulls IvSkewZ out, and warm-up never completes (it's one of the six
        // required components). A second, independent strike breaks the self-reference by
        // pulling the *averaged* underlying away from that one exact value -- constructed via
        // real BlackScholes pricing (not arbitrary numbers) so it stays parity-consistent and
        // doesn't itself break either solve. Production never hits this at all: it always has
        // dozens of strikes, never just the one IvSkew itself targets.
        const string SecondCallToken = "99005";
        const string SecondPutToken = "99006";
        const decimal SecondStrike = 24000m;
        var universe = BaseUniverse();
        universe.Add(Option(SecondCallToken, OptionType.Call, SecondStrike));
        universe.Add(Option(SecondPutToken, OptionType.Put, SecondStrike));

        var engine = new LiveFeatureEngine(universe);
        var at = Start;
        ScoreSnapshot? snapshot = null;
        var random = new Random(42);
        var lastSpotPrice = 23900m;
        var i = 0;

        // A little over 2 hours at 15s cadence -- long enough to warm up PriceMomentumZScoreWindow
        // (2h, the longest of the six required since F4/2026-09-08; previously the 30-minute
        // windows -- Pcr/OiBuildupNet/FuturesBasis -- were longest). Every jittered quantity is
        // independently randomized -- spot and future must NOT share the same offset (that
        // cancels out in the basis calc), and depth quantities need their own variance too
        // (imbalance is otherwise perfectly balanced, hence zero, every cadence). Depth bid/ask
        // must jitter too, not just LTP: MidPrice prefers depth mid over LTP, and a fixed depth
        // mid would make the option price constant every cadence regardless of LLP's own jitter.
        for (var elapsed = TimeSpan.Zero; elapsed <= TimeSpan.FromHours(2) + TimeSpan.FromSeconds(15); elapsed += TimeSpan.FromSeconds(15))
        {
            at = Start + elapsed;
            // Spot oscillates deterministically (Wave, same helper BuildSeedHistory uses),
            // not i.i.d. random noise, during warm-up here (audit finding F17, 2026-09-08):
            // OiBuildupNet's classification now reads spot's own cadence-to-cadence delta, and
            // spot already anchors FuturesBasis/IvSkew's theoretical pricing too -- a random
            // walk's occasional same-direction runs correlated all three components' z-scores
            // during the warm-up loop often enough to inflate the smoothed baseline this test
            // warms up on, defeating the point of testing against a genuinely calm one. A regular
            // oscillation still gives every window real (non-zero) variance without the
            // multi-cadence same-direction runs a random walk produces by chance.
            lastSpotPrice = 23900m + (decimal)Math.Round(Wave(1.5, i));
            engine.OnTick(MakeTick(SpotToken, lastSpotPrice, at));
            engine.OnTick(MakeTick(FutureToken, 24000m + random.Next(-2, 3), at));
            i++;
            // OiBuildupNet's classifier reads spot's own price change (audit finding F17,
            // 2026-09-08 -- previously the option's own price, but spot already jitters above,
            // which is what drives classification now).
            var callJitter = random.Next(-1, 2);
            var putJitter = random.Next(-1, 2);
            engine.OnTick(MakeTick(CallToken, 100m + callJitter, at,
                oi: 1_000_000 + random.Next(-3_000, 3_001),
                depth: Depth(400 + random.Next(0, 200), 400 + random.Next(0, 200), bid: 99.5m + callJitter, ask: 100.5m + callJitter)));
            engine.OnTick(MakeTick(PutToken, 80m + putJitter, at,
                oi: 900_000 + random.Next(-3_000, 3_001),
                depth: Depth(400 + random.Next(0, 200), 400 + random.Next(0, 200), bid: 79.5m + putJitter, ask: 80.5m + putJitter)));
            // Real BlackScholes construction, not arbitrary numbers -- see the comment above
            // on why an inconsistent second strike would just break both IV solves instead of
            // gently perturbing the averaged underlying.
            var secondUnderlying = 23900.0 + random.Next(-3, 4);
            var secondT = TimeToExpiry.YearsUntilExpiry(NearestExpiry, at);
            var secondCallPrice = (decimal)BlackScholes.Calculate(OptionType.Call, secondUnderlying, (double)SecondStrike, secondT, 0.065, 0.15).Price;
            var secondPutPrice = (decimal)BlackScholes.Calculate(OptionType.Put, secondUnderlying, (double)SecondStrike, secondT, 0.065, 0.15).Price;
            engine.OnTick(MakeTick(SecondCallToken, secondCallPrice, at, depth: Depth(200, 200, bid: secondCallPrice - 0.05m, ask: secondCallPrice + 0.05m)));
            engine.OnTick(MakeTick(SecondPutToken, secondPutPrice, at, depth: Depth(200, 200, bid: secondPutPrice - 0.05m, ask: secondPutPrice + 0.05m)));
            snapshot = engine.ComputeCadence(at);
        }

        Assert.NotNull(snapshot);
        Assert.True(snapshot!.IsWarmedUp);

        // One drastic, single-cadence OI spike -- call OI roughly 4-5x its baseline, versus
        // the +/-2,000 jitter the baseline warmed up on. Spot moves by exactly +/-1 from its own
        // last real value (audit finding F17: classification is spot-driven now, not the
        // option's own price) -- deterministic and unambiguous (never accidentally 0) without a
        // disturbance large enough to also swing FuturesBasis/IvSkew's own spot-anchored
        // calculations. Direction matches the already-warmed-up baseline's own sign (not fixed
        // up) so the spike's classification reinforces the existing trend rather than risking a
        // coincidental cancellation -- F17 means OiBuildupNet's classification now shares spot as
        // a jitter source with FuturesBasis/IvSkew, so a fixed spike direction could land opposite
        // an already-nonzero smoothed baseline under some RNG seeds, shrinking |instant| instead
        // of growing it.
        var preSpikeSmoothed = snapshot!.CompositeScoreRaw!.Value;
        var pushUp = preSpikeSmoothed is not < 0;
        var spikeAt = at + TimeSpan.FromSeconds(15);
        engine.OnTick(MakeTick(SpotToken, lastSpotPrice + (pushUp ? 1 : -1), spikeAt));
        engine.OnTick(MakeTick(FutureToken, 24000m, spikeAt));
        engine.OnTick(MakeTick(CallToken, 100m, spikeAt, oi: 5_000_000, depth: Depth(500, 500, bid: 99.5m, ask: 100.5m)));
        engine.OnTick(MakeTick(PutToken, 80m, spikeAt, oi: 900_000, depth: Depth(500, 500, bid: 79.5m, ask: 80.5m)));
        var spiked = engine.ComputeCadence(spikeAt);

        Assert.NotNull(spiked);
        Assert.NotNull(spiked!.CompositeScoreRawInstant);
        Assert.NotNull(spiked.CompositeScoreRaw);

        // The smoothed value must *move* far less than the instantaneous one, both measured as a
        // delta off the established pre-spike baseline (not their raw magnitudes) -- comparing
        // absolute values implicitly assumed the pre-spike baseline was near zero, which doesn't
        // reliably hold once OiBuildupNet's classification shares spot as a jitter source with
        // several other components (audit finding F17); comparing movement off the actual
        // pre-spike baseline is robust to whatever ambient value that baseline happens to be.
        var smoothedMove = Math.Abs(spiked.CompositeScoreRaw!.Value - preSpikeSmoothed);
        var instantMove = Math.Abs(spiked.CompositeScoreRawInstant!.Value - preSpikeSmoothed);
        // <= not < (audit finding F46, 2026-09-10): fixing the z-score self-inclusion bug
        // removed a pre-existing dampening bias from the instant reading itself, which moved
        // this specific deterministic scenario's ratio to exactly 0.5 -- still strong smoothing
        // (only ~1/12 FIFO leak-through, as expected for CompositeSmoothingCadences=12), just
        // sitting exactly on the old strict boundary rather than under it.
        Assert.True(smoothedMove <= instantMove / 2);
    }

    [Fact]
    public void ComputeCadence_FuturesBasisZ_ExcludesCurrentObservationFromItsOwnWindow()
    {
        // Audit finding F46 (2026-09-10): the current cadence's raw value must be scored
        // against the window's state as it stood BEFORE this observation, never after --
        // otherwise an outlier inflates its own comparison stddev and understates its own
        // extremity. FuturesBasis is used here (rather than the more heavily-weighted
        // OiBuildupNet) because its raw value is a simple, fully test-controlled
        // futureMark-spot subtraction with no option-chain machinery involved.
        var engine = new LiveFeatureEngine(BaseUniverse());
        var shadowWindow = new WelfordRollingWindow(FeatureWindowLengths.FuturesBasis);

        var at = Start;
        ScoreSnapshot? snapshot = null;
        // Oscillate basis between two close values for a bit over the 30-minute window so
        // FuturesBasisZ warms up with a real (non-zero) spread to divide by.
        for (var elapsed = TimeSpan.Zero; elapsed <= FeatureWindowLengths.FuturesBasis + TimeSpan.FromMinutes(2); elapsed += TimeSpan.FromSeconds(15))
        {
            at = Start + elapsed;
            var cadenceIndex = elapsed.Ticks / TimeSpan.FromSeconds(15).Ticks;
            var basis = cadenceIndex % 2 == 0 ? 100m : 102m;
            engine.OnTick(MakeTick(SpotToken, 23900m, at));
            engine.OnTick(MakeTick(FutureToken, 23900m + basis, at));
            snapshot = engine.ComputeCadence(at);

            // Mirrors the engine's own basis window exactly -- same values, same timestamps,
            // fed from the same public FuturesBasisRaw the engine computed internally -- so
            // this shadow window's state is identical to the engine's private _basisWindow
            // without needing to reach into it.
            if (snapshot?.FuturesBasisRaw is { } raw)
            {
                shadowWindow.Add(at, raw);
            }
        }

        Assert.NotNull(snapshot);
        Assert.NotNull(snapshot!.FuturesBasisZ);

        // A moderate outlier relative to the 100/102 oscillation (mean ~101) -- deliberately
        // NOT extreme: an outlier large enough to saturate the +/-3 clamp under both orderings
        // would make them indistinguishable after clamping, hiding the very divergence this
        // test exists to catch.
        var spikeAt = at + TimeSpan.FromSeconds(15);
        engine.OnTick(MakeTick(SpotToken, 23900m, spikeAt));
        engine.OnTick(MakeTick(FutureToken, 23900m + 103m, spikeAt));
        var spiked = engine.ComputeCadence(spikeAt);

        Assert.NotNull(spiked);
        Assert.NotNull(spiked!.FuturesBasisRaw);
        Assert.NotNull(spiked.FuturesBasisZ);

        // Correct (fixed) behavior: z computed against the shadow window's state as it stood
        // before the spike -- must match the engine's actual FuturesBasisZ exactly.
        var correctZ = shadowWindow.ComputeZScore(spiked.FuturesBasisRaw!.Value);
        Assert.Equal(correctZ, spiked.FuturesBasisZ);

        // The bug this guards against: had the engine (wrongly) added the spike to the window
        // before scoring it, the spike would inflate its own comparison stddev and understate
        // its own extremity. Confirm the two orderings actually diverge for this scenario
        // (otherwise this test wouldn't be discriminating at all), and that the engine's real
        // answer is not the buggy one.
        shadowWindow.Add(spikeAt, spiked.FuturesBasisRaw!.Value);
        var buggyZ = shadowWindow.ComputeZScore(spiked.FuturesBasisRaw!.Value);
        Assert.NotEqual(buggyZ, spiked.FuturesBasisZ);
    }

    [Fact]
    public void BuildStrikeSnapshots_ReportsVolumeTradedThisCadence_NotTheCumulativeDayTotal()
    {
        // The feed reports cumulative day volume, so a naive persist would record an
        // ever-growing number instead of "how much traded in these 15 seconds".
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, volume: 5_000));

        // First pass has no prior observation to diff against -- null, not a fabricated zero.
        var first = engine.BuildStrikeSnapshots(Start);
        Assert.Null(Assert.Single(first, s => s.Token == CallToken).VolumeDelta);

        engine.OnTick(MakeTick(CallToken, 101m, Start.AddSeconds(15), volume: 5_350));

        var second = engine.BuildStrikeSnapshots(Start.AddSeconds(15));

        // 5,350 cumulative minus 5,000 at the previous cadence = 350 traded in between.
        Assert.Equal(350, Assert.Single(second, s => s.Token == CallToken).VolumeDelta);
    }

    [Fact]
    public void BuildStrikeSnapshots_ClampsVolumeDeltaToZero_WhenTheCumulativeCounterGoesBackwards()
    {
        // A feed reset mid-session would otherwise yield a negative "traded volume", which is
        // meaningless -- better to record no activity than a nonsense negative.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, volume: 9_000));
        engine.BuildStrikeSnapshots(Start);

        engine.OnTick(MakeTick(CallToken, 100m, Start.AddSeconds(15), volume: 120));
        var afterReset = engine.BuildStrikeSnapshots(Start.AddSeconds(15));

        Assert.Equal(0, Assert.Single(afterReset, s => s.Token == CallToken).VolumeDelta);
    }

    [Fact]
    public void BuildStrikeSnapshots_ReportsOpenInterestChangeThisCadence_NotTheRunningLevel()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000));

        // First pass has no prior observation to diff against -- null, not a fabricated zero.
        var first = engine.BuildStrikeSnapshots(Start);
        Assert.Null(Assert.Single(first, s => s.Token == CallToken).OpenInterestDelta);

        engine.OnTick(MakeTick(CallToken, 101m, Start.AddSeconds(15), oi: 1_045_000));

        var second = engine.BuildStrikeSnapshots(Start.AddSeconds(15));

        Assert.Equal(45_000, Assert.Single(second, s => s.Token == CallToken).OpenInterestDelta);
    }

    [Fact]
    public void BuildStrikeSnapshots_ReportsOpenInterestDeltaAsNegative_WhenOpenInterestFalls()
    {
        // Unlike VolumeDelta, OI is a real level, not a cumulative day counter -- a fall is
        // genuine information (positions closing), not a feed-reset artifact, so it must not be
        // clamped to zero the way VolumeDelta is.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000));
        engine.BuildStrikeSnapshots(Start);

        engine.OnTick(MakeTick(CallToken, 100m, Start.AddSeconds(15), oi: 960_000));
        var second = engine.BuildStrikeSnapshots(Start.AddSeconds(15));

        Assert.Equal(-40_000, Assert.Single(second, s => s.Token == CallToken).OpenInterestDelta);
    }

    [Fact]
    public void BuildStrikeSnapshots_ClassifiesOiBuildup_UsingPriceAndOiDeltaTogether()
    {
        // Price up + OI up on a call is the textbook LongBuildup quadrant (plan section 5.2) --
        // same classifier OiBuildupNet already uses, just recorded per strike here.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));

        // First pass has no prior cadence to classify against -- null, not Neutral.
        var first = engine.BuildStrikeSnapshots(Start);
        Assert.Null(Assert.Single(first, s => s.Token == CallToken).OiBuildup);
        Assert.Null(Assert.Single(first, s => s.Token == CallToken).MarkPriceDelta);

        engine.OnTick(MakeTick(CallToken, 105m, Start.AddSeconds(15), oi: 1_045_000, depth: Depth(500, 400, bid: 104.5m, ask: 105.5m)));
        var second = engine.BuildStrikeSnapshots(Start.AddSeconds(15));
        var call = Assert.Single(second, s => s.Token == CallToken);

        Assert.Equal(5.0m, call.MarkPriceDelta);
        Assert.Equal(OiBuildupQuadrant.LongBuildup, call.OiBuildup);
    }

    [Fact]
    public void BuildStrikeSnapshots_ClassifiesShortCovering_WhenPriceRisesButOiFalls()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.BuildStrikeSnapshots(Start);

        engine.OnTick(MakeTick(CallToken, 105m, Start.AddSeconds(15), oi: 960_000, depth: Depth(500, 400, bid: 104.5m, ask: 105.5m)));
        var second = engine.BuildStrikeSnapshots(Start.AddSeconds(15));

        Assert.Equal(OiBuildupQuadrant.ShortCovering, Assert.Single(second, s => s.Token == CallToken).OiBuildup);
    }

    [Fact]
    public void BuildStrikeSnapshots_RecordsSpreadAndGreeks_ForTheNearAtmBand()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        // Spread is sampled by Sample() (called every ~3s in production, and once more right at
        // the cadence boundary by ComputeCadence) rather than read instantaneously -- one sample
        // in means the average is trivially that one value.
        engine.Sample(Start);

        var call = Assert.Single(engine.BuildStrikeSnapshots(Start), s => s.Token == CallToken);

        Assert.Equal(99.5m, call.BidPrice);
        Assert.Equal(100.5m, call.AskPrice);
        Assert.Equal(1.0m, call.SpreadAbs);
        Assert.Equal(1_000_000, call.OpenInterest);
        Assert.Equal(NearestExpiry, call.ExpiryDate);

        // Greeks only exist when the IV solve succeeded -- they must travel together, never a
        // partially-populated row.
        Assert.NotNull(call.ImpliedVolatility);
        Assert.NotNull(call.Delta);
        Assert.NotNull(call.Gamma);
        Assert.NotNull(call.Vega);
    }

    [Fact]
    public void BuildStrikeSnapshots_AveragesSpreadAcrossSamples_RatherThanReadingTheLatestOnly()
    {
        // Two samples straddling a brief wide print: (1.0 + 3.0) / 2 = 2.0. A point-in-time
        // read at the cadence boundary would have reported 3.0 (or 1.0, depending on which
        // arrived last) and hidden that the strike was tight for most of the window.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.Sample(Start);

        engine.OnTick(MakeTick(CallToken, 100m, Start.AddSeconds(3), depth: Depth(500, 400, bid: 98.5m, ask: 101.5m)));
        engine.Sample(Start.AddSeconds(3));

        var call = Assert.Single(engine.BuildStrikeSnapshots(Start.AddSeconds(15)), s => s.Token == CallToken);

        Assert.Equal(2.0m, call.SpreadAbs);
        // The bid/ask fields themselves stay instantaneous -- they reflect whichever tick
        // arrived last, not an average of unrelated price levels.
        Assert.Equal(98.5m, call.BidPrice);
        Assert.Equal(101.5m, call.AskPrice);
    }

    [Fact]
    public void BuildStrikeSnapshots_ResetsSpreadSamples_SoTheyDoNotBleedIntoTheNextCadence()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(500, 400, bid: 90m, ask: 110m))); // spread 20
        engine.Sample(Start);
        engine.BuildStrikeSnapshots(Start);

        // A single new sample in the next window -- if the previous window's spread=20 sample
        // survived, this would average to (20 + 1) / 2 = 10.5 instead of 1.
        engine.OnTick(MakeTick(CallToken, 100m, Start.AddSeconds(15), depth: Depth(500, 400, bid: 99.5m, ask: 100.5m)));
        engine.Sample(Start.AddSeconds(15));

        var call = Assert.Single(engine.BuildStrikeSnapshots(Start.AddSeconds(15)), s => s.Token == CallToken);

        Assert.Equal(1.0m, call.SpreadAbs);
    }

    [Fact]
    public void BuildStrikeSnapshots_TheoreticalPriceAtTheAtmStrike_ReproducesItsOwnMarkPrice()
    {
        // BaseUniverse's one strike (23950) sits exactly at spot, so it IS the ATM strike --
        // the reference vol is solved from its own quote, so pricing it back at that same vol
        // must reproduce the price it was solved from. Same sanity check already verified live
        // for the dashboard's identical methodology (2026-09-05).
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 150m, Start, depth: Depth(500, 400, bid: 149.5m, ask: 150.5m)));

        var call = Assert.Single(engine.BuildStrikeSnapshots(Start), s => s.Token == CallToken);

        Assert.Equal(150m, call.MarkPrice);
        Assert.NotNull(call.TheoreticalPrice);
        Assert.Equal((double)call.MarkPrice!.Value, call.TheoreticalPrice!.Value, precision: 6);
        Assert.NotNull(call.PriceVsTheoretical);
        Assert.Equal(0.0, call.PriceVsTheoretical!.Value, precision: 6);
    }

    [Fact]
    public void BuildStrikeSnapshots_PricesEveryStrikeAtTheSharedAtmReferenceVol_NotItsOwnImpliedVol()
    {
        // A second, farther strike must be priced at the ATM leg's vol, not its own -- proving
        // the vol is genuinely shared rather than each row solving (and so trivially
        // reproducing) its own price.
        const string FarCallToken = "99001";
        var universe = BaseUniverse();
        universe.Add(Option(FarCallToken, OptionType.Call, 24450m));

        var engine = new LiveFeatureEngine(universe);
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 150m, Start, depth: Depth(500, 400, bid: 149.5m, ask: 150.5m)));
        engine.OnTick(MakeTick(FarCallToken, 40m, Start, depth: Depth(200, 200, bid: 39.5m, ask: 40.5m)));

        var snapshots = engine.BuildStrikeSnapshots(Start);
        var far = Assert.Single(snapshots, s => s.Token == FarCallToken);

        var t = TimeToExpiry.YearsUntilExpiry(NearestExpiry, Start);
        var atmVol = ImpliedVolatilitySolver.Solve(OptionType.Call, 150.0, 23950.0, 23950.0, t, 0.065)!.Value;
        var expectedTheoretical = BlackScholes.Calculate(OptionType.Call, 23950.0, 24450.0, t, 0.065, atmVol).Price;

        Assert.NotNull(far.TheoreticalPrice);
        Assert.Equal(expectedTheoretical, far.TheoreticalPrice!.Value, precision: 6);
        // Its own market price (40) is nowhere near the shared-vol theoretical for a strike
        // this far out of the money -- if this failed, it'd mean the row silently fell back to
        // solving its own IV instead of using the shared one.
        Assert.NotEqual(40.0, far.TheoreticalPrice!.Value, precision: 1);
    }

    [Fact]
    public void BuildStrikeSnapshots_LeavesTheoreticalPriceNull_WhenNeitherAtmLegHasAUsableQuote()
    {
        // Both ATM legs present but with no depth and no LTP (price 0) -- there's nothing to
        // solve a reference vol from, so every row's theoretical price must stay null rather
        // than falling back to a fabricated vol.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(CallToken, 0m, Start));
        engine.OnTick(MakeTick(PutToken, 0m, Start));

        var snapshots = engine.BuildStrikeSnapshots(Start);

        Assert.All(snapshots, s => Assert.Null(s.TheoreticalPrice));
        Assert.All(snapshots, s => Assert.Null(s.PriceVsTheoretical));
    }

    [Fact]
    public void BuildStrikeSnapshots_ReturnsEmpty_BeforeSpotHasTicked()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(CallToken, 100m, Start));

        Assert.Empty(engine.BuildStrikeSnapshots(Start));
    }

    [Fact]
    public void ComputeCadence_RecordsSpotPrice_ForChartingAndReversalAnalysis()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23942.35m, Start));
        engine.OnTick(MakeTick(FutureToken, 24068.90m, Start));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.Equal(23942.35, snapshot!.SpotPrice!.Value, precision: 2);
    }

    [Fact]
    public void ComputeCadence_ComputesVixChange_AsNegatedDeltaOverTheLookbackWindow()
    {
        const string VixToken = "26017";
        var universe = BaseUniverse();
        universe.Add(new Instrument
        {
            Token = VixToken,
            Exchange = Exchange.Nse,
            TradingSymbol = "India VIX",
            InstrumentType = InstrumentType.Vix,
            Underlying = "NIFTY",
            LotSize = 1,
            TickSize = 0.01m,
            AsOfDate = AsOfDate,
        });

        var engine = new LiveFeatureEngine(universe);
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(VixToken, 12.00m, Start));

        var first = engine.ComputeCadence(Start);
        Assert.NotNull(first);
        Assert.Equal(0.0, first!.VixChangeRaw!.Value, precision: 6); // first observation compares to itself

        var later = Start.AddMinutes(10);
        engine.OnTick(MakeTick(SpotToken, 23900m, later));
        engine.OnTick(MakeTick(FutureToken, 24000m, later));
        engine.OnTick(MakeTick(VixToken, 13.50m, later)); // VIX rose 1.50

        var second = engine.ComputeCadence(later);

        Assert.NotNull(second);
        // Negated: VIX rose (12.00 -> 13.50), so raw must be negative (bearish contribution).
        Assert.Equal(-1.50, second!.VixChangeRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCadence_VixChangeZStaysNull_UntilTheZScoreWindowElapses_NotJustTheRawLookbackWindow()
    {
        // Regression for a live-caught bug (2026-09-07): the raw VIX change is a 30-minute
        // lookback delta, and z-scoring it against a window of that SAME 30-minute length
        // means each new 15s sample's lookback overlaps the last one almost entirely -- during
        // any stretch where VIX drifts smoothly, that series has almost no internal variance,
        // so the window's StdDev collapses and an ordinary later move slams into the +/-3 clip.
        // The z-score window is now several times longer than the raw lookback, confirmed here
        // by checking VixChangeZ is still null just past the OLD window's length -- a genuine
        // fix must make the window longer, not just rename the same duration.
        const string VixToken = "26017";
        var universe = BaseUniverse();
        universe.Add(new Instrument
        {
            Token = VixToken,
            Exchange = Exchange.Nse,
            TradingSymbol = "India VIX",
            InstrumentType = InstrumentType.Vix,
            Underlying = "NIFTY",
            LotSize = 1,
            TickSize = 0.01m,
            AsOfDate = AsOfDate,
        });

        // Sample every 5 minutes (well inside the 30-minute raw lookback, so each reading is a
        // genuine non-zero comparison rather than degenerating to "compares to itself") with
        // VIX drifting up a little each time -- exactly the "smoothly drifting" shape that
        // triggered the live bug. Runs past both the old 30-minute window and the new one so
        // the warm-up transition is directly observable.
        var engine = new LiveFeatureEngine(universe);
        ScoreSnapshot? last = null;
        var vix = 12.00m;
        for (var elapsed = TimeSpan.Zero; elapsed <= FeatureWindowLengths.VixChangeZScoreWindow + TimeSpan.FromMinutes(10); elapsed += TimeSpan.FromMinutes(5))
        {
            var at = Start + elapsed;
            vix += 0.01m;
            engine.OnTick(MakeTick(SpotToken, 23900m, at));
            engine.OnTick(MakeTick(FutureToken, 24000m, at));
            engine.OnTick(MakeTick(VixToken, vix, at));
            last = engine.ComputeCadence(at);

            // Just past the OLD 30-minute window -- under the pre-fix window length this would
            // already be warmed up (and prone to clipping); it must not be now.
            if (elapsed == FeatureWindowLengths.VixChange + TimeSpan.FromMinutes(5))
            {
                Assert.Null(last!.VixChangeZ);
            }
        }

        // Past the new (longer) window, it should finally be able to warm up.
        Assert.NotNull(last);
        Assert.NotNull(last!.VixChangeZ);
    }

    [Fact]
    public void ComputeCadence_LeavesVixChangeNull_WhenUniverseDoesNotTrackVix()
    {
        // BaseUniverse() has no Vix-type instrument -- ComputeCadence must not throw, and
        // VixChangeRaw/Z simply stay null (optional by design, see CompositeScoreCalculator).
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.Null(snapshot!.VixChangeRaw);
        Assert.Null(snapshot.VixChangeZ);
    }

    [Fact]
    public void ComputeCadence_CompositeScoreStaysNull_UntilAllSixMetricsWarmUp()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000, depth: Depth(500, 400)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 870_000, depth: Depth(300, 600)));

        // A single observation can never satisfy any window's real-elapsed-time warm-up
        // requirement (shortest is 5 minutes), regardless of how many cadence ticks fire
        // at the same instant.
        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.False(snapshot!.IsWarmedUp);
        Assert.Null(snapshot.CompositeScore);
    }

    [Fact]
    public void ComputeCadence_AveragesSamplesSinceLastCadence_ForTheFiveSmoothedMetrics()
    {
        // DepthImbalance stands in for FuturesBasis here (originally used) -- basis no longer
        // varies with a simple per-sample delta once measured against the synthetic forward
        // (see F11), and falls back to spot (delta 0) without a real option chain configured.
        // The mechanism under test is the averaging itself, not which metric supplies the
        // numbers, so any of the five smoothed metrics proves the same thing.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));

        // Two mid-cadence samples before any explicit ComputeCadence call: imbalance 1.0, then
        // 0.2. A third, implicit sample happens inside ComputeCadence itself (-1.0) -- average
        // of 1.0/0.2/-1.0 = 0.2/3.
        engine.OnTick(MakeTick(CallToken, 100m, Start.AddSeconds(3), depth: Depth(bidQty: 100, askQty: 0)));
        engine.Sample(Start.AddSeconds(3)); // (100-0)/100 = 1.0
        engine.OnTick(MakeTick(CallToken, 100m, Start.AddSeconds(6), depth: Depth(bidQty: 60, askQty: 40)));
        engine.Sample(Start.AddSeconds(6)); // (60-40)/100 = 0.2
        engine.OnTick(MakeTick(CallToken, 100m, Start.AddSeconds(9), depth: Depth(bidQty: 0, askQty: 100))); // (0-100)/100 = -1.0

        var snapshot = engine.ComputeCadence(Start.AddSeconds(9));

        Assert.NotNull(snapshot);
        Assert.Equal((1.0 + 0.2 - 1.0) / 3.0, snapshot!.DepthImbalanceRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCadence_SingleSample_MatchesTheUnsampledValue_WhenNoMidCadenceSamplesWereTaken()
    {
        // Guards against a regression where averaging changes behavior even for callers (most
        // existing tests) that never call Sample() themselves -- a single implicit sample
        // inside ComputeCadence should equal the old "just read the instant" behavior.
        // DepthImbalance stands in for FuturesBasis here -- see the averaging test above.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23900m, Start));
        engine.OnTick(MakeTick(FutureToken, 24028.35m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(bidQty: 60, askQty: 40)));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.Equal(0.2, snapshot!.DepthImbalanceRaw!.Value, precision: 6);
    }

    [Fact]
    public void NearestExpiry_IsTheSmallestOptionExpiryInTheUniverse()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());

        Assert.Equal(NearestExpiry, engine.NearestExpiry);
    }

    [Fact]
    public void BuildStrikeCandidates_ReturnsOnlyTheRequestedSide()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        // IV/Delta price against spot, not the future (2026-09-04 fix) -- spot must have
        // ticked for BuildStrikeCandidates to return anything.
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000, depth: Depth(500, 400, bid: 99.9m, ask: 100.1m)));
        engine.OnTick(MakeTick(PutToken, 80m, Start, oi: 870_000, depth: Depth(300, 600, bid: 79.9m, ask: 80.1m)));

        var calls = engine.BuildStrikeCandidates(OptionType.Call, Start);

        var candidate = Assert.Single(calls);
        Assert.Equal(CallToken, candidate.Token);
        Assert.Equal(OptionType.Call, candidate.OptionType);
        Assert.Equal(1_000_000, candidate.OpenInterest);
    }

    [Fact]
    public void BuildStrikeCandidates_ReportsCumulativeDayVolume_NotAHardcodedZero()
    {
        // Audit finding F19: Volume used to be hardcoded 0, making StrikeSelector's own
        // volume tie-break a permanent no-op (always 0 vs 0).
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        engine.OnTick(MakeTick(CallToken, 100m, Start, oi: 1_000_000, depth: Depth(500, 400, bid: 99.9m, ask: 100.1m), volume: 42_000));

        var candidate = Assert.Single(engine.BuildStrikeCandidates(OptionType.Call, Start));

        Assert.Equal(42_000, candidate.Volume);
    }

    [Fact]
    public void BuildStrikeCandidates_PricesIvAgainstSpot_NotTheMismatchedTrackedFuture()
    {
        // Regression test for the 2026-09-04 live-caught bug ("all put IVs read >10, call
        // IVs around 5"): IV/Delta were solved against the tracked future, but NSE only
        // lists monthly futures -- mismatched against a weekly option's own much nearer
        // expiry, overstating the underlying by the month-vs-week cost-of-carry gap.
        // Deliberately push spot and future ~150 points apart (comparable to the real gap
        // observed live) so a formula that used the wrong one would recover a badly wrong
        // IV instead of the true one.
        var engine = new LiveFeatureEngine(BaseUniverse());
        const decimal spot = 23950m; // == CallToken's own strike, i.e. exactly ATM against spot
        const decimal future = 24100m;
        const double trueIv = 0.15;

        var years = TimeToExpiry.YearsUntilExpiry(NearestExpiry, Start);
        var fairPrice = (decimal)BlackScholes.Calculate(OptionType.Call, (double)spot, 23950, years, 0.065, trueIv).Price;

        engine.OnTick(MakeTick(SpotToken, spot, Start));
        engine.OnTick(MakeTick(FutureToken, future, Start));
        engine.OnTick(MakeTick(CallToken, fairPrice, Start, depth: Depth(bidQty: 100, askQty: 100, bid: fairPrice - 0.05m, ask: fairPrice + 0.05m)));

        var candidate = Assert.Single(engine.BuildStrikeCandidates(OptionType.Call, Start));

        Assert.NotNull(candidate.ImpliedVolatility);
        Assert.Equal(trueIv, candidate.ImpliedVolatility!.Value, 1e-3);
    }

    [Fact]
    public void ComputeCadence_ComputesIvSkew_AgainstTheSyntheticForward_NotRawSpot()
    {
        // 2026-09-07: the original fix here (spot instead of the mismatched monthly future)
        // was directionally right but incomplete -- spot itself carries no cost-of-carry
        // adjustment, and a same-day live check found call/put IV at the same strike
        // systematically ~7-8 vol points apart, all day, every strike: the signature of an
        // understated underlying (it biases a call solve up and a put solve down), not real
        // skew (which shows up across strikes, not as a same-strike call/put split).
        //
        // Here: call and put are both priced off the SAME true vol (0.15, i.e. genuinely zero
        // skew) but off the FORWARD (24080, a realistic ~130pt premium to spot), not spot
        // itself (23950). If IvSkew still used raw spot as the underlying, solving these
        // prices against the wrong (too-low) underlying would recover a large artificial
        // skew -- exactly the live-caught symptom. Recovering ~zero proves the forward is
        // what's actually feeding the solve now.
        var engine = new LiveFeatureEngine(BaseUniverse());
        const decimal spot = 23950m;
        const decimal forward = 24080m;
        const double trueVol = 0.15;

        var years = TimeToExpiry.YearsUntilExpiry(NearestExpiry, Start);
        var callPrice = (decimal)BlackScholes.Calculate(OptionType.Call, (double)forward, 23950, years, 0.065, trueVol).Price;
        var putPrice = (decimal)BlackScholes.Calculate(OptionType.Put, (double)forward, 23950, years, 0.065, trueVol).Price;

        engine.OnTick(MakeTick(SpotToken, spot, Start));
        engine.OnTick(MakeTick(FutureToken, 24200m, Start)); // the mismatched monthly future -- must not be used either
        engine.OnTick(MakeTick(CallToken, callPrice, Start, depth: Depth(bidQty: 100, askQty: 100, bid: callPrice - 0.05m, ask: callPrice + 0.05m)));
        engine.OnTick(MakeTick(PutToken, putPrice, Start, depth: Depth(bidQty: 100, askQty: 100, bid: putPrice - 0.05m, ask: putPrice + 0.05m)));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.NotNull(snapshot!.IvSkewOneSigmaRaw);
        Assert.Equal(0.0, snapshot.IvSkewOneSigmaRaw!.Value, 1e-3);
    }

    [Fact]
    public void ComputeCadence_IvSkew_TargetStrikeOffset_ScalesWithVolatility_NotAFixedPointCount()
    {
        // Audit finding F8 (2026-09-08): a fixed +/-200 point offset means something different
        // on a calm day (deep OTM wings) than a volatile one (near ATM, real premium). Proven
        // here with a near strike (zero skew) and a far strike (a large, deliberate skew): low
        // ATM vol should target the near strike (small expected move), high ATM vol should
        // target the far one (large expected move) -- extreme enough vol values that this holds
        // regardless of the exact day-count between Start and NearestExpiry.
        const decimal spot = 24000m;
        const decimal atmStrike = 24000m;
        const decimal nearCallStrike = 24050m;
        const decimal nearPutStrike = 23950m;
        const decimal farCallStrike = 24800m;
        const decimal farPutStrike = 23200m;

        var universe = new List<Instrument> { Spot(), Future(),
            Option(CallToken, OptionType.Call, atmStrike), Option(PutToken, OptionType.Put, atmStrike),
            Option("88101", OptionType.Call, nearCallStrike), Option("88102", OptionType.Put, nearPutStrike),
            Option("88103", OptionType.Call, farCallStrike), Option("88104", OptionType.Put, farPutStrike) };

        double SkewAtAtmVol(double atmVol)
        {
            var engine = new LiveFeatureEngine(universe);
            var t = TimeToExpiry.YearsUntilExpiry(NearestExpiry, Start);
            engine.OnTick(MakeTick(SpotToken, spot, Start));
            engine.OnTick(MakeTick(FutureToken, spot + 50m, Start));

            var atmCallPrice = (decimal)BlackScholes.Calculate(OptionType.Call, (double)spot, (double)atmStrike, t, 0.065, atmVol).Price;
            var atmPutPrice = (decimal)BlackScholes.Calculate(OptionType.Put, (double)spot, (double)atmStrike, t, 0.065, atmVol).Price;
            engine.OnTick(MakeTick(CallToken, atmCallPrice, Start, depth: Depth(100, 100, bid: atmCallPrice - 0.05m, ask: atmCallPrice + 0.05m)));
            engine.OnTick(MakeTick(PutToken, atmPutPrice, Start, depth: Depth(100, 100, bid: atmPutPrice - 0.05m, ask: atmPutPrice + 0.05m)));

            // Near strikes: identical call/put vol -- zero skew if these are the ones selected.
            // Symmetric distances either side of spot (call target lands above spot, put target
            // below it), since nearest-strike search only helps if a strike actually exists on
            // the target's own side -- one strike reused for both legs left every put target
            // resolving to the ATM strike instead, since nothing below spot was ever closer.
            var nearCallPrice = (decimal)BlackScholes.Calculate(OptionType.Call, (double)spot, (double)nearCallStrike, t, 0.065, 0.15).Price;
            var nearPutPrice = (decimal)BlackScholes.Calculate(OptionType.Put, (double)spot, (double)nearPutStrike, t, 0.065, 0.15).Price;
            engine.OnTick(MakeTick("88101", nearCallPrice, Start, depth: Depth(100, 100, bid: nearCallPrice - 0.05m, ask: nearCallPrice + 0.05m)));
            engine.OnTick(MakeTick("88102", nearPutPrice, Start, depth: Depth(100, 100, bid: nearPutPrice - 0.05m, ask: nearPutPrice + 0.05m)));

            // Far strikes: a large, deliberate put-vs-call vol gap -- a recognizable +0.40 skew
            // if these are the ones selected instead. Vols kept high enough on both legs that
            // neither price underflows to near-zero given the short T (a strike this far OTM,
            // at 0.15 vol, priced at only ~2 trading days to expiry, was observed to underflow
            // to ~1e-10 -- an unusable, effectively-zero price with a negative synthetic bid).
            var farCallPrice = (decimal)BlackScholes.Calculate(OptionType.Call, (double)spot, (double)farCallStrike, t, 0.065, 0.20).Price;
            var farPutPrice = (decimal)BlackScholes.Calculate(OptionType.Put, (double)spot, (double)farPutStrike, t, 0.065, 0.60).Price;
            engine.OnTick(MakeTick("88103", farCallPrice, Start, depth: Depth(100, 100, bid: farCallPrice - 0.05m, ask: farCallPrice + 0.05m)));
            engine.OnTick(MakeTick("88104", farPutPrice, Start, depth: Depth(100, 100, bid: farPutPrice - 0.05m, ask: farPutPrice + 0.05m)));

            var snapshot = engine.ComputeCadence(Start);
            Assert.NotNull(snapshot);
            Assert.NotNull(snapshot!.IvSkewOneSigmaRaw);
            return snapshot.IvSkewOneSigmaRaw!.Value;
        }

        var lowVolSkew = SkewAtAtmVol(0.12);
        var highVolSkew = SkewAtAtmVol(1.50);

        Assert.Equal(0.0, lowVolSkew, 1e-2);
        Assert.Equal(0.40, highVolSkew, 1e-1);
    }

    [Fact]
    public void TryGetLatestQuote_PrefersBidOverLtp()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(CallToken, 100m, Start, depth: Depth(500, 400, bid: 98.5m, ask: 101m)));

        var found = engine.TryGetLatestQuote(CallToken, out var ltp, out var bid);

        Assert.True(found);
        Assert.Equal(100m, ltp);
        Assert.Equal(98.5m, bid);
    }

    [Fact]
    public void TryGetLatestQuote_FallsBackToNullBid_WhenNoDepthSnapshotYet()
    {
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(CallToken, 100m, Start));

        var found = engine.TryGetLatestQuote(CallToken, out var ltp, out var bid);

        Assert.True(found);
        Assert.Equal(100m, ltp);
        Assert.Null(bid);
    }

    [Fact]
    public void SeedHistory_RestoresWarmUp_WithoutNeedingLiveTicksToAccumulate()
    {
        // Depth imbalance's window is 5 minutes -- replay one point per minute across that
        // span, as if this were the ScoreSnapshot history a restart would find in Postgres.
        // Values vary (not a constant) so the window has real spread -- an all-identical
        // series has zero StdDev, which ComputeZScore correctly reports as "no z-score" on
        // its own merits, and that would be indistinguishable from a warm-up failure here.
        var history = new[] { 0.80, 0.85, 0.95, 0.90, 1.05, 0.92 }
            .Select((value, i) => new ScoreSnapshot
            {
                ComputedAt = Start.AddMinutes(i),
                DepthImbalanceRaw = value,
                WeightSetVersion = "v1",
            })
            .ToList();

        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.SeedHistory(history);

        // A single fresh observation right after seeding should already read as warmed up
        // -- if the seed hadn't taken effect, this would need another 5 real minutes.
        var now = Start.AddMinutes(5).AddSeconds(1);
        engine.OnTick(MakeTick(SpotToken, 23900m, now));
        engine.OnTick(MakeTick(FutureToken, 24000m, now));
        engine.OnTick(MakeTick(CallToken, 100m, now, depth: Depth(bidQty: 90, askQty: 100)));
        engine.OnTick(MakeTick(PutToken, 80m, now, depth: Depth(bidQty: 90, askQty: 100)));

        var snapshot = engine.ComputeCadence(now);

        Assert.NotNull(snapshot);
        Assert.NotNull(snapshot!.DepthImbalanceZ);
    }

    [Fact]
    public void ComputeCadence_CompositeScore_AlwaysUsesFixedDefaultK_RegardlessOfPastRawVolatility()
    {
        // Audit finding F1 (2026-09-08): k used to self-normalize as the rolling stddev of the
        // composite's own recent raw values -- this proves that mechanism is gone. Confirms the
        // resulting score matches CompositeScoreCalculator.Calculate's own DefaultK regardless
        // of how much the underlying components moved during warm-up.
        const int SeedMinutes = 120;
        var history = BuildSeedHistory(SeedMinutes);
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.SeedHistory(history);

        // A priming cadence first (audit finding F16, 2026-09-08): OiBuildupNet correctly
        // returns null, not a fabricated 0, on the very first cadence after SeedHistory (there's
        // no real _previousCadence yet to diff against) -- same as a real restart genuinely loses
        // one cadence's worth of OiBuildupNet. The second call below has a real previous cadence.
        var primingAt = Start.AddMinutes(SeedMinutes).AddSeconds(1);
        FeedFinalTick(engine, primingAt);
        engine.ComputeCadence(primingAt);

        var now = primingAt.AddSeconds(15);
        FeedFinalTick(engine, now);
        var snapshot = engine.ComputeCadence(now);

        Assert.NotNull(snapshot);
        Assert.True(snapshot!.IsWarmedUp);
        Assert.NotNull(snapshot.CompositeScore);

        var inputs = new ScoreComponentInputs(
            OiBuildupNetZ: snapshot.OiBuildupNetZ, PcrZ: snapshot.PcrZ, FuturesBasisZ: snapshot.FuturesBasisZ,
            IvSkewZ: snapshot.IvSkewZ, PriceMomentumZ: snapshot.PriceMomentumZ, DepthImbalanceZ: snapshot.DepthImbalanceZ);
        var expectedScore = CompositeScoreCalculator.Calculate(inputs, ScoreWeights.Default, now, CompositeScoreCalculator.DefaultK).Score;

        Assert.Equal(expectedScore!.Value, snapshot.CompositeScore!.Value, precision: 9);
    }

    static double Wave(double amplitude, int i) => amplitude * Math.Sin(i * 0.7);

    static List<ScoreSnapshot> BuildSeedHistory(int minutes)
    {
        var history = new List<ScoreSnapshot>();
        for (var i = 0; i < minutes; i++)
        {
            history.Add(new ScoreSnapshot
            {
                ComputedAt = Start.AddMinutes(i),
                OiBuildupNetRaw = Wave(1.0, i),
                PcrRaw = 0.8 + Wave(0.1, i),
                FuturesBasisRaw = 100 + Wave(20, i),
                IvSkewOneSigmaRaw = Wave(0.05, i),
                PriceMomentumRaw = Wave(10, i),
                DepthImbalanceRaw = Wave(0.3, i),
                WeightSetVersion = "v1",
            });
        }

        return history;
    }

    static void FeedFinalTick(LiveFeatureEngine engine, DateTimeOffset at)
    {
        engine.OnTick(MakeTick(SpotToken, 23900m, at));
        engine.OnTick(MakeTick(FutureToken, 24000m, at));
        engine.OnTick(MakeTick(CallToken, 100m, at, oi: 1_000_000, depth: Depth(bidQty: 90, askQty: 100)));
        engine.OnTick(MakeTick(PutToken, 80m, at, oi: 870_000, depth: Depth(bidQty: 90, askQty: 100)));
    }

    [Fact]
    public void SeedHistory_IgnoresNullRawValues_InsteadOfWarmingUpOnGaps()
    {
        var history = new List<ScoreSnapshot>
        {
            new() { ComputedAt = Start, DepthImbalanceRaw = null, WeightSetVersion = "v1" },
        };

        var engine = new LiveFeatureEngine(BaseUniverse());

        // Must not throw on a null raw value (e.g. a cadence tick where depth hadn't
        // arrived yet) -- SeedHistory should skip it, not feed a fabricated 0 into the window.
        var exception = Record.Exception(() => engine.SeedHistory(history));
        Assert.Null(exception);
    }

    // --- Ratio-based composite score (weekend build, 2026-09-09) ---------------------------

    /// <summary>ATM+/-5 strikes at 50-point spacing, offset 0 == the 23950 ATM strike used everywhere else in this file -- BaseUniverse's single pair is insufficient for the ratio composite's wider bands (metrics 1/2's ATM+/-5).</summary>
    static string WideCallToken(int offsetFromAtm) => $"7{offsetFromAtm + 5:00}";
    static string WidePutToken(int offsetFromAtm) => $"8{offsetFromAtm + 5:00}";

    static List<Instrument> WideRatioUniverse()
    {
        var universe = new List<Instrument> { Spot(), Future() };
        for (var offset = -5; offset <= 5; offset++)
        {
            var strike = 23950m + (offset * 50m);
            universe.Add(Option(WideCallToken(offset), OptionType.Call, strike));
            universe.Add(Option(WidePutToken(offset), OptionType.Put, strike));
        }

        return universe;
    }

    /// <summary>
    /// Ticks every strike in <see cref="WideRatioUniverse"/> with real Black-Scholes-consistent
    /// two-way quotes (priced from <paramref name="underlying"/>/<paramref name="vol"/> at each
    /// strike) rather than an arbitrary linear price ladder -- a hand-rolled price scheme
    /// produces strike/price combinations the IV solver can't reliably round-trip (or that
    /// don't bracket a real 25-delta strike for metric 4's selection), where a real BS price at
    /// a known vol always converges cleanly. Shared setup for the tests below.
    /// </summary>
    static void TickWideRatioUniverse(LiveFeatureEngine engine, DateTimeOffset at, decimal underlying = 23950m, double vol = 0.40, long oi = 100_000, long volume = 1_000)
    {
        var t = TimeToExpiry.YearsUntilExpiry(NearestExpiry, at);
        for (var offset = -5; offset <= 5; offset++)
        {
            var strike = 23950m + (offset * 50m);
            var callPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Call, (double)underlying, (double)strike, t, 0.065, vol).Price);
            var putPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Put, (double)underlying, (double)strike, t, 0.065, vol).Price);
            engine.OnTick(MakeTick(WideCallToken(offset), callPrice, at, oi: oi, depth: Depth(500, 400, bid: callPrice - 0.5m, ask: callPrice + 0.5m), volume: volume));
            engine.OnTick(MakeTick(WidePutToken(offset), putPrice, at, oi: oi, depth: Depth(500, 400, bid: putPrice - 0.5m, ask: putPrice + 0.5m), volume: volume));
        }
    }

    [Fact]
    public void FuturesVwapDeviationZ_IsNull_BeforeTheThirtyMinuteWindowWarmsUp()
    {
        // Audit finding F55's price-led dynamic-hybrid mode: FeatureWindowLengths.FuturesVwapDeviation
        // is 30 minutes of real elapsed time (WelfordRollingWindow.IsWarmedUp), not a cadence
        // count -- a single early cadence must not report a z-score.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start, volume: 1_000));

        var snapshot = engine.ComputeCadence(Start);

        Assert.NotNull(snapshot);
        Assert.Null(snapshot!.FuturesVwapDeviationZ);
        // FuturesVwap itself is also null on this very first cadence -- the first tick for any
        // token always contributes a zero volume delta (no prior baseline to diff against yet,
        // same "no prior observation" convention every other VolumeDelta-based metric in this
        // class already follows), so cumulative volume is still 0 here.
        Assert.Null(snapshot.FuturesVwap);

        // A second tick with real volume gives the future a real delta to accumulate -- VWAP
        // becomes available (even though the z-score still isn't, real elapsed time is nowhere
        // near 30 minutes yet).
        var next = Start.AddSeconds(15);
        engine.OnTick(MakeTick(FutureToken, 24010m, next, volume: 2_000));
        var snapshot2 = engine.ComputeCadence(next);

        Assert.NotNull(snapshot2);
        Assert.Null(snapshot2!.FuturesVwapDeviationZ);
        Assert.NotNull(snapshot2.FuturesVwap);
    }

    [Fact]
    public void FuturesVwapDeviationZ_GoesPositive_WhenPriceJumpsAwayFromAnAlreadyWarmFlatBaseline()
    {
        // Audit finding F55's price-led dynamic-hybrid mode (2026-09-11, user's own diagnosis:
        // every ratio metric is built from option chain data that *reacts* to price, so none of
        // it can lead -- entries need something that moves *with* price instead). The future's
        // own price relative to its own volume-weighted average price is the most direct,
        // zero-lag signal available.
        //
        // Warm the 30-minute window on a long, FLAT baseline first (so its recent-history mean
        // and stddev are small and stable), then check right after a fresh jump -- not at the end
        // of a long climb. A first version of this test checked *after* a 100-cadence climb and
        // got a *negative* z-score: VWAP is a cumulative, never-evicting average, so across a long
        // climb it keeps catching up to the new price, meaning deviation itself decays over the
        // climb -- by the end, current deviation can legitimately sit *below* the rolling window's
        // own recent (still climb-dominated, still-elevated) mean, even though the raw deviation
        // is still positive. That's the metric correctly measuring "still rising or already
        // settling," not a bug -- but it means the right moment to see a clean positive spike is
        // right as the jump happens, before VWAP has had time to react to it.
        var engine = new LiveFeatureEngine(BaseUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));

        var at = Start;
        ScoreSnapshot? snapshot = null;

        // Flat baseline, 130 cadences (32.5 min -- comfortably past the 30-minute warm-up mark),
        // constant per-tick volume delta (Tick.Volume is cumulative day volume, so this must keep
        // growing -- 1_000*(i+1) gives an exact 1_000 delta every tick, i.e. equal VWAP weighting
        // per tick, not "no new volume" the way a literal constant Volume value would).
        for (var i = 0; i < 130; i++)
        {
            engine.OnTick(MakeTick(FutureToken, 24000m + (i % 2), at, volume: 1_000 * (i + 1)));
            snapshot = engine.ComputeCadence(at);
            at = at.AddSeconds(15);
        }

        // A sharp jump to 24200, one cadence in: 130 flat ticks already anchor VWAP near 24000,
        // so a single new tick barely moves it -- deviation jumps to roughly +200 while the
        // window's recent mean/stddev are still small (dominated by the flat baseline), which is
        // exactly the "fresh, sharp move" case this metric exists to catch fast.
        engine.OnTick(MakeTick(FutureToken, 24200m, at, volume: 1_000 * 131));
        var jumpSnapshot = engine.ComputeCadence(at);

        Assert.NotNull(jumpSnapshot);
        Assert.NotNull(jumpSnapshot!.FuturesVwapDeviationZ);
        Assert.True(jumpSnapshot.FuturesVwapDeviationRaw > 0, $"Raw deviation ({jumpSnapshot.FuturesVwapDeviationRaw:F2}) should be positive right after the jump.");
        Assert.True(jumpSnapshot.FuturesVwapDeviationZ!.Value > 0, $"FuturesVwapDeviationZ ({jumpSnapshot.FuturesVwapDeviationZ.Value:F2}) should be positive right after a fresh jump above an already-warm flat baseline.");
    }

    // ==================== Core score (2026-09-13, live-wiring plan Batch 2) ====================

    /// <summary>ATM+/-10 strikes at 50-point spacing -- WideRatioUniverse's own ATM+/-5 span is too narrow for GammaExposure's ATM+/-CoreGammaBandOffset(10) band. Distinct token prefixes from WideRatioUniverse so both can coexist in the same test if ever needed.</summary>
    static string WideCoreCallToken(int offsetFromAtm) => $"9{offsetFromAtm + 10:00}";
    static string WideCorePutToken(int offsetFromAtm) => $"6{offsetFromAtm + 10:00}";

    static List<Instrument> WideCoreUniverse()
    {
        var universe = new List<Instrument> { Spot(), Future() };
        for (var offset = -10; offset <= 10; offset++)
        {
            var strike = 23950m + (offset * 50m);
            universe.Add(Option(WideCoreCallToken(offset), OptionType.Call, strike));
            universe.Add(Option(WideCorePutToken(offset), OptionType.Put, strike));
        }

        return universe;
    }

    /// <summary>Same real-Black-Scholes-quote approach as TickWideRatioUniverse, extended to the full ATM+/-10 span.</summary>
    static void TickWideCoreUniverse(LiveFeatureEngine engine, DateTimeOffset at, decimal underlying = 23950m, double vol = 0.20, long oi = 100_000, long volume = 1_000)
    {
        var t = TimeToExpiry.YearsUntilExpiry(NearestExpiry, at);
        for (var offset = -10; offset <= 10; offset++)
        {
            var strike = 23950m + (offset * 50m);
            var callPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Call, (double)underlying, (double)strike, t, 0.065, vol).Price);
            var putPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Put, (double)underlying, (double)strike, t, 0.065, vol).Price);
            engine.OnTick(MakeTick(WideCoreCallToken(offset), callPrice, at, oi: oi, depth: Depth(500, 400, bid: callPrice - 0.5m, ask: callPrice + 0.5m), volume: volume));
            engine.OnTick(MakeTick(WideCorePutToken(offset), putPrice, at, oi: oi, depth: Depth(500, 400, bid: putPrice - 0.5m, ask: putPrice + 0.5m), volume: volume));
        }
    }

    [Fact]
    public void ComputeCadence_CoreScorePointInTimeMetrics_AreNotNull_OnTheVeryFirstCadence()
    {
        // DepthImbalance/ItmSkew/GammaExposure need no prior cadence -- unlike the flow metrics
        // below, they should populate immediately once real quotes/OI exist.
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        TickWideCoreUniverse(engine, Start);

        var snapshot = engine.ComputeCadence(Start);
        var coreSnapshot = engine.LastCoreScoreSnapshot;

        Assert.NotNull(snapshot);
        Assert.NotNull(coreSnapshot);
        Assert.NotNull(coreSnapshot!.DepthImbalanceRaw);
        Assert.NotNull(coreSnapshot.ItmSkewRaw);
        Assert.NotNull(coreSnapshot.GammaExposureRaw);
    }

    [Fact]
    public void ComputeCadence_CoreScoreFlowMetrics_AreNullOrZero_OnTheVeryFirstCadence_WithNoPriorStateToDeltaAgainst()
    {
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 23999.5m, ask: 24000.5m)));
        TickWideCoreUniverse(engine, Start);

        engine.ComputeCadence(Start);
        var coreSnapshot = engine.LastCoreScoreSnapshot;

        Assert.NotNull(coreSnapshot);
        // NotionalVolumeRatio needs a prior volume baseline to compute a delta -- null on the
        // very first cadence, same as OiBuildupNetRaw's own well-established behavior.
        Assert.Null(coreSnapshot!.NotionalVolumeRatioRaw);
        // TrendReversion15m/BasisChange (Batch 3 fix) use THIS cadence's own future/spot LTP
        // open-to-close, not a prior-cadence price -- with exactly one future/spot tick this
        // cadence, CadenceOpen == CadenceClose, so both changes are a real 0, not null.
        // TrendReversion15m itself stays null: its window holds one 0-valued observation, giving
        // a zero path length that can't be normalized (net/pathLength), matching
        // CoreScoreOptionSimulator's own path>0 guard.
        Assert.Null(coreSnapshot.TrendReversion15mRaw);
        Assert.Equal(0, coreSnapshot.BasisChangeRaw);
        // OiChangeDiff15m needs _previousCadence, which doesn't exist yet -- null, not zero.
        Assert.Null(coreSnapshot.OiChangeDiff15mRaw);
        // FutureCvdNet5Min (Batch 3 fix, second pass): the 5-minute rolling SUM needs a full 5
        // real minutes elapsed since its own first cadence contribution before it's trusted --
        // matching RollingNetSumWindow.IsWarmedUp exactly (`latestTimestamp - firstSeenAt >=
        // window`) -- so it's null on the very first cadence (0 elapsed), not a real 0, even
        // though the per-tick volume delta itself is genuinely 0 this cadence (no prior volume to
        // diff against).
        Assert.Null(coreSnapshot.FutureCvdNet5MinRaw);
    }

    [Fact]
    public void ComputeCoreDepthImbalance_ExcludesStrikesOutsideItm2Atm1Band()
    {
        // Itm2Atm1: calls {-2,-1,0}, puts {0,+1,+2} by signed offset. Construct a universe where
        // the two furthest-in-band strikes (call offset -2, put offset +2) have a strongly
        // bullish depth reading, and everything OUTSIDE the band (offset +/-3 and beyond) has an
        // equally strong BEARISH reading -- if the band filter leaks, the result flips sign.
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        TickWideCoreUniverse(engine, Start);
        // Flush TickWideCoreUniverse's own neutral depth (500/400 on every strike) into a
        // completed cadence before sending the skewed depth this test actually asserts on --
        // DepthImbalance now averages every tick THIS cadence per strike (Batch 3 fix, matching
        // CadencePopulator's own DepthImbalanceAccumulator), so without this flush the neutral
        // baseline tick would blend into the skewed reading below instead of being superseded by
        // it (the old "last tick wins" semantics this test was originally written against).
        engine.ComputeCadence(Start);

        // Overwrite depth on every strike: heavily bid-skewed (bullish) inside Itm2Atm1, heavily
        // ask-skewed (bearish) outside it, on BOTH sides -- a leaking band would pull the result
        // toward 0 or flip its sign; a correct band keeps it strongly positive (call-bid-heavy
        // minus put-bid-heavy, matching CoreScoreOptionSimulator's own "positive = bullish" sign).
        var next = Start.AddSeconds(15);
        for (var offset = -10; offset <= 10; offset++)
        {
            var strike = 23950m + (offset * 50m);
            var callPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Call, 23950, (double)strike, TimeToExpiry.YearsUntilExpiry(NearestExpiry, next), 0.065, 0.20).Price);
            var putPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Put, 23950, (double)strike, TimeToExpiry.YearsUntilExpiry(NearestExpiry, next), 0.065, 0.20).Price);

            var callInItm2Atm1 = offset is >= -2 and <= 0;
            var putInItm2Atm1 = offset is >= 0 and <= 2;
            var callDepth = callInItm2Atm1 ? Depth(bidQty: 900, askQty: 100, bid: callPrice - 0.5m, ask: callPrice + 0.5m) : Depth(bidQty: 100, askQty: 900, bid: callPrice - 0.5m, ask: callPrice + 0.5m);
            var putDepth = putInItm2Atm1 ? Depth(bidQty: 100, askQty: 900, bid: putPrice - 0.5m, ask: putPrice + 0.5m) : Depth(bidQty: 900, askQty: 100, bid: putPrice - 0.5m, ask: putPrice + 0.5m);

            engine.OnTick(MakeTick(WideCoreCallToken(offset), callPrice, next, oi: 100_000, depth: callDepth, volume: 1_000));
            engine.OnTick(MakeTick(WideCorePutToken(offset), putPrice, next, oi: 100_000, depth: putDepth, volume: 1_000));
        }

        engine.ComputeCadence(next);
        var coreSnapshot = engine.LastCoreScoreSnapshot;

        Assert.NotNull(coreSnapshot);
        Assert.NotNull(coreSnapshot!.DepthImbalanceRaw);
        // Bid-heavy calls (bullish) minus ask-heavy... wait, put side is ask-heavy within the
        // band per the setup above (putInItm2Atm1 => bidQty:100, askQty:900) -- a call imbalance
        // near +0.8 minus a put imbalance near -0.8 should land close to +1.6, strongly positive.
        Assert.True(coreSnapshot.DepthImbalanceRaw!.Value > 1.0, $"Expected a strongly positive band-restricted DepthImbalance, got {coreSnapshot.DepthImbalanceRaw.Value:F3} -- the Itm2Atm1 band may be leaking strikes it shouldn't.");
    }

    [Fact]
    public void ComputeCoreItmSkew_IsNull_OnA0DteExpiryDay()
    {
        // NearestExpiry is fixed at 2026-09-08 by this file's own Option()/Future() helpers --
        // pass a cadence timestamp whose IST date equals that expiry to trigger the 0-DTE check,
        // regardless of AsOfDate.
        var expiryDayNow = new DateTimeOffset(2026, 9, 8, 10, 0, 0, TimeSpan.FromHours(5.5));
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, expiryDayNow));
        engine.OnTick(MakeTick(FutureToken, 24000m, expiryDayNow));
        TickWideCoreUniverse(engine, expiryDayNow);

        engine.ComputeCadence(expiryDayNow);
        var coreSnapshot = engine.LastCoreScoreSnapshot;

        Assert.NotNull(coreSnapshot);
        Assert.Null(coreSnapshot!.ItmSkewRaw);
        // Renormalize-by-present-weight (CoreScoreCalculator) must still publish a score from the
        // other 7 terms -- ItmSkew being null must not withhold the whole Core score.
        Assert.NotNull(coreSnapshot.CoreScore);
    }

    [Fact]
    public void ComputeCoreItmSkew_IsNotNull_OnANonExpiryDay_WithTheSameUniverse()
    {
        // Same universe/quotes as the 0-DTE test above, different day -- isolates the 0-DTE
        // check itself as the cause of the null, not some other missing precondition.
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        TickWideCoreUniverse(engine, Start);

        engine.ComputeCadence(Start);

        Assert.NotNull(engine.LastCoreScoreSnapshot!.ItmSkewRaw);
    }

    [Fact]
    public void ComputeCoreGammaExposure_ExcludesStrikesOutsideAtmPlusMinusTen()
    {
        // Set OI to 0 (excluded from the sum, per ComputeCoreGammaExposureRaw's own OI>0 guard)
        // on every strike EXCEPT one just inside the band (offset +10) and one just outside it
        // (offset +11 -- add one more ring to WideCoreUniverse's own +/-10 span for this one
        // strike) -- if the band leaks, the outside strike's nonzero OI would change the result.
        var universe = WideCoreUniverse();
        const int outsideOffset = 11;
        var outsideStrike = 23950m + (outsideOffset * 50m);
        universe.Add(Option("outside_call", OptionType.Call, outsideStrike));
        var engine = new LiveFeatureEngine(universe);

        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        var t = TimeToExpiry.YearsUntilExpiry(NearestExpiry, Start);

        // Every strike in the +/-10 band: zero OI (contributes nothing).
        for (var offset = -10; offset <= 10; offset++)
        {
            var strike = 23950m + (offset * 50m);
            var callPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Call, 23950, (double)strike, t, 0.065, 0.20).Price);
            var putPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Put, 23950, (double)strike, t, 0.065, 0.20).Price);
            engine.OnTick(MakeTick(WideCoreCallToken(offset), callPrice, Start, oi: 0, depth: Depth(500, 400, bid: callPrice - 0.5m, ask: callPrice + 0.5m)));
            engine.OnTick(MakeTick(WideCorePutToken(offset), putPrice, Start, oi: 0, depth: Depth(500, 400, bid: putPrice - 0.5m, ask: putPrice + 0.5m)));
        }

        // The one strike outside the band: large OI. If it leaked into the sum, GammaExposureRaw
        // would be strongly nonzero; if the band correctly excludes it, the result is null (no
        // strike inside the band had any OI at all).
        var outsidePrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Call, 23950, (double)outsideStrike, t, 0.065, 0.20).Price);
        engine.OnTick(MakeTick("outside_call", outsidePrice, Start, oi: 1_000_000, depth: Depth(500, 400, bid: outsidePrice - 0.5m, ask: outsidePrice + 0.5m)));

        engine.ComputeCadence(Start);

        Assert.Null(engine.LastCoreScoreSnapshot!.GammaExposureRaw);
    }

    [Fact]
    public void ComputeCoreNotionalVolumeRatio_ExcludesStrikesOutsideAtmPlusMinusFive()
    {
        // WideRatioUniverse spans exactly ATM+/-5 -- if NotionalVolumeRatio's own band leaked
        // beyond it, this test wouldn't catch that (no wider strikes exist). Instead: prove the
        // computed ratio only reflects the two ATM+/-5-inclusive edge strikes' own notional by
        // comparing against a hand-computed expectation using ALL eleven strikes on each side
        // (the whole WideRatioUniverse IS the ATM+/-5 band, so this doubles as the "matches a
        // manual computation" test for this metric).
        var engine = new LiveFeatureEngine(WideRatioUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        TickWideRatioUniverse(engine, Start, volume: 0); // volume=0 baseline: first real deltas come next cadence
        engine.ComputeCadence(Start);

        var at = Start.AddSeconds(15);
        double expectedCallNotional = 0, expectedPutNotional = 0;
        var t = TimeToExpiry.YearsUntilExpiry(NearestExpiry, at);
        for (var offset = -5; offset <= 5; offset++)
        {
            var strike = 23950m + (offset * 50m);
            var callPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Call, 23950, (double)strike, t, 0.065, 0.40).Price);
            var putPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Put, 23950, (double)strike, t, 0.065, 0.40).Price);
            engine.OnTick(MakeTick(WideCallToken(offset), callPrice, at, oi: 100_000, depth: Depth(500, 400, bid: callPrice - 0.5m, ask: callPrice + 0.5m), volume: 1_000));
            engine.OnTick(MakeTick(WidePutToken(offset), putPrice, at, oi: 100_000, depth: Depth(500, 400, bid: putPrice - 0.5m, ask: putPrice + 0.5m), volume: 1_000));
            expectedCallNotional += 1_000 * (double)callPrice;
            expectedPutNotional += 1_000 * (double)putPrice;
        }

        engine.ComputeCadence(at);
        var coreSnapshot = engine.LastCoreScoreSnapshot;

        Assert.NotNull(coreSnapshot);
        Assert.NotNull(coreSnapshot!.NotionalVolumeRatioRaw);
        var expected = Math.Log(expectedPutNotional / expectedCallNotional);
        Assert.Equal(expected, coreSnapshot.NotionalVolumeRatioRaw!.Value, precision: 3);
    }

    [Fact]
    public void ComputeCoreTrendReversionAndBasisChange_UseWithinCadenceLtpOpenToCloseChange()
    {
        // Batch 3 fix: TrendReversion15m/BasisChange read THIS cadence's own future/spot LTP
        // open-to-close (CadenceContext.FutureChangeFromLastCadence/SpotChangeFromLastCadence's
        // actual definition, despite the "FromLastCadence" name -- see ComputeCoreTrendAndBasis's
        // own doc comment), not a cross-cadence previous-mid-to-current-mid diff.
        var engine = new LiveFeatureEngine(WideCoreUniverse());

        // First cadence: exactly one future/spot tick each -- CadenceOpen == CadenceClose, so
        // futureChange/spotChange are a real 0 (not null), matching InstrumentPriceState's own
        // CadenceClose-CadenceOpen with a single tick. BasisChange is therefore a real 0 (0-0),
        // but TrendReversion15m stays null: its window holds one 0-valued observation, giving a
        // zero path length that can't be normalized (net/pathLength), matching
        // CoreScoreOptionSimulator's own path>0 guard.
        engine.OnTick(MakeTick(SpotToken, 23950m, Start, depth: null));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 23999m, ask: 24001m)));
        TickWideCoreUniverse(engine, Start);
        engine.ComputeCadence(Start);

        Assert.Null(engine.LastCoreScoreSnapshot!.TrendReversion15mRaw);
        Assert.Equal(0, engine.LastCoreScoreSnapshot!.BasisChangeRaw);

        // Second cadence: future prints 24000 then 24020 WITHIN this cadence (open=24000,
        // close=24020, futureChange=+20); spot prints 23950 then 23960 within the same cadence
        // (spotChange=+10). TrendReversion15m = -1 * (net/pathLength); with a single observation
        // in the window, net == pathLength == 20, so TrendReversion15m == -1.0 exactly (full
        // saturation, a single clean move). BasisChange = futureChange - spotChange = 20 - 10 = 10.
        var at = Start.AddSeconds(15);
        engine.OnTick(MakeTick(SpotToken, 23950m, at, depth: null));
        engine.OnTick(MakeTick(FutureToken, 24000m, at, depth: Depth(bidQty: 10, askQty: 10, bid: 23999m, ask: 24001m)));
        engine.OnTick(MakeTick(SpotToken, 23960m, at, depth: null));
        engine.OnTick(MakeTick(FutureToken, 24020m, at, depth: Depth(bidQty: 10, askQty: 10, bid: 24019m, ask: 24021m)));
        TickWideCoreUniverse(engine, at);
        engine.ComputeCadence(at);

        var coreSnapshot = engine.LastCoreScoreSnapshot;
        Assert.NotNull(coreSnapshot);
        Assert.Equal(-1.0, coreSnapshot!.TrendReversion15mRaw!.Value, precision: 6);
        Assert.Equal(10.0, coreSnapshot.BasisChangeRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCoreOiChangeDiff_ExcludesStrikesOutsideAtmPlusMinusTwo_AndAccumulatesOverTheRollingWindow()
    {
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start));
        TickWideCoreUniverse(engine, Start, oi: 100_000);
        engine.ComputeCadence(Start);

        Assert.Null(engine.LastCoreScoreSnapshot!.OiChangeDiff15mRaw);

        // Second cadence: bump OI by +5,000 on every call strike, +1,000 on every put strike,
        // both inside AND outside ATM+/-2 -- if the band leaks, the sum grows far beyond what the
        // 5 in-band strikes (offsets -2..2) alone would produce.
        var at = Start.AddSeconds(15);
        var t = TimeToExpiry.YearsUntilExpiry(NearestExpiry, at);
        for (var offset = -10; offset <= 10; offset++)
        {
            var strike = 23950m + (offset * 50m);
            var callPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Call, 23950, (double)strike, t, 0.065, 0.20).Price);
            var putPrice = Math.Max(0.5m, (decimal)BlackScholes.Calculate(OptionType.Put, 23950, (double)strike, t, 0.065, 0.20).Price);
            engine.OnTick(MakeTick(WideCoreCallToken(offset), callPrice, at, oi: 105_000, depth: Depth(500, 400, bid: callPrice - 0.5m, ask: callPrice + 0.5m)));
            engine.OnTick(MakeTick(WideCorePutToken(offset), putPrice, at, oi: 101_000, depth: Depth(500, 400, bid: putPrice - 0.5m, ask: putPrice + 0.5m)));
        }

        engine.ComputeCadence(at);
        var coreSnapshot = engine.LastCoreScoreSnapshot;

        Assert.NotNull(coreSnapshot);
        // Exactly 5 strikes in ATM+/-2 (offsets -2..2): callDelta = 5*5,000=25,000, putDelta =
        // 5*1,000=5,000 -- CallOiDelta-PutOiDelta = 20,000. A leaking band (all 21 strikes) would
        // give 21*5,000 - 21*1,000 = 84,000 instead.
        Assert.Equal(20_000.0, coreSnapshot!.OiChangeDiff15mRaw!.Value, precision: 6);
    }

    [Fact]
    public void ComputeCoreFutureCvdNet5Min_ClassifiesByQuoteRule_SignsBuyLeaningTicksPositive()
    {
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        // First future tick just establishes the volume baseline (no prior volume -> delta 0,
        // contributes nothing) -- matches FutureCvdProxyAccumulator's own "skip if volumeDelta<=0" rule.
        engine.OnTick(MakeTick(FutureToken, 24000m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 23999m, ask: 24001m), volume: 1_000));
        TickWideCoreUniverse(engine, Start);
        engine.ComputeCadence(Start);

        // Second cadence: LastPrice (24002) sits ABOVE the midpoint (24000.5) -- buy-leaning,
        // whole volume delta (500) signed positive. This is this metric's own "first seen"
        // cadence for warm-up purposes (Batch 3 fix, third pass): CadencePopulator's own
        // "skip a null cadence, never zero-fill it" rule means the window/warm-up timestamps only
        // advance on a cadence with a REAL contribution, not simply the first cadence overall --
        // see _coreFutureCvdFirstSeenAt's own doc comment.
        var second = Start.AddSeconds(15);
        engine.OnTick(MakeTick(FutureToken, 24002m, second, depth: Depth(bidQty: 10, askQty: 10, bid: 24000m, ask: 24001m), volume: 1_500));
        TickWideCoreUniverse(engine, second);
        engine.ComputeCadence(second);
        Assert.Null(engine.LastCoreScoreSnapshot!.FutureCvdNet5MinRaw);

        // Third cadence, exactly 5 real minutes after the SECOND (the first real contribution,
        // not the first cadence overall) -- warm-up needs another real contribution at or after
        // that mark, since the warm-up clock itself only advances on Add. LastPrice (24020) sits
        // AT the new midpoint (24020) -- a tie, which the quote rule's own >= counts as
        // buy-leaning, so this tick's whole volume delta (500) also signs positive. The window
        // still holds the second cadence's +500 (exactly 5min old, not yet evicted -- eviction is
        // a strict >, not >=), so the sum is 500 (second) + 500 (third) = 1000.
        var third = second.AddMinutes(5);
        engine.OnTick(MakeTick(FutureToken, 24020m, third, depth: Depth(bidQty: 10, askQty: 10, bid: 24019m, ask: 24021m), volume: 2_000));
        TickWideCoreUniverse(engine, third);
        engine.ComputeCadence(third);

        var coreSnapshot = engine.LastCoreScoreSnapshot;
        Assert.NotNull(coreSnapshot);
        Assert.Equal(1000.0, coreSnapshot!.FutureCvdNet5MinRaw!.Value, precision: 6);
    }

    [Fact]
    public void CoreScoreCalculator_PublishesAScore_ThroughLiveFeatureEngine_WithRealisticQuotes()
    {
        // End-to-end smoke test: a fully-quoted, realistic cadence should warm up and produce a
        // real CoreScore, not just individual raw values.
        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.OnTick(MakeTick(SpotToken, 23950m, Start));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start, depth: Depth(bidQty: 10, askQty: 10, bid: 23999m, ask: 24001m)));
        TickWideCoreUniverse(engine, Start);
        engine.ComputeCadence(Start);

        var at = Start.AddSeconds(15);
        engine.OnTick(MakeTick(FutureToken, 24010m, at, depth: Depth(bidQty: 10, askQty: 10, bid: 24009m, ask: 24011m)));
        TickWideCoreUniverse(engine, at);
        engine.ComputeCadence(at);

        var coreSnapshot = engine.LastCoreScoreSnapshot;
        Assert.NotNull(coreSnapshot);
        Assert.True(coreSnapshot!.IsWarmedUp);
        Assert.NotNull(coreSnapshot.CoreScore);
        Assert.InRange(coreSnapshot.CoreScore!.Value, -100.0, 100.0);
        // CoreScoreFast/Slow should also have started warming up (at least one observation each).
        Assert.NotNull(coreSnapshot.CoreScoreFast);
        Assert.NotNull(coreSnapshot.CoreScoreSlow);
    }

    [Fact]
    public void SeedCoreScoreHistory_DoesNotThrow_OnNullRawValues()
    {
        var history = new List<CoreScoreSnapshot>
        {
            new() { ComputedAt = Start, DepthImbalanceRaw = null },
        };

        var engine = new LiveFeatureEngine(WideCoreUniverse());

        var exception = Record.Exception(() => engine.SeedCoreScoreHistory(history));
        Assert.Null(exception);
    }

    [Fact]
    public void SeedCoreScoreHistory_ReplaysCoreScoreIntoFastAndSlowWindows_SoTheyAreImmediatelyWarm()
    {
        // The whole point of A5's restart-replay fix: post-replay, CoreScoreFast/Slow must be
        // immediately non-null on the very next cadence, not need a fresh 10/30-minute warm-up.
        var history = new List<CoreScoreSnapshot>
        {
            new() { ComputedAt = Start, CoreScore = 42.0 },
            new() { ComputedAt = Start.AddSeconds(15), CoreScore = 44.0 },
        };

        var engine = new LiveFeatureEngine(WideCoreUniverse());
        engine.SeedCoreScoreHistory(history);

        engine.OnTick(MakeTick(SpotToken, 23950m, Start.AddSeconds(30)));
        engine.OnTick(MakeTick(FutureToken, 24000m, Start.AddSeconds(30), depth: Depth(bidQty: 10, askQty: 10, bid: 23999m, ask: 24001m)));
        TickWideCoreUniverse(engine, Start.AddSeconds(30));
        engine.ComputeCadence(Start.AddSeconds(30));

        var coreSnapshot = engine.LastCoreScoreSnapshot;
        Assert.NotNull(coreSnapshot);
        Assert.NotNull(coreSnapshot!.CoreScoreFast);
        Assert.NotNull(coreSnapshot.CoreScoreSlow);
    }

    // Audit finding F61 (2026-09-22): regression coverage for the Underlying-ambiguity bug found
    // while scoping the Sensex/Bank Nifty tick-collection task. Before the fix, _spot/_future/
    // _nearestExpiry were picked via plain First(...)/Min(...) over the WHOLE instruments list with
    // no Underlying filter -- harmless only because every real caller's list was 100% NIFTY. These
    // tests build a fixture with a second underlying's rows mixed in (deliberately placed FIRST in
    // the list, and with an earlier expiry than NIFTY's own, so an unfiltered First()/Min() would
    // pick the wrong one) and assert the engine still resolves to NIFTY's own instruments only.
    const string OtherUnderlyingSpotToken = "99000";
    const string OtherUnderlyingFutureToken = "99001";
    const string OtherUnderlyingOptionToken = "99002";
    static readonly DateOnly OtherUnderlyingEarlierExpiry = NearestExpiry.AddDays(-3);

    static List<Instrument> MixedUnderlyingUniverse() =>
    [
        // Other underlying's rows first, and with an earlier expiry -- if the constructor's
        // First()/Min() calls were ever unfiltered again, these would win.
        new()
        {
            Token = OtherUnderlyingSpotToken,
            Exchange = Exchange.Bse,
            TradingSymbol = "SENSEX",
            InstrumentType = InstrumentType.Index,
            Underlying = "SENSEX",
            LotSize = 1,
            TickSize = 0.05m,
            AsOfDate = AsOfDate,
        },
        new()
        {
            Token = OtherUnderlyingFutureToken,
            Exchange = Exchange.Bfo,
            TradingSymbol = "SENSEX-FUT",
            InstrumentType = InstrumentType.Future,
            ExpiryDate = OtherUnderlyingEarlierExpiry,
            Underlying = "SENSEX",
            LotSize = 10,
            TickSize = 0.05m,
            AsOfDate = AsOfDate,
        },
        new()
        {
            Token = OtherUnderlyingOptionToken,
            Exchange = Exchange.Bfo,
            TradingSymbol = "SENSEX-OPT",
            InstrumentType = InstrumentType.Option,
            OptionType = OptionType.Call,
            StrikePrice = 80000m,
            ExpiryDate = OtherUnderlyingEarlierExpiry,
            Underlying = "SENSEX",
            LotSize = 10,
            TickSize = 0.05m,
            AsOfDate = AsOfDate,
        },
        .. BaseUniverse(),
    ];

    [Fact]
    public void Constructor_WithMixedUnderlyingInstruments_OnlyResolvesNiftyOwnInstruments()
    {
        var engine = new LiveFeatureEngine(MixedUnderlyingUniverse());

        Assert.NotNull(engine.FindInstrument(SpotToken));
        Assert.NotNull(engine.FindInstrument(FutureToken));
        Assert.NotNull(engine.FindInstrument(CallToken));

        Assert.Null(engine.FindInstrument(OtherUnderlyingSpotToken));
        Assert.Null(engine.FindInstrument(OtherUnderlyingFutureToken));
        Assert.Null(engine.FindInstrument(OtherUnderlyingOptionToken));
    }

    [Fact]
    public void Constructor_WithMixedUnderlyingInstruments_ComputesCadenceIdenticallyToNiftyOnlyUniverse()
    {
        // Same tick sequence fed to two engines -- one built from a NIFTY-only universe (today's
        // real-world shape), one from the mixed universe above (the shape once Sensex/Bank Nifty
        // rows exist in the same table) -- asserting byte-identical composite scores proves the
        // extra rows are inert, not just that FindInstrument happens to filter them.
        var niftyOnlyEngine = new LiveFeatureEngine(BaseUniverse());
        var mixedEngine = new LiveFeatureEngine(MixedUnderlyingUniverse());

        void Feed(LiveFeatureEngine engine)
        {
            engine.OnTick(MakeTick(SpotToken, 23950m, Start.AddSeconds(30)));
            engine.OnTick(MakeTick(FutureToken, 24000m, Start.AddSeconds(30), depth: Depth(bidQty: 10, askQty: 10, bid: 23999m, ask: 24001m)));
            engine.OnTick(MakeTick(CallToken, 120m, Start.AddSeconds(30), depth: Depth(bidQty: 10, askQty: 10, bid: 119m, ask: 121m)));
            engine.OnTick(MakeTick(PutToken, 110m, Start.AddSeconds(30), depth: Depth(bidQty: 10, askQty: 10, bid: 109m, ask: 111m)));
            engine.Sample(Start.AddSeconds(30));
        }

        Feed(niftyOnlyEngine);
        Feed(mixedEngine);

        // The other underlying's own ticks (dead weight for a real feed sharing one WebSocket) must
        // not perturb anything either.
        mixedEngine.OnTick(MakeTick(OtherUnderlyingSpotToken, 81000m, Start.AddSeconds(31)));
        mixedEngine.OnTick(MakeTick(OtherUnderlyingFutureToken, 81050m, Start.AddSeconds(31)));

        var niftyOnlySnapshot = niftyOnlyEngine.ComputeCadence(Start.AddSeconds(45));
        var mixedSnapshot = mixedEngine.ComputeCadence(Start.AddSeconds(45));

        Assert.Equal(niftyOnlySnapshot?.CompositeScore, mixedSnapshot?.CompositeScore);
        Assert.Equal(niftyOnlySnapshot?.IsWarmedUp, mixedSnapshot?.IsWarmedUp);
    }
}
