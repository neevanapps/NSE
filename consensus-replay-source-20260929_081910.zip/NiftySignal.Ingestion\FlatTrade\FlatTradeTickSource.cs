using System.Net.WebSockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Threading.Channels;
using Microsoft.Extensions.Logging;
using NiftySignal.Domain.Abstractions;
using NiftySignal.Domain.Entities;
using NiftySignal.Domain.Enums;

namespace NiftySignal.Ingestion.FlatTrade;

/// <summary>
/// Live <see cref="ITickSource"/> over FlatTrade's WebSocket feed. An access token and the
/// day's subscription list are supplied at construction -- obtaining/refreshing the token
/// (plan section 4.3, daily) and building the subscription list (section 3.1, the 08:45
/// job) are separate concerns, not yet wired up; this class only owns "given those, stream
/// ticks reliably and reconnect when the connection drops."
///
/// Message shapes confirmed 2026-09-03 against the live docs at pi.flattrade.in/docs.
/// That site's own changelog documents a breaking change from an older API generation
/// (connect task "c" -> "a", auth field "susertoken" -> "accesstoken", connect
/// acknowledgement "ck" -> "ak") -- this targets the current shape, not the older one
/// still found in some reference clients circulating online. Still not exercised against
/// a real account, since that needs an approved API key.
/// </summary>
public sealed class FlatTradeTickSource(
    FlatTradeOptions options,
    string userId,
    string accessToken,
    IReadOnlyList<(Exchange Exchange, string Token)> subscriptions,
    IDataGapRecorder dataGapRecorder,
    ILogger<FlatTradeTickSource> logger) : ITickSource
{
    // Additions requested live, after the session's already connected (e.g. a dashboard
    // user watching a strike outside the originally-resolved ATM band). Kept separately
    // from the fixed `subscriptions` list (rather than mutating it) because it also has to
    // survive a reconnect -- SubscribeAllAsync replays both lists on every (re)connect.
    readonly List<(Exchange Exchange, string Token)> _dynamicSubscriptions = [];
    readonly Lock _dynamicSubscriptionsSync = new();
    readonly Channel<(Exchange Exchange, string Token)> _subscriptionRequests = Channel.CreateUnbounded<(Exchange, string)>();

    /// <summary>
    /// The currently-open data gap, if any -- promoted from a PumpAsync-local variable
    /// (2026-09-07, live-caught) so RunSessionAsync can close it too. Previously the only
    /// close point was PumpAsync's post-await check, reached only if RunSessionAsync *returns*
    /// -- which in normal operation it doesn't; a successful reconnect just keeps the session
    /// running (streaming ticks) for the next hour, not returning. Every gap this feed had ever
    /// recorded stayed open forever as a result (confirmed live: 11 gaps back to 2026-09-04,
    /// all still open), which silently blocked every entry via EntryContext.HasOpenDataGap.
    /// </summary>
    long? _openGapId;

    /// <summary>Thread-safe, callable at any time regardless of connection state -- queued if the session is mid-reconnect.</summary>
    public void RequestSubscribe(Exchange exchange, string token) =>
        _subscriptionRequests.Writer.TryWrite((exchange, token));

    /// <summary>
    /// Fires whenever <see cref="ReconnectionPolicy.ShouldAlert"/> does (2026-09-07,
    /// live-caught: the feed dropped six times in one morning with a FATAL log line each time
    /// and nothing else -- no one watching logs would have known). Deliberately not wired
    /// straight to Telegram here -- this project stays a plain tick source with no notification
    /// dependency; the caller (which already has ITelegramNotifier) decides what to do with it.
    /// Async and awaited by the raiser rather than a plain event, so a subscriber's own
    /// exception (or a slow HTTP call) can't get silently dropped or crash the process the way
    /// an async-void handler would.
    /// </summary>
    public event Func<int, Task>? ConnectionUnstable;

    public async IAsyncEnumerable<Tick> ReadTicksAsync([EnumeratorCancellation] CancellationToken cancellationToken)
    {
        var channel = Channel.CreateUnbounded<Tick>(new UnboundedChannelOptions { SingleReader = true, SingleWriter = true });
        var pump = PumpAsync(channel.Writer, cancellationToken);

        await foreach (var tick in channel.Reader.ReadAllAsync(cancellationToken))
        {
            yield return tick;
        }

        await pump;
    }

    async Task PumpAsync(ChannelWriter<Tick> writer, CancellationToken ct)
    {
        var policy = new ReconnectionPolicy();

        try
        {
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    await RunSessionAsync(writer, policy, ct);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    policy.RecordFailure();
                    logger.LogError(ex, "FlatTrade feed session failed (consecutive failures: {Count})", policy.ConsecutiveFailures);

                    // Every failure inside one outage is recorded, not just the first
                    // (2026-09-07). A gap that lasted 59 seconds against a backoff starting
                    // at 1 second is either one slow reconnect or a run of escalating
                    // retries, and only the attempt count can tell those apart.
                    if (_openGapId is { } openGapId)
                    {
                        await dataGapRecorder.RecordGapAttemptAsync(openGapId, ex.Message, ct);
                    }
                    else
                    {
                        _openGapId = await dataGapRecorder.RecordGapStartedAsync(DateTimeOffset.UtcNow, ex.Message, ct);
                    }

                    if (policy.ShouldAlert)
                    {
                        logger.LogCritical(
                            "FlatTrade feed has failed {Count} times consecutively -- exceeds the {Threshold} alert threshold",
                            policy.ConsecutiveFailures, ReconnectionPolicy.AlertThreshold);

                        if (ConnectionUnstable is { } handler)
                        {
                            await handler(policy.ConsecutiveFailures);
                        }
                    }

                    var delay = policy.NextDelay();
                    logger.LogWarning("Reconnecting to FlatTrade feed in {Delay}", delay);
                    await Task.Delay(delay, ct);
                    continue;
                }

                // Reached only if RunSessionAsync returns normally (e.g. the server closed
                // the socket gracefully -- see the `json is null` branch below) rather than
                // throwing. The far more common "reconnected and resumed streaming" case is
                // handled inside RunSessionAsync itself, at the point auth actually succeeds --
                // this is just a fallback for the graceful-close path.
                if (_openGapId is not null)
                {
                    await dataGapRecorder.CloseAllOpenGapsAsync(DateTimeOffset.UtcNow, ct);
                    _openGapId = null;
                }
            }
        }
        finally
        {
            writer.TryComplete();
        }
    }

    async Task RunSessionAsync(ChannelWriter<Tick> writer, ReconnectionPolicy policy, CancellationToken ct)
    {
        using var ws = new ClientWebSocket();
        await ws.ConnectAsync(new Uri(options.WebSocketUrl), ct);
        logger.LogInformation("FlatTrade WebSocket connected");

        using var sessionCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        var heartbeat = HeartbeatLoopAsync(ws, sessionCts.Token);
        var subscriptionDrain = DrainSubscriptionRequestsAsync(ws, sessionCts.Token);

        try
        {
            await SendAsync(ws, $$"""{"t":"a","uid":"{{userId}}","actid":"{{userId}}","source":"API","accesstoken":"{{accessToken}}"}""", ct);

            var state = new Dictionary<string, FlatTradeFeedState>();
            var buffer = new byte[64 * 1024];
            var subscribed = false;

            while (ws.State == WebSocketState.Open && !ct.IsCancellationRequested)
            {
                var json = await ReceiveMessageAsync(ws, buffer, ct);
                if (json is null)
                {
                    logger.LogWarning("FlatTrade WebSocket closed by server");
                    return;
                }

                var msg = JsonSerializer.Deserialize<RawFeedMessage>(json, JsonOpts);
                if (msg?.Type is null)
                {
                    continue;
                }

                if (msg.Type == "ak")
                {
                    policy.RecordSuccess();

                    // The actual "the outage is over" moment -- authenticated and about to
                    // resume streaming, not "the session object eventually returned" (see
                    // _openGapId's doc comment for why that distinction is the whole bug).
                    // Closes *all* open gaps unconditionally (not just _openGapId), because a
                    // service restart while disconnected starts this process with _openGapId
                    // null even though the DB still has a real open gap from the previous
                    // process -- confirmed live 2026-09-07 (gap #14, orphaned by a restart,
                    // never closed by this instance because it never opened it).
                    await dataGapRecorder.CloseAllOpenGapsAsync(DateTimeOffset.UtcNow, ct);
                    _openGapId = null;

                    if (!subscribed)
                    {
                        await SubscribeAllAsync(ws, ct);
                        subscribed = true;
                    }
                }
                else if (msg.Type is "tk" or "tf" or "dk" or "df" && msg.Exchange is not null && msg.Token is not null)
                {
                    var key = $"{msg.Exchange}|{msg.Token}";
                    if (!state.TryGetValue(key, out var feedState))
                    {
                        state[key] = feedState = new FlatTradeFeedState(FlatTradeAuthClient.ParseExchange(msg.Exchange), msg.Token);
                    }

                    feedState.ApplyDelta(msg);
                    // UtcNow, not Now: Npgsql only accepts Offset=0 for timestamptz columns,
                    // and this flows straight into a persisted Tick.ReceivedAt.
                    if (feedState.ToTick(DateTimeOffset.UtcNow) is { } tick)
                    {
                        await writer.WriteAsync(tick, ct);
                    }
                }
                // "om"/"ok" order-update messages are ignored -- this is a market-data-only tick source.
            }
        }
        finally
        {
            sessionCts.Cancel();
            await Task.WhenAny(Task.WhenAll(heartbeat, subscriptionDrain), Task.Delay(TimeSpan.FromSeconds(2), CancellationToken.None));
        }
    }

    async Task SubscribeAllAsync(ClientWebSocket ws, CancellationToken ct)
    {
        List<(Exchange Exchange, string Token)> dynamic;
        lock (_dynamicSubscriptionsSync)
        {
            dynamic = [.. _dynamicSubscriptions];
        }

        foreach (var (exchange, token) in subscriptions.Concat(dynamic))
        {
            var code = FlatTradeAuthClient.ExchangeCode(exchange);
            await SendAsync(ws, $$"""{"t":"t","k":"{{code}}|{{token}}"}""", ct);
            await SendAsync(ws, $$"""{"t":"d","k":"{{code}}|{{token}}"}""", ct);
        }
        logger.LogInformation("Subscribed to {Count} instrument(s) (touchline + depth)", subscriptions.Count + dynamic.Count);
    }

    /// <summary>Sends a live subscribe message for anything queued via <see cref="RequestSubscribe"/>, and remembers it so a reconnect's SubscribeAllAsync replays it too.</summary>
    async Task DrainSubscriptionRequestsAsync(ClientWebSocket ws, CancellationToken ct)
    {
        try
        {
            await foreach (var (exchange, token) in _subscriptionRequests.Reader.ReadAllAsync(ct))
            {
                lock (_dynamicSubscriptionsSync)
                {
                    if (_dynamicSubscriptions.Contains((exchange, token)))
                    {
                        continue; // already subscribed earlier this session (or a prior one)
                    }

                    _dynamicSubscriptions.Add((exchange, token));
                }

                var code = FlatTradeAuthClient.ExchangeCode(exchange);
                await SendAsync(ws, $$"""{"t":"t","k":"{{code}}|{{token}}"}""", ct);
                await SendAsync(ws, $$"""{"t":"d","k":"{{code}}|{{token}}"}""", ct);
                logger.LogInformation("Dynamically subscribed to {Exchange}|{Token} (touchline + depth)", code, token);
            }
        }
        catch (OperationCanceledException)
        {
        }
    }

    async Task HeartbeatLoopAsync(ClientWebSocket ws, CancellationToken ct)
    {
        try
        {
            while (!ct.IsCancellationRequested)
            {
                // Docs require a heartbeat every 30s to keep the connection alive; 25s
                // leaves a small margin.
                await Task.Delay(TimeSpan.FromSeconds(25), ct);
                if (ws.State == WebSocketState.Open)
                {
                    await SendAsync(ws, """{"t":"h"}""", ct);
                }
            }
        }
        catch (OperationCanceledException)
        {
        }
    }

    static async Task SendAsync(ClientWebSocket ws, string json, CancellationToken ct) =>
        await ws.SendAsync(Encoding.UTF8.GetBytes(json), WebSocketMessageType.Text, endOfMessage: true, ct);

    static async Task<string?> ReceiveMessageAsync(ClientWebSocket ws, byte[] buffer, CancellationToken ct)
    {
        using var messageStream = new MemoryStream();
        WebSocketReceiveResult result;
        do
        {
            result = await ws.ReceiveAsync(buffer, ct);
            if (result.MessageType == WebSocketMessageType.Close)
            {
                return null;
            }
            messageStream.Write(buffer, 0, result.Count);
        } while (!result.EndOfMessage);

        return Encoding.UTF8.GetString(messageStream.ToArray());
    }

    static readonly JsonSerializerOptions JsonOpts = new(JsonSerializerDefaults.Web);
}
