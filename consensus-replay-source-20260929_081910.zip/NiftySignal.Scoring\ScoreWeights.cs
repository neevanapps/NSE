namespace NiftySignal.Scoring;

/// <summary>
/// A versioned weight set for the components. Weights live in config in the real system and
/// are versioned there; this record is just the shape -- every persisted score records the
/// <see cref="Version"/> that produced it, so a later re-tune is always traceable back to
/// which weights were live when a signal fired.
/// </summary>
public sealed record ScoreWeights(
    string Version,
    double OiBuildupNet,
    double Pcr,
    double FuturesBasis,
    double IvSkew,
    double PriceMomentum,
    double DepthImbalance,
    double VixChange = 0.0,
    double GammaExposure = 0.0,
    double VolumePcr = 0.0,
    double SpreadRatio = 0.0,
    double VannaExposure = 0.0,
    double CharmExposure = 0.0,
    double CvdProxy = 0.0,
    double StraddleRichness = 0.0)
{
    /// <summary>
    /// The plan's own starting weights (section 6: 25/20/15/15/15/10), rescaled by 0.95 to
    /// make room for a deliberately conservative 0.05 VixChange weight (2026-09-04) -- VIX
    /// is a genuinely new, empirically-unvalidated signal source here (unlike k, there's no
    /// accumulated live data yet to derive a weight from), so it starts small rather than
    /// displacing a proportional share of an already-tuned six.
    ///
    /// PriceMomentum cut from 0.1425 to 0.07 (2026-09-07), after the first full live session's
    /// data showed it correlates strongly with the price move that already happened (backward
    /// r=+0.48 at 5min) but not with what comes next (forward r=-0.08) -- it's a lagging
    /// confirmation signal, not a leading one, consistent with a live-caught incident the same
    /// day where a momentum dip dragged the score down through a move that turned out to still
    /// be flat-to-up. The freed 0.0725 went to OiBuildupNet and DepthImbalance -- the two
    /// components whose raw values actually change most cadences (see the same day's staleness
    /// check), rather than to Pcr/FuturesBasis/IvSkew, whose apparent forward correlation that
    /// day is suspected to be a single trending session's spurious correlation, not signal.
    /// Still sums to 1.0; see <see cref="Total"/>'s own test coverage.
    /// </summary>
    /// <summary>
    /// GammaExposure (2026-09-07) starts at weight 0.0 -- unlike VixChange, which launched with
    /// a small nonzero weight, GEX has zero days of validated evidence yet (the day-one attempt
    /// to check it used strike_snapshots' persisted ATM+/-2 band, too narrow a slice of the
    /// chain to mean anything -- see ComputeGammaExposure, which is computed from the *full*
    /// nearest-expiry chain instead, precisely so a real multi-day evaluation becomes possible).
    /// It's included in the composite and persisted every cadence starting now purely so there's
    /// a real GammaExposureZ history to evaluate before ever giving it a nonzero weight.
    /// </summary>
    /// <summary>
    /// VolumePcr (2026-09-07) starts at weight 0.0 for the same reason GammaExposure does --
    /// zero days of validated evidence. Unlike GammaExposure, a same-day offline check found
    /// mixed evidence even on methodology: a notional-weighted version of the existing
    /// (count-weighted) Pcr correlated far more strongly with forward price than count-weighted
    /// Pcr does, but for traded volume specifically, count- and notional-weighted put/call
    /// ratios actually disagreed in sign at the 15-minute horizon. VolumePcr launches
    /// notional-weighted (matching the stronger OI-based result, and the more economically
    /// meaningful reading -- rupee value traded, not just contract count), but that
    /// count-vs-notional disagreement is exactly the kind of thing worth watching once there's
    /// real multi-day VolumePcrZ history to look at.
    /// </summary>
    /// <summary>
    /// SpreadRatio (2026-09-07) starts at weight 0.0 for the same reason GammaExposure and
    /// VolumePcr do -- zero days of validated evidence. Unlike VolumePcr's mixed methodology
    /// signal, this one came back clean on a same-day check: put-spread/call-spread ratio
    /// correlated +0.315 with the 15-minute forward price move, consistently signed across
    /// 1/5/15-minute horizons (unlike VolumePcr's count-vs-notional sign disagreement), and on
    /// a much less autocorrelated series than the raw-level metrics whose apparent correlation
    /// turned out to be a single trending day's spurious signal -- the cleanest same-day result
    /// of the three new diagnostic components. Still launches at 0.0 regardless: one day is one
    /// day, not multi-day validated evidence.
    /// </summary>
    /// <summary>
    /// VannaExposure and CharmExposure (2026-09-08) both start at weight 0.0 for the same
    /// reason every other diagnostic component has -- zero days of validated evidence. Unlike
    /// GammaExposure/VolumePcr/SpreadRatio, these went in without even a same-day correlation
    /// check (built ahead of today's expiry-day afternoon decay window specifically, so there
    /// would be *something* to check afterwards) -- treat these two as earlier-stage than the
    /// other three diagnostics until that first real evaluation happens.
    /// </summary>
    /// <summary>
    /// CvdProxy and StraddleRichness (2026-09-08) both start at weight 0.0 -- same reasoning as
    /// VannaExposure/CharmExposure, built ahead of evidence rather than after it. StraddleRichness
    /// in particular is not even the same *kind* of signal as the other twelve: it reads
    /// volatility demand, not price direction, so a validated nonzero weight for it would likely
    /// need a different integration shape than a plain addition to the directional weighted sum
    /// -- a decision for whenever it's actually validated, not now.
    ///
    /// PENDING (audit finding F43, standing rule, 2026-09-09 external review): none of the seven diagnostic weights above
    /// (GammaExposure/VolumePcr/SpreadRatio/VannaExposure/CharmExposure/CvdProxy/
    /// StraddleRichness) move off 0.0 until scripts/batch5-component-correlation.sql has run
    /// against several *clean* live sessions (not VM-restart-interrupted ones) on the current,
    /// corrected formulas. This is not a one-time gate to clear -- re-check it every time before
    /// raising any of these, not just the first time.
    ///
    /// PENDING (audit finding F9, from the score-reactivity discussion 2026-09-08 -- see fix
    /// plan dazzling-orbiting-whistle.md's Batch 5, "ongoing, not a one-time fix"): OiBuildupNet,
    /// Pcr, and IvSkew all read option positioning; FuturesBasis and PriceMomentum both come off
    /// the futures price -- these weights assume the fourteen components are independent inputs,
    /// which they're likely not. Tooling exists (scripts/batch5-component-correlation.sql,
    /// ranks pairwise |correlation| across all fourteen) but hasn't been run yet -- needs several
    /// sessions of live data on the Batch 3/4/6-corrected formulas first, not just one or two, per
    /// the plan's own reasoning (computing this against still-buggy components would just encode
    /// those bugs more precisely). Folds into the three-parallel-scoring-system idea (current
    /// weights / correlation-ranked / decorrelated minimal set) already discussed and agreed to
    /// think over, not a one-off reweighting pass.
    /// </summary>
    public static ScoreWeights Default { get; } = new(
        // Short and date-stamped, matching RulesetVersion's convention -- not a changelog. The
        // full history of what changed and why lives in this record's doc comments above (and
        // in git blame), not in an ever-growing string that a live trade insert has to fit
        // inside a database column (live-caught 2026-09-08: the old descriptive-suffix version
        // grew past ScoreWeightsVersion's column length and silently killed the trading loop).
        Version: "live-2026-09-09",
        // OiBuildupNet/DepthImbalance raised again (2026-09-09, F4, external review): the same
        // 0.07 PriceMomentum carried below is now fully cut to 0, not just window-fixed -- see
        // PriceMomentum's own comment. Freed weight split evenly between these two again, same
        // reasoning and same two recipients as the 2026-09-07 cut (0.1425->0.07): they're the
        // components whose raw values actually change most cadences.
        OiBuildupNet: 0.3125,
        Pcr: 0.19, // PENDING (audit finding F23) -- sign vs. bullish/bearish reading, see LiveFeatureEngine.ComputePcr
        FuturesBasis: 0.1425, // PENDING (audit finding F25) -- may warrant weight 0, see LiveFeatureEngine.Sample's basis comment
        IvSkew: 0.1425, // PENDING (audit finding F24) -- sign, and 25-delta rigor, see LiveFeatureEngine.ComputeIvSkew
        // Cut from 0.07 to 0.0 (2026-09-09, audit finding F4, external review): the 2026-09-08
        // window fix (see PriceMomentumZScoreWindow) only addressed the z-scoring bug, not the
        // underlying finding it was layered on top of -- the 2026-09-07 correlation check (see
        // this record's own history above) already showed momentum is a lagging, not leading,
        // signal (backward r=+0.48, forward r=-0.08). No amount of z-window tuning fixes that;
        // the honest move is weight 0, not a retuned k around a component known to be cut.
        // Not deleted from the composite entirely (ScoreComponentInputs/ScoreSnapshot keep
        // PriceMomentumRaw/Z) -- it's a required component still, so it still gates warm-up and
        // stays visible for anyone watching the raw series, just with zero say in the score.
        PriceMomentum: 0.0,
        DepthImbalance: 0.1625,
        VixChange: 0.05, // PENDING (audit finding F27) -- open-baseline vs. rolling lookback, see LiveFeatureEngine.ComputeVixChange
        GammaExposure: 0.0,
        VolumePcr: 0.0,
        SpreadRatio: 0.0,
        VannaExposure: 0.0,
        CharmExposure: 0.0,
        CvdProxy: 0.0,
        StraddleRichness: 0.0);

    public double Total => OiBuildupNet + Pcr + FuturesBasis + IvSkew + PriceMomentum + DepthImbalance + VixChange
        + GammaExposure + VolumePcr + SpreadRatio + VannaExposure + CharmExposure + CvdProxy + StraddleRichness;
}
